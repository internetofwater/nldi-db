--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = charadata, pg_catalog;

SET search_path = charadata, pg_catalog;

--
-- Data for Name: acc_charadata; Type: TABLE DATA; Schema: charadata; Owner: postgres
--

COPY acc_charadata (seq, comid, charaid, val, nodatap) FROM stdin;
\.
COPY acc_charadata (seq, comid, charaid, val, nodatap) FROM '$$PATH$$/4030.dat';

--
-- Data for Name: cat_charadata; Type: TABLE DATA; Schema: charadata; Owner: postgres
--

COPY cat_charadata (seq, comid, charaid, val, nodatap) FROM stdin;
\.
COPY cat_charadata (seq, comid, charaid, val, nodatap) FROM '$$PATH$$/4031.dat';

--
-- Data for Name: charametadata; Type: TABLE DATA; Schema: charadata; Owner: dblodgett
--

COPY charametadata ("row", "ID", description, units, "datasetLabel", "datasteURL", "themeLabel", "themeURL", "watershedType") FROM stdin;
\.
COPY charametadata ("row", "ID", description, units, "datasetLabel", "datasteURL", "themeLabel", "themeURL", "watershedType") FROM '$$PATH$$/4033.dat';

--
-- Data for Name: tot_charadata; Type: TABLE DATA; Schema: charadata; Owner: postgres
--

COPY tot_charadata (seq, comid, charaid, val, nodatap) FROM stdin;
\.
COPY tot_charadata (seq, comid, charaid, val, nodatap) FROM '$$PATH$$/4032.dat';

--
-- PostgreSQL database dump complete
--

