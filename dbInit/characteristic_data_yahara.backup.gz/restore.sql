--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = characteristic_data, pg_catalog;

SET search_path = characteristic_data, pg_catalog;

--
-- Data for Name: characteristic_metadata; Type: TABLE DATA; Schema: characteristic_data; Owner: nldi
--

COPY characteristic_metadata (characteristic_id, characteristic_description, units, dataset_label, dataset_url, theme_label, theme_url, characteristic_type) FROM stdin;
\.
COPY characteristic_metadata (characteristic_id, characteristic_description, units, dataset_label, dataset_url, theme_label, theme_url, characteristic_type) FROM '$$PATH$$/4030.dat';

--
-- Data for Name: divergence_routed_characteristics; Type: TABLE DATA; Schema: characteristic_data; Owner: nldi
--

COPY divergence_routed_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM stdin;
\.
COPY divergence_routed_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM '$$PATH$$/4031.dat';

--
-- Data for Name: local_catchment_characteristics; Type: TABLE DATA; Schema: characteristic_data; Owner: nldi
--

COPY local_catchment_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM stdin;
\.
COPY local_catchment_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM '$$PATH$$/4033.dat';

--
-- Data for Name: total_accumulated_characteristics; Type: TABLE DATA; Schema: characteristic_data; Owner: nldi
--

COPY total_accumulated_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM stdin;
\.
COPY total_accumulated_characteristics (comid, characteristic_id, characteristic_value, percent_nodata) FROM '$$PATH$$/4032.dat';

--
-- PostgreSQL database dump complete
--

