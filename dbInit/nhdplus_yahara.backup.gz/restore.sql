--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.2
-- Dumped by pg_dump version 9.5.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = nhdplus_navigation, pg_catalog;

DROP INDEX nhdplus_navigation.tmp_navigation_working_pk2;
DROP INDEX nhdplus_navigation.tmp_navigation_working_pk;
DROP INDEX nhdplus_navigation.tmp_navigation_working_26i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_17i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_16i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_13i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_10i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_09i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_08i;
DROP INDEX nhdplus_navigation.tmp_navigation_working_03i;
DROP INDEX nhdplus_navigation.tmp_navigation_uptrib_pk;
DROP INDEX nhdplus_navigation.tmp_navigation_status_u01;
DROP INDEX nhdplus_navigation.tmp_navigation_results_u01;
DROP INDEX nhdplus_navigation.tmp_navigation_results_16i;
DROP INDEX nhdplus_navigation.tmp_navigation_results_13i;
DROP INDEX nhdplus_navigation.tmp_navigation_results_10i;
DROP INDEX nhdplus_navigation.tmp_navigation_results_09i;
DROP INDEX nhdplus_navigation.tmp_navigation_results_08i;
DROP INDEX nhdplus_navigation.tmp_navigation_results_03i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_pk2;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_pk;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_pk2;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_pk;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_21i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_16i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_13i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_10i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_09i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_dd_08i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_16i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_13i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_10i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_09i;
DROP INDEX nhdplus_navigation.tmp_navigation_connections_08i;
DROP INDEX nhdplus_navigation.prep_connections_ut_u01;
DROP INDEX nhdplus_navigation.prep_connections_ut_17i;
DROP INDEX nhdplus_navigation.prep_connections_ut_16i;
DROP INDEX nhdplus_navigation.prep_connections_ut_14i;
DROP INDEX nhdplus_navigation.prep_connections_ut_13i;
DROP INDEX nhdplus_navigation.prep_connections_ut_08i;
DROP INDEX nhdplus_navigation.prep_connections_um_u01;
DROP INDEX nhdplus_navigation.prep_connections_um_17i;
DROP INDEX nhdplus_navigation.prep_connections_um_16i;
DROP INDEX nhdplus_navigation.prep_connections_um_14i;
DROP INDEX nhdplus_navigation.prep_connections_um_13i;
DROP INDEX nhdplus_navigation.prep_connections_um_08i;
DROP INDEX nhdplus_navigation.prep_connections_dm_u01;
DROP INDEX nhdplus_navigation.prep_connections_dm_17i;
DROP INDEX nhdplus_navigation.prep_connections_dm_16i;
DROP INDEX nhdplus_navigation.prep_connections_dm_14i;
DROP INDEX nhdplus_navigation.prep_connections_dm_13i;
DROP INDEX nhdplus_navigation.prep_connections_dm_08i;
DROP INDEX nhdplus_navigation.prep_connections_dd_u01;
DROP INDEX nhdplus_navigation.prep_connections_dd_17i;
DROP INDEX nhdplus_navigation.prep_connections_dd_16i;
DROP INDEX nhdplus_navigation.prep_connections_dd_14i;
DROP INDEX nhdplus_navigation.prep_connections_dd_13i;
DROP INDEX nhdplus_navigation.prep_connections_dd_08i;
SET search_path = nhdplus, pg_catalog;

DROP INDEX nhdplus.r45_sde_rowid_uk;
DROP INDEX nhdplus.r43_sde_rowid_uk;
DROP INDEX nhdplus.r368_sde_rowid_uk;
DROP INDEX nhdplus.r34_sde_rowid_uk;
DROP INDEX nhdplus.r325_sde_rowid_uk;
DROP INDEX nhdplus.i973tocomid;
DROP INDEX nhdplus.i954streamlevel;
DROP INDEX nhdplus.i910permanent_id;
DROP INDEX nhdplus.i871navigable;
DROP INDEX nhdplus.i841upcomid;
DROP INDEX nhdplus.i835fcode;
DROP INDEX nhdplus.i82ftype;
DROP INDEX nhdplus.i818wbarea_perma;
DROP INDEX nhdplus.i814hydroseq;
DROP INDEX nhdplus.i757wbarea_nhdpl;
DROP INDEX nhdplus.i664tocomid;
DROP INDEX nhdplus.i655gnis_name;
DROP INDEX nhdplus.i648levelpathid;
DROP INDEX nhdplus.i638streamorder;
DROP INDEX nhdplus.i605nhdplus_comi;
DROP INDEX nhdplus.i603wbd_huc12;
DROP INDEX nhdplus.i576permanent_id;
DROP INDEX nhdplus.i556nhdplus_regi;
DROP INDEX nhdplus.i540wbarea_ftype;
DROP INDEX nhdplus.i52dncomid;
DROP INDEX nhdplus.i51streamlevel;
DROP INDEX nhdplus.i509nhdplus_regi;
DROP INDEX nhdplus.i468reachcode;
DROP INDEX nhdplus.i444nhdplus_regi_1;
DROP INDEX nhdplus.i442hydroseq;
DROP INDEX nhdplus.i427fcode;
DROP INDEX nhdplus.i398fromcomid;
DROP INDEX nhdplus.i387wbarea_fcode;
DROP INDEX nhdplus.i349reachcode;
DROP INDEX nhdplus.i325comid;
DROP INDEX nhdplus.i301gnis_id;
DROP INDEX nhdplus.i270nhdplus_regi;
DROP INDEX nhdplus.i206streamorder;
DROP INDEX nhdplus.i177terminalpath;
DROP INDEX nhdplus.i160catchment_fe;
DROP INDEX nhdplus.i12fromcomid;
DROP INDEX nhdplus.catchmentsp_the_geom_geom_idx;
DROP INDEX nhdplus.a162_ix1;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.databasechangeloglock DROP CONSTRAINT pk_databasechangeloglock;
SET search_path = nldi_data, pg_catalog;

ALTER TABLE ONLY nldi_data.crawler_source DROP CONSTRAINT crawler_source_pk;
SET search_path = nhdplus_navigation, pg_catalog;

ALTER TABLE ONLY nhdplus_navigation.tmp_navigation_status DROP CONSTRAINT tmp_navigation_status_pk;
ALTER TABLE ONLY nhdplus_navigation.tmp_navigation_results DROP CONSTRAINT tmp_navigation_results_pk2;
ALTER TABLE ONLY nhdplus_navigation.tmp_navigation_results DROP CONSTRAINT tmp_navigation_results_pk;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_ut DROP CONSTRAINT prep_connections_ut_pk2;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_ut DROP CONSTRAINT prep_connections_ut_pk;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_um DROP CONSTRAINT prep_connections_um_pk2;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_um DROP CONSTRAINT prep_connections_um_pk;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_dm DROP CONSTRAINT prep_connections_dm_pk2;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_dm DROP CONSTRAINT prep_connections_dm_pk;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_dd DROP CONSTRAINT prep_connections_dd_pk2;
ALTER TABLE ONLY nhdplus_navigation.prep_connections_dd DROP CONSTRAINT prep_connections_dd_pk;
SET search_path = nhdplus, pg_catalog;

ALTER TABLE ONLY nhdplus.catchmentsp DROP CONSTRAINT catchmentsp_pkey;
SET search_path = topology, pg_catalog;

SET search_path = public, pg_catalog;

SET search_path = nldi_data, pg_catalog;

SET search_path = nhdplus_navigation, pg_catalog;

SET search_path = nhdplus, pg_catalog;

ALTER TABLE nhdplus.catchmentsp ALTER COLUMN ogc_fid DROP DEFAULT;
SET search_path = public, pg_catalog;

DROP TABLE public.databasechangeloglock;
DROP TABLE public.databasechangelog;
SET search_path = nldi_data, pg_catalog;

DROP TABLE nldi_data.feature_wqp_temp;
DROP TABLE nldi_data.feature_wqp;
DROP TABLE nldi_data.feature;
DROP TABLE nldi_data.crawler_source;
SET search_path = nhdplus_navigation, pg_catalog;

DROP TABLE nhdplus_navigation.tmp_navigation_working;
DROP TABLE nhdplus_navigation.tmp_navigation_uptrib;
DROP SEQUENCE nhdplus_navigation.tmp_navigation_status_seq;
DROP TABLE nhdplus_navigation.tmp_navigation_status;
DROP SEQUENCE nhdplus_navigation.tmp_navigation_results_seq;
DROP TABLE nhdplus_navigation.tmp_navigation_results;
DROP TABLE nhdplus_navigation.tmp_navigation_connections_dd;
DROP TABLE nhdplus_navigation.tmp_navigation_connections;
DROP TABLE nhdplus_navigation.prep_connections_ut;
DROP TABLE nhdplus_navigation.prep_connections_um;
DROP TABLE nhdplus_navigation.prep_connections_dm;
DROP TABLE nhdplus_navigation.prep_connections_dd;
SET search_path = nhdplus, pg_catalog;

DROP TABLE nhdplus.plusflowlinevaa_np21;
DROP TABLE nhdplus.plusflow_np21;
DROP TABLE nhdplus.nhdplusconnect_np21;
DROP TABLE nhdplus.nhdflowline_np21;
DROP TABLE nhdplus.megadiv_np21;
DROP SEQUENCE nhdplus.catchmentsp_ogc_fid_seq;
DROP TABLE nhdplus.catchmentsp;
SET search_path = nhdplus_navigation, pg_catalog;

DROP FUNCTION nhdplus_navigation.temp_table_exists(p_table_name character varying);
DROP FUNCTION nhdplus_navigation.start_path_length(p_navigation_type character varying, p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_path_length numeric, p_divergence numeric, p_up_hydro_seq numeric, p_type character varying);
DROP FUNCTION nhdplus_navigation.reference_calculations(p_navigation_type character varying, p_start_measure numeric, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, OUT p_start_path_length numeric, OUT p_start_path_time numeric, OUT p_start_inc_dist numeric, OUT p_start_inc_time numeric);
DROP FUNCTION nhdplus_navigation.query_single_flowline(p_navigation_type character varying, p_comid integer, p_permanent_identifier character varying, p_hydrosequence numeric, p_reachcode character varying, p_measure numeric, p_check_intent character varying, OUT p_output flowline_rec, OUT p_check_comid integer, OUT p_check_permanent_identifier character varying, OUT p_check_measure numeric, OUT p_return_code numeric, OUT p_status_message character varying);
DROP FUNCTION nhdplus_navigation.prepare_working_table(p_navigation_type character varying, p_num_max_distance numeric, p_num_max_time numeric, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_start_path_length numeric, p_start_path_time numeric);
DROP FUNCTION nhdplus_navigation.navigate_vpu_core(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, psessionid character varying, pdebug character varying, OUT pcheckstartcomid integer, OUT pcheckstartpermanentidentifier character varying, OUT pcheckstartmeasure numeric, OUT pcheckstartpathlength numeric, OUT pcheckstartpathtime numeric, OUT pcheckstartincdist numeric, OUT pcheckstartinctime numeric, OUT pcheckstopcomid integer, OUT pcheckstoppermanentidentifier character varying, OUT pcheckstopmeasure numeric, OUT pcheckstopincdist numeric, OUT pcheckstopinctime numeric, OUT pcheckstopconditionmet numeric, OUT pcheckstartflowline flowline_rec, OUT pcheckstopflowline flowline_rec, OUT preturncode numeric, OUT pstatusmessage character varying);
DROP FUNCTION nhdplus_navigation.navigate_uptrib(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric);
DROP FUNCTION nhdplus_navigation.navigate_upmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric);
DROP FUNCTION nhdplus_navigation.navigate_dnmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_stop_comid integer, p_stop_measure numeric, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric, p_debug character varying);
DROP FUNCTION nhdplus_navigation.navigate_dndiv(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric);
DROP FUNCTION nhdplus_navigation.navigate(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, pdebug character varying, paddflowlineattributes character varying, paddflowlinegeometry character varying, OUT poutstartcomid integer, OUT poutstartmeasure numeric, OUT poutstopcomid integer, OUT poutstopmeasure numeric, OUT preturncode numeric, OUT pstatusmessage character varying, INOUT psessionid character varying);
DROP FUNCTION nhdplus_navigation.measure_at_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_distance numeric, p_half character varying);
DROP FUNCTION nhdplus_navigation.irc_up_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying);
DROP FUNCTION nhdplus_navigation.irc_down_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_start_comid integer, p_start_permanent_identifier character varying, p_start_measure numeric, p_stop_comid integer, p_stop_permanent_identifier character varying, p_stop_measure numeric, p_start_inc_dist numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying);
DROP FUNCTION nhdplus_navigation.included_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_half character varying);
DROP FUNCTION nhdplus_navigation.divergences(INOUT p_list_divs listdivs_rec[], INOUT p_divergence_count numeric);
DROP FUNCTION nhdplus_navigation.create_temp_tables();
DROP TYPE nhdplus_navigation.type_recdivs;
DROP TYPE nhdplus_navigation.typ_rec_mega_divergences;
DROP TYPE nhdplus_navigation.typ_connections;
DROP TYPE nhdplus_navigation.listdivs_rec;
DROP TYPE nhdplus_navigation.flowline_rec;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION postgis_topology;
DROP EXTENSION postgis;
DROP EXTENSION plpgsql;
DROP SCHEMA topology;
DROP SCHEMA public;
DROP SCHEMA nldi_data;
DROP SCHEMA nhdplus_navigation;
DROP SCHEMA nhdplus_indexing;
DROP SCHEMA nhdplus_delineation;
DROP SCHEMA nhdplus;
DROP SCHEMA catchmentsp_np21_uhi_topo;
DROP SCHEMA catchmentsp_np21_lpv_topo;
DROP SCHEMA catchmentsp_np21_acu_topo;
--
-- Name: catchmentsp_np21_acu_topo; Type: SCHEMA; Schema: -; Owner: nhdplus
--

CREATE SCHEMA catchmentsp_np21_acu_topo;


ALTER SCHEMA catchmentsp_np21_acu_topo OWNER TO nhdplus;

--
-- Name: catchmentsp_np21_lpv_topo; Type: SCHEMA; Schema: -; Owner: nhdplus
--

CREATE SCHEMA catchmentsp_np21_lpv_topo;


ALTER SCHEMA catchmentsp_np21_lpv_topo OWNER TO nhdplus;

--
-- Name: catchmentsp_np21_uhi_topo; Type: SCHEMA; Schema: -; Owner: nhdplus
--

CREATE SCHEMA catchmentsp_np21_uhi_topo;


ALTER SCHEMA catchmentsp_np21_uhi_topo OWNER TO nhdplus;

--
-- Name: nhdplus; Type: SCHEMA; Schema: -; Owner: nhdplus
--

CREATE SCHEMA nhdplus;


ALTER SCHEMA nhdplus OWNER TO nhdplus;

--
-- Name: nhdplus_delineation; Type: SCHEMA; Schema: -; Owner: nhdplus_delineation
--

CREATE SCHEMA nhdplus_delineation;


ALTER SCHEMA nhdplus_delineation OWNER TO nhdplus_delineation;

--
-- Name: nhdplus_indexing; Type: SCHEMA; Schema: -; Owner: nhdplus_indexing
--

CREATE SCHEMA nhdplus_indexing;


ALTER SCHEMA nhdplus_indexing OWNER TO nhdplus_indexing;

--
-- Name: nhdplus_navigation; Type: SCHEMA; Schema: -; Owner: nhdplus_navigation
--

CREATE SCHEMA nhdplus_navigation;


ALTER SCHEMA nhdplus_navigation OWNER TO nhdplus_navigation;

--
-- Name: nldi_data; Type: SCHEMA; Schema: -; Owner: nldi_data
--

CREATE SCHEMA nldi_data;


ALTER SCHEMA nldi_data OWNER TO nldi_data;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: nldi
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO nldi;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET search_path = nhdplus_navigation, pg_catalog;

--
-- Name: flowline_rec; Type: TYPE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TYPE flowline_rec AS (
	permanent_identifier character varying(40),
	nhdplus_comid integer,
	reachcode character varying(14),
	fmeasure numeric,
	tmeasure numeric,
	hydroseq integer,
	pathlength numeric,
	lengthkm numeric,
	length_measure_ratio numeric,
	pathtime numeric,
	travtime numeric,
	time_measure_ratio numeric,
	divergence integer,
	uphydroseq integer,
	uplevelpathid integer,
	dnhydroseq integer,
	dnlevelpathid integer,
	terminalpathid integer,
	levelpathid integer,
	nhdplus_region character varying(3),
	nhdplus_version character varying(6)
);


ALTER TYPE flowline_rec OWNER TO nhdplus_navigation;

--
-- Name: listdivs_rec; Type: TYPE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TYPE listdivs_rec AS (
	permanent_identifier character varying(40),
	nhdplus_comid integer,
	fmeasure numeric,
	tmeasure numeric,
	hydroseq integer,
	pathlength numeric,
	pathtime numeric,
	lengthkm numeric,
	travtime numeric,
	terminalpathid integer,
	levelpathid integer,
	uphydroseq integer,
	divergence integer,
	done integer,
	nhdplus_region character varying(3),
	nhdplus_version character varying(6)
);


ALTER TYPE listdivs_rec OWNER TO nhdplus_navigation;

--
-- Name: typ_connections; Type: TYPE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TYPE typ_connections AS (
	upcomid integer,
	dncomid integer,
	upunitid character varying(8),
	dnunitid character varying(8)
);


ALTER TYPE typ_connections OWNER TO nhdplus_navigation;

--
-- Name: typ_rec_mega_divergences; Type: TYPE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TYPE typ_rec_mega_divergences AS (
	fromcomid integer,
	comid integer,
	hydroseq integer
);


ALTER TYPE typ_rec_mega_divergences OWNER TO nhdplus_navigation;

--
-- Name: type_recdivs; Type: TYPE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TYPE type_recdivs AS (
	permanent_identifier character varying(40),
	nhdplus_comid integer,
	reachcode character varying(14),
	hydroseq integer,
	pathlength numeric,
	terminalpathid integer,
	levelpathid integer,
	uphydroseq integer,
	uplevelpathid integer,
	dnhydroseq integer,
	dnlevelpathid integer,
	dnminorhyd integer,
	divergence integer,
	dndraincount integer,
	frommeas numeric,
	tomeas numeric,
	lengthkm numeric,
	travtime numeric,
	pathtime numeric,
	selected integer,
	from1 numeric,
	to1 numeric,
	totaldist numeric,
	totaltime numeric,
	nhdplus_region character varying(3)
);


ALTER TYPE type_recdivs OWNER TO nhdplus_navigation;

--
-- Name: create_temp_tables(); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION create_temp_tables() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE

BEGIN
   
   ----------------------------------------------------------------------------
   -- Step 10
   -- Create tmp_navigation_connections temp table
   ----------------------------------------------------------------------------
   IF nhdplus_navigation.temp_table_exists('tmp_navigation_connections')
   THEN
      TRUNCATE TABLE tmp_navigation_connections;
      
   ELSE
      CREATE TEMPORARY TABLE tmp_navigation_connections(
          start_permanent_identifier  VARCHAR(40)
         ,permanent_identifier        VARCHAR(40)
         ,start_nhdplus_comid         INTEGER
         ,nhdplus_comid               INTEGER
         ,reachcode                   VARCHAR(14)
         ,fmeasure                    NUMERIC
         ,tmeasure                    NUMERIC
         ,totaldist                   NUMERIC
         ,totaltime                   NUMERIC
         ,hydroseq                    INTEGER
         ,levelpathid                 INTEGER
         ,terminalpathid              INTEGER
         ,uphydroseq                  INTEGER
         ,dnhydroseq                  INTEGER
         ,pathlength                  NUMERIC
         ,lengthkm                    NUMERIC
         ,length_measure_ratio        NUMERIC
         ,pathtime                    NUMERIC
         ,travtime                    NUMERIC
         ,time_measure_ratio          NUMERIC
         ,ofmeasure                   NUMERIC
         ,otmeasure                   NUMERIC
         ,nhdplus_region              VARCHAR(3)
         ,nhdplus_version             VARCHAR(6)
         ,reachsmdate                 DATE
         ,ftype                       INTEGER
         ,fcode                       INTEGER
         ,gnis_id                     VARCHAR(10)
         ,wbarea_permanent_identifier VARCHAR(40)
         ,wbarea_nhdplus_comid        INTEGER
         ,wbd_huc12                   VARCHAR(12)
         ,catchment_featureid         INTEGER
         ,shape                       geometry
      );

      CREATE UNIQUE INDEX tmp_navigation_connections_pk 
      ON tmp_navigation_connections(permanent_identifier);
      
      CREATE UNIQUE INDEX tmp_navigation_connections_pk2 
      ON tmp_navigation_connections(nhdplus_comid);

      CREATE INDEX tmp_navigation_connections_08i 
      ON tmp_navigation_connections(hydroseq);

      CREATE INDEX tmp_navigation_connections_09i 
      ON tmp_navigation_connections(levelpathid);

      CREATE INDEX tmp_navigation_connections_10i 
      ON tmp_navigation_connections(terminalpathid);

      CREATE INDEX tmp_navigation_connections_13i 
      ON tmp_navigation_connections(pathlength);

      CREATE INDEX tmp_navigation_connections_16i 
      ON tmp_navigation_connections(pathtime);

   END IF;

   ----------------------------------------------------------------------------
   -- Step 20
   -- Create tmp_navigation_connections_dd temp table
   ----------------------------------------------------------------------------
   IF nhdplus_navigation.temp_table_exists('tmp_navigation_connections_dd')
   THEN
      TRUNCATE TABLE tmp_navigation_connections_dd;
      
   ELSE
      CREATE TEMPORARY TABLE tmp_navigation_connections_dd(
          start_permanent_identifier  VARCHAR(40)
         ,permanent_identifier        VARCHAR(40)
         ,start_nhdplus_comid         INTEGER
         ,nhdplus_comid               INTEGER
         ,reachcode                   VARCHAR(14)
         ,fmeasure                    NUMERIC
         ,tmeasure                    NUMERIC
         ,totaldist                   NUMERIC
         ,totaltime                   NUMERIC
         ,hydroseq                    INTEGER
         ,levelpathid                 INTEGER
         ,terminalpathid              INTEGER
         ,uphydroseq                  INTEGER
         ,dnhydroseq                  INTEGER
         ,pathlength                  NUMERIC
         ,lengthkm                    NUMERIC
         ,length_measure_ratio        NUMERIC
         ,pathtime                    NUMERIC
         ,travtime                    NUMERIC
         ,time_measure_ratio          NUMERIC
         ,ofmeasure                   NUMERIC
         ,otmeasure                   NUMERIC
         ,processed                   NUMERIC(11)
         ,nhdplus_region              VARCHAR(3)
         ,nhdplus_version             VARCHAR(6)
         ,reachsmdate                 DATE
         ,ftype                       NUMERIC(3)
         ,fcode                       NUMERIC(5)
         ,gnis_id                     VARCHAR(10)
         ,wbarea_permanent_identifier VARCHAR(40)
         ,wbarea_nhdplus_comid        INTEGER
         ,wbd_huc12                   VARCHAR(12)
         ,catchment_featureid         INTEGER
         ,shape                       geometry
      );

      CREATE UNIQUE INDEX tmp_navigation_connections_dd_pk
      ON tmp_navigation_connections_dd(permanent_identifier);
      
      CREATE UNIQUE INDEX tmp_navigation_connections_dd_pk2
      ON tmp_navigation_connections_dd(nhdplus_comid);

      CREATE INDEX tmp_navigation_connections_dd_08i 
      ON tmp_navigation_connections_dd(hydroseq);

      CREATE INDEX tmp_navigation_connections_dd_09i 
      ON tmp_navigation_connections_dd(levelpathid);

      CREATE INDEX tmp_navigation_connections_dd_10i 
      ON tmp_navigation_connections_dd(terminalpathid);

      CREATE INDEX tmp_navigation_connections_dd_13i 
      ON tmp_navigation_connections_dd(pathlength);

      CREATE INDEX tmp_navigation_connections_dd_16i 
      ON tmp_navigation_connections_dd(pathtime);

      CREATE INDEX tmp_navigation_connections_dd_21i 
      ON tmp_navigation_connections_dd(processed);
      
   END IF;
   
   ----------------------------------------------------------------------------
   -- Step 30
   -- Create tmp_navigation_uptrib temp table
   ----------------------------------------------------------------------------
   IF nhdplus_navigation.temp_table_exists('tmp_navigation_uptrib')
   THEN
      TRUNCATE TABLE tmp_navigation_uptrib;
      
   ELSE
      CREATE TEMPORARY TABLE tmp_navigation_uptrib(
          fromlevelpathid             INTEGER
         ,minhs                       INTEGER
      );

      CREATE UNIQUE INDEX tmp_navigation_uptrib_pk
      ON tmp_navigation_uptrib(fromlevelpathid);

   END IF;
   
   ----------------------------------------------------------------------------
   -- Step 40
   -- Create tmp_navigation_working temp table
   ----------------------------------------------------------------------------
   IF nhdplus_navigation.temp_table_exists('tmp_navigation_working')
   THEN
      TRUNCATE TABLE tmp_navigation_working;
      
   ELSE
      CREATE TEMPORARY TABLE tmp_navigation_working(
          start_permanent_identifier  VARCHAR(40)
         ,permanent_identifier        VARCHAR(40)
         ,start_nhdplus_comid         INTEGER
         ,nhdplus_comid               INTEGER
         ,reachcode                   VARCHAR(14)
         ,fmeasure                    NUMERIC
         ,tmeasure                    NUMERIC
         ,totaldist                   NUMERIC
         ,totaltime                   NUMERIC
         ,hydroseq                    INTEGER
         ,levelpathid                 INTEGER
         ,terminalpathid              INTEGER
         ,uphydroseq                  INTEGER
         ,uplevelpathid               INTEGER
         ,dnhydroseq                  INTEGER
         ,dnlevelpathid               INTEGER
         ,dnminorhyd                  INTEGER
         ,divergence                  INTEGER
         ,dndraincount                INTEGER
         ,pathlength                  NUMERIC
         ,lengthkm                    NUMERIC
         ,length_measure_ratio        NUMERIC
         ,pathtime                    NUMERIC
         ,travtime                    NUMERIC
         ,time_measure_ratio          NUMERIC
         ,ofmeasure                   NUMERIC
         ,otmeasure                   NUMERIC
         ,selected                    INTEGER
         ,nhdplus_region              VARCHAR(3)
         ,nhdplus_version             VARCHAR(6)
         ,reachsmdate                 DATE
      );

      CREATE UNIQUE INDEX tmp_navigation_working_pk
      ON tmp_navigation_working(permanent_identifier);
      
      CREATE UNIQUE INDEX tmp_navigation_working_pk2
      ON tmp_navigation_working(permanent_identifier);

      CREATE INDEX tmp_navigation_working_03i 
      ON tmp_navigation_working(reachcode);

      CREATE INDEX tmp_navigation_working_08i 
      ON tmp_navigation_working(hydroseq);
      
      CREATE INDEX tmp_navigation_working_09i 
      ON tmp_navigation_working(levelpathid);

      CREATE INDEX tmp_navigation_working_10i 
      ON tmp_navigation_working(terminalpathid);

      CREATE INDEX tmp_navigation_working_13i 
      ON tmp_navigation_working(pathlength);

      CREATE INDEX tmp_navigation_working_16i 
      ON tmp_navigation_working(pathtime);

      CREATE INDEX tmp_navigation_working_17i 
      ON tmp_navigation_working(dndraincount);

      CREATE INDEX tmp_navigation_working_26i 
      ON tmp_navigation_working(selected);

   END IF;

   ----------------------------------------------------------------------------
   -- Step 70
   -- I guess that went okay
   ----------------------------------------------------------------------------
   RETURN 0;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.create_temp_tables() OWNER TO nhdplus_navigation;

--
-- Name: divergences(listdivs_rec[], numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION divergences(INOUT p_list_divs listdivs_rec[], INOUT p_divergence_count numeric) RETURNS record
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   int_found            INTEGER;
   int_temp             INTEGER;
   rec_divergences      nhdplus_navigation.type_recdivs;
   rec_flowline         nhdplus_navigation.flowline_rec;
   rec_mega_divergences nhdplus_navigation.typ_rec_mega_divergences;
   str_status_message   VARCHAR(4000);
   num_return_code      NUMERIC;
   str_dummy            VARCHAR(4000);
   int_dummy            INTEGER;
   num_dummy            NUMERIC;
   r                    RECORD;
   
   curs_divergences CURSOR FOR
   SELECT 
    a.permanent_identifier
   ,a.nhdplus_comid
   ,a.reachcode
   ,a.hydroseq
   ,a.pathlength
   ,a.terminalpathid
   ,a.levelpathid
   ,a.uphydroseq
   ,a.uplevelpathid
   ,a.dnhydroseq
   ,a.dnlevelpathid
   ,a.dnminorhyd
   ,a.divergence
   ,a.dndraincount
   ,a.fmeasure
   ,a.tmeasure
   ,a.lengthkm
   ,a.travtime
   ,a.pathtime
   ,a.selected
   ,a.ofmeasure
   ,a.otmeasure
   ,a.totaldist
   ,a.totaltime 
   ,a.nhdplus_region
   FROM 
   tmp_navigation_working a 
   WHERE 
       a.selected     =  1 
   AND a.dndraincount >= 2 
   ORDER BY 
   a.hydroseq DESC;
   
   curs_mega_divergences CURSOR(
      p_comid INTEGER
   ) IS
   SELECT 
    a.fromcomid
   ,b.nhdplus_comid
   ,b.hydroseq 
   FROM 
   nhdplus.megadiv_np21 a
   JOIN
   tmp_navigation_working b
   ON
   a.tocomid = b.nhdplus_comid
   WHERE 
   a.fromcomid = p_comid 
   ORDER BY 
   b.hydroseq DESC;

BEGIN

   OPEN curs_divergences;
   LOOP
      FETCH curs_divergences INTO rec_divergences;
      IF NOT FOUND
      THEN
         EXIT;
         
      END IF;

      IF rec_divergences.dndraincount = 2
      THEN
         --two outflows
         --See if the minor downstream hs exists in the list already
         int_temp := rec_divergences.dnminorhyd;
         int_found := 0;

         IF p_list_divs IS NOT NULL
         AND array_length(p_list_divs,1) > 0
         THEN
            FOR i IN 1 .. array_length(p_list_divs,1)
            LOOP
               IF p_list_divs[i].hydroseq = int_temp
               THEN
                  int_found := 1;
                     
               END IF;
                  
            END LOOP;
            
         END IF;

         --If not - add it
         IF int_found = 0
         THEN
            --HS does not exist - so add
            r := nhdplus_navigation.query_single_flowline(
                p_navigation_type      := 'DM'
               ,p_comid                := NULL
               ,p_permanent_identifier := NULL
               ,p_hydrosequence        := int_temp
               ,p_reachcode            := NULL
               ,p_measure              := NULL
               ,p_check_intent         := NULL
            );
            rec_flowline       := r.p_output;
            int_dummy          := r.p_check_comid;
            num_dummy          := r.p_check_measure;
            num_return_code    := r.p_return_code;
            str_status_message := r.p_status_message;
            
            IF rec_flowline.nhdplus_comid IS NOT NULL
            THEN
               p_divergence_count := p_divergence_count + 1;
               
               p_list_divs[p_divergence_count] := (
                   rec_flowline.permanent_identifier -- permanent_identifier
                  ,rec_flowline.nhdplus_comid
                  ,rec_flowline.fmeasure         -- fmeasure
                  ,rec_flowline.tmeasure         -- tmeasure
                  ,rec_flowline.hydroseq         -- hydroseq
                  ,rec_flowline.pathlength       -- pathlength
                  ,rec_flowline.pathtime         -- pathtime
                  ,rec_flowline.lengthkm         -- lengthkm
                  ,rec_flowline.travtime         -- travtime
                  ,rec_flowline.terminalpathid   -- terminalpathid   
                  ,rec_flowline.levelpathid      -- levelpathid
                  ,rec_flowline.uphydroseq       -- uphydroseq
                  ,rec_flowline.divergence       -- divergence
                  ,0                             -- done
                  ,rec_flowline.nhdplus_region   -- nhdplus_region
                  ,rec_flowline.nhdplus_version  -- nhdplus_version
               )::nhdplus_navigation.listdivs_rec;
               
            END IF;
            
         END IF;
         
      ELSE
         OPEN curs_mega_divergences(
            rec_divergences.nhdplus_comid
         );

         LOOP
            FETCH curs_mega_divergences INTO rec_mega_divergences;
            EXIT WHEN NOT FOUND;

            r := nhdplus_navigation.query_single_flowline(
                p_navigation_type      := 'DM'
               ,p_comid                := rec_mega_divergences.comid
               ,p_permanent_identifier := NULL
               ,p_hydrosequence        := NULL
               ,p_reachcode            := NULL
               ,p_measure              := NULL
               ,p_check_intent         := NULL
            );
            rec_flowline       := r.p_output;
            num_return_code    := r.p_return_code;
            str_status_message := r.p_status_message;

            IF rec_flowline.nhdplus_comid IS NOT NULL
            THEN
               --See if the divergence exists in the list already
               int_temp  := rec_flowline.hydroseq;
               int_found := 0;
               
               IF p_list_divs IS NOT NULL
               AND array_length(p_list_divs,1) > 0
               THEN
                  FOR i IN 1 .. array_length(p_list_divs,1)
                  LOOP
                     IF p_list_divs[i].hydroseq = int_temp
                     THEN
                        int_found := 1;
                           
                     END IF;
                        
                  END LOOP;
                  
               END IF;

               IF int_found = 0
               THEN
                  --See if the divergence has already been navigated
                  SELECT 
                  a.selected 
                  INTO int_temp
                  FROM 
                  tmp_navigation_working a 
                  WHERE 
                  a.hydroseq = rec_flowline.hydroseq;

                  IF int_temp >= 1
                  THEN
                     int_found := 1;
                     
                  END IF;

               END IF;

               --If not - add it
               IF int_found = 0
               THEN
                  p_divergence_count := p_divergence_count + 1;
                  p_list_divs[p_divergence_count] := (
                      rec_flowline.permanent_identifier -- permanent_identifier
                     ,rec_flowline.nhdplus_comid        -- nhdplus_comid
                     ,rec_flowline.fmeasure             -- fmeasure
                     ,rec_flowline.tmeasure             -- tmeasure
                     ,rec_flowline.hydroseq             -- hydroseq
                     ,rec_flowline.pathlength           -- pathlength
                     ,rec_flowline.pathtime             -- pathtime
                     ,rec_flowline.lengthkm             -- lengthkm
                     ,rec_flowline.travtime             -- travtime
                     ,rec_flowline.terminalpathid       -- terminalpathid   
                     ,rec_flowline.levelpathid          -- levelpathid
                     ,rec_flowline.uphydroseq           -- uphydroseq
                     ,rec_flowline.divergence           -- divergence
                     ,0                                 -- done
                     ,rec_flowline.nhdplus_region       -- nhdplus_region
                     ,rec_flowline.nhdplus_version      -- nhdplus_version
                  )::nhdplus_navigation.listdivs_rec;
                  
               END IF;
               
            ELSE
               NULL;
               
            END IF;
            
         END LOOP;

         CLOSE curs_mega_divergences;

      END IF;

   END LOOP;

   CLOSE curs_divergences;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.divergences(INOUT p_list_divs listdivs_rec[], INOUT p_divergence_count numeric) OWNER TO nhdplus_navigation;

--
-- Name: included_distance(numeric, numeric, numeric, numeric, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION included_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_half character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   num_distance NUMERIC;
   str_half     VARCHAR(4000) := UPPER(p_half);
   
BEGIN
   -- Calculate Included Distance  
   -- (determine the distance along this permid to be included in the navigation)
   -- tmeasure - references the to measure which will actually be the from point of nhdflowline.
   -- fmeasure - references the from measure which will actually be the to point of nhdflowline.
   -- X is the measure supplied by the user
   -- Arrows indicate coordinate ordering - which is in agreement with the flow table

   --NHDFlowline C:   A(tmeasure)--->---X------>----->-----B(fmeasure)

   --Distance from A to X is the 'TOP'   (will need to be included in upstream navigations)
   --Distance from X to B is the 'BOTTOM' (will need to be included in downstream navigations)

   num_distance := p_length * ((p_tmeasure - p_measure) / (p_tmeasure - p_fmeasure));

   IF str_half = 'TOP'
   THEN
      RETURN num_distance;
      
   ELSIF str_half = 'BOTTOM'
   THEN
      RETURN p_length - num_distance;
   
   ELSE
      RAISE EXCEPTION 'err';
      
   END IF;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.included_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_half character varying) OWNER TO nhdplus_navigation;

--
-- Name: irc_down_processing(character varying, flowline_rec, flowline_rec, numeric, numeric, numeric, numeric, integer, character varying, numeric, integer, character varying, numeric, numeric, character varying, character varying, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION irc_down_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_start_comid integer, p_start_permanent_identifier character varying, p_start_measure numeric, p_stop_comid integer, p_stop_permanent_identifier character varying, p_stop_measure numeric, p_start_inc_dist numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   ary_used_comids     INTEGER[];
   num_used            NUMERIC := 0;
   num_found           INTEGER;
   num_inserted        INTEGER;
   boo_continue        BOOLEAN := TRUE;
   num_did_insertions  INTEGER := 0;
   num_updated         INTEGER;
   num_iterations      INTEGER;
   num_min_hydro_seq   INTEGER;
   num_W_path_length   NUMERIC;
   num_W_lengthkm      NUMERIC;
   num_W_tomeas        NUMERIC;
   num_W_frommeas      NUMERIC;
   num_W_calc_meas     NUMERIC;
   num_W_calc_dis      NUMERIC;
   num_W_calc_time     NUMERIC;
   num_W_path_time     NUMERIC;
   num_W_trav_time     NUMERIC;
   rec_connections     nhdplus_navigation.typ_connections;
   num_check           NUMERIC;
   
   curs_connections CURSOR(
      p_session_id  VARCHAR
   )
   IS
   SELECT DISTINCT 
    a.upcomid
   ,a.dncomid
   ,a.upunitid
   ,a.dnunitid 
   FROM 
   nhdplus.nhdplusconnect_np21 a
   JOIN
   nhdplus_navigation.tmp_navigation_results b
   ON
   a.upcomid = b.nhdplus_comid
   WHERE
   b.session_id = p_session_id;

BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   --------------------------------------------------------------------------
   
   --------------------------------------------------------------------------
   -- Step 20
   -- Bail if we are able
   --------------------------------------------------------------------------
   SELECT 
   COUNT(*)
   INTO num_check
   FROM
   nhdplus.nhdplusconnect_np21 a
   WHERE
       a.upunitid = p_start_flowline.nhdplus_region
   AND a.upunittype = 'VPU';
   
   IF num_check = 0
   THEN
      RETURN 0;
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 20
   -- Update totals before checking for connections
   --------------------------------------------------------------------------
   UPDATE nhdplus_navigation.tmp_navigation_results a 
   SET 
   totaldist = p_start_path_length - a.pathlength 
   WHERE 
       a.session_id = p_session_id
   AND a.totaldist IS NULL;

   UPDATE nhdplus_navigation.tmp_navigation_results a 
   SET 
   totaltime = p_start_path_time - a.pathtime 
   WHERE 
       a.session_id = p_session_id
   AND a.totaltime IS NULL;

   UPDATE nhdplus_navigation.tmp_navigation_results a 
   SET 
    tmeasure  = p_start_measure
   ,totaldist = p_start_inc_dist
   WHERE 
       a.session_id = p_session_id
   AND a.nhdplus_comid = p_start_comid;

   --------------------------------------------------------------------------
   -- Step 30
   -- Populate results table going down
   -- Do this until there are no more inserts from the prenavigated data
   --------------------------------------------------------------------------
   WHILE boo_continue
   LOOP
      boo_continue := FALSE;

      OPEN curs_connections(p_session_id);

      LOOP
         FETCH curs_connections INTO rec_connections;
         EXIT WHEN NOT FOUND;

         num_found := 0;

         IF ary_used_comids IS NOT NULL
         AND array_length(ary_used_comids,1) > 0
         THEN
            FOR i IN 1 .. array_length(ary_used_comids,1)
            LOOP
               IF ary_used_comids[i] = rec_connections.dncomid
               THEN
                  num_found := 1;
                  
               END IF;
                  
            END LOOP;
            
         END IF;

         IF num_found = 0
         THEN
            -- IRC connection has not yet been included in the results.  
            -- Add the approproate dnmain recults to a temp file.
            IF p_num_max_distance IS NOT NULL
            THEN
               INSERT INTO tmp_navigation_connections(
                   start_permanent_identifier
                  ,permanent_identifier
                  ,start_nhdplus_comid
                  ,nhdplus_comid
                  ,reachcode
                  ,fmeasure
                  ,tmeasure
                  ,totaldist
                  ,totaltime
                  ,hydroseq
                  ,levelpathid
                  ,terminalpathid
                  ,uphydroseq
                  ,dnhydroseq
                  ,pathlength
                  ,lengthkm
                  ,length_measure_ratio
                  ,pathtime
                  ,travtime
                  ,time_measure_ratio
                  ,ofmeasure
                  ,otmeasure
                  ,nhdplus_region
                  ,nhdplus_version
                  ,reachsmdate
                  ,ftype
                  ,fcode
                  ,gnis_id
                  ,wbarea_permanent_identifier
                  ,wbarea_nhdplus_comid
                  ,wbd_huc12
                  ,catchment_featureid
                  ,shape 
               ) 
               SELECT 
                a.start_permanent_identifier
               ,a.permanent_identifier
               ,a.start_nhdplus_comid
               ,a.nhdplus_comid
               ,a.reachcode
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS totaldist
               ,NULL AS totaltime
               ,a.hydroseq
               ,a.levelpathid
               ,a.terminalpathid
               ,a.uphydroseq
               ,a.dnhydroseq
               ,a.pathlength
               ,a.lengthkm
               ,a.length_measure_ratio
               ,a.pathtime
               ,a.travtime
               ,a.time_measure_ratio
               ,a.fmeasure
               ,a.tmeasure
               ,a.nhdplus_region
               ,a.nhdplus_version
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.reachsmdate
                ELSE
                   NULL
                END 
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.ftype
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.fcode
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.gnis_id
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_permanent_identifier
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_nhdplus_comid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbd_huc12
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.catchment_featureid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                AND p_add_flowline_geometry = 'TRUE'
                THEN
                   a.shape
                ELSE
                   NULL
                END
               FROM 
               nhdplus_navigation.prep_connections_dm a 
               WHERE 
                   a.start_nhdplus_comid = rec_connections.dncomid
               AND a.pathlength + a.lengthkm >= p_start_path_length - p_num_max_distance
               AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
               ORDER BY 
               a.hydroseq DESC;
               
               GET DIAGNOSTICS num_inserted = ROW_COUNT;

            ELSIF p_num_max_time IS NOT NULL
            THEN
               INSERT INTO tmp_navigation_connections(
                   start_permanent_identifier
                  ,permanent_identifier
                  ,start_nhdplus_comid
                  ,nhdplus_comid
                  ,reachcode
                  ,fmeasure
                  ,tmeasure
                  ,totaldist
                  ,totaltime
                  ,hydroseq
                  ,levelpathid
                  ,terminalpathid
                  ,uphydroseq
                  ,dnhydroseq
                  ,pathlength
                  ,lengthkm
                  ,length_measure_ratio
                  ,pathtime
                  ,travtime
                  ,time_measure_ratio
                  ,ofmeasure
                  ,otmeasure
                  ,nhdplus_region
                  ,nhdplus_version
                  ,reachsmdate
                  ,ftype
                  ,fcode
                  ,gnis_id
                  ,wbarea_permanent_identifier
                  ,wbarea_nhdplus_comid
                  ,wbd_huc12
                  ,catchment_featureid
                  ,shape 
               ) 
               SELECT 
                a.start_permanent_identifier
               ,a.permanent_identifier
               ,a.start_nhdplus_comid
               ,a.nhdplus_comid
               ,a.reachcode
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS totaldist
               ,NULL AS totaltime
               ,a.hydroseq
               ,a.levelpathid
               ,a.terminalpathid
               ,a.uphydroseq
               ,a.dnhydroseq
               ,a.pathlength
               ,a.lengthkm
               ,a.length_measure_ratio
               ,a.pathtime
               ,a.travtime
               ,a.time_measure_ratio
               ,a.fmeasure
               ,a.tmeasure
               ,a.nhdplus_region
               ,a.nhdplus_version
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.reachsmdate
                ELSE
                   NULL
                END 
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.ftype
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.fcode
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.gnis_id
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_permanent_identifier
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_nhdplus_comid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbd_huc12
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.catchment_featureid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                AND p_add_flowline_geometry = 'TRUE'
                THEN
                   a.shape
                ELSE
                   NULL
                END
               FROM 
               nhdplus_navigation.prep_connections_dm a 
               WHERE 
                   a.start_nhdplus_comid = rec_connections.dncomid 
               AND a.pathtime + a.travtime >= p_start_path_time - p_num_max_time 
               AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
               ORDER BY 
               a.hydroseq DESC;
               
               GET DIAGNOSTICS num_inserted = ROW_COUNT;

            ELSIF p_navigation_type = 'PP'
            THEN
               INSERT INTO tmp_navigation_connections(
                   start_permanent_identifier
                  ,permanent_identifier
                  ,start_nhdplus_comid
                  ,nhdplus_comid
                  ,reachcode
                  ,fmeasure
                  ,tmeasure
                  ,totaldist
                  ,totaltime
                  ,hydroseq
                  ,levelpathid
                  ,terminalpathid
                  ,uphydroseq
                  ,dnhydroseq
                  ,pathlength
                  ,lengthkm
                  ,length_measure_ratio
                  ,pathtime
                  ,travtime
                  ,time_measure_ratio
                  ,ofmeasure
                  ,otmeasure
                  ,nhdplus_region
                  ,nhdplus_version
                  ,reachsmdate
                  ,ftype
                  ,fcode
                  ,gnis_id
                  ,wbarea_permanent_identifier
                  ,wbarea_nhdplus_comid
                  ,wbd_huc12
                  ,catchment_featureid
                  ,shape 
               ) 
               SELECT 
                a.start_permanent_identifier
               ,a.permanent_identifier
               ,a.start_nhdplus_comid
               ,a.nhdplus_comid
               ,a.reachcode
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS totaldist
               ,NULL AS totaltime
               ,a.hydroseq
               ,a.levelpathid
               ,a.terminalpathid
               ,a.uphydroseq
               ,a.dnhydroseq
               ,a.pathlength
               ,a.lengthkm
               ,a.length_measure_ratio
               ,a.pathtime
               ,a.travtime
               ,a.time_measure_ratio
               ,a.fmeasure
               ,a.tmeasure
               ,a.nhdplus_region
               ,a.nhdplus_version
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.reachsmdate
                ELSE
                   NULL
                END 
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.ftype
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.fcode
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.gnis_id
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_permanent_identifier
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_nhdplus_comid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbd_huc12
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.catchment_featureid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                AND p_add_flowline_geometry = 'TRUE'
                THEN
                   a.shape
                ELSE
                   NULL
                END
               FROM 
               nhdplus_navigation.prep_connections_dm a
               WHERE 
                   a.start_nhdplus_comid = rec_connections.dncomid
               AND a.hydroseq >= p_stop_flowline.hydroseq
               ORDER BY 
               a.hydroseq DESC;
               
               GET DIAGNOSTICS num_inserted = ROW_COUNT;
               
            ELSE
               INSERT INTO tmp_navigation_connections(
                   start_permanent_identifier
                  ,permanent_identifier
                  ,start_nhdplus_comid
                  ,nhdplus_comid
                  ,reachcode
                  ,fmeasure
                  ,tmeasure
                  ,totaldist
                  ,totaltime
                  ,hydroseq
                  ,levelpathid
                  ,terminalpathid
                  ,uphydroseq
                  ,dnhydroseq
                  ,pathlength
                  ,lengthkm
                  ,length_measure_ratio
                  ,pathtime
                  ,travtime
                  ,time_measure_ratio
                  ,ofmeasure
                  ,otmeasure
                  ,nhdplus_region
                  ,nhdplus_version
                  ,reachsmdate
                  ,ftype
                  ,fcode
                  ,gnis_id
                  ,wbarea_permanent_identifier
                  ,wbarea_nhdplus_comid
                  ,wbd_huc12
                  ,catchment_featureid
                  ,shape 
               ) 
               SELECT 
                a.start_permanent_identifier
               ,a.permanent_identifier
               ,a.start_nhdplus_comid
               ,a.nhdplus_comid
               ,a.reachcode
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS totaldist
               ,NULL AS totaltime
               ,a.hydroseq
               ,a.levelpathid
               ,a.terminalpathid
               ,a.uphydroseq
               ,a.dnhydroseq
               ,a.pathlength
               ,a.lengthkm
               ,a.length_measure_ratio
               ,a.pathtime
               ,a.travtime
               ,a.time_measure_ratio
               ,a.fmeasure
               ,a.tmeasure
               ,a.nhdplus_region
               ,a.nhdplus_version
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.reachsmdate
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.ftype
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.fcode
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.gnis_id
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_permanent_identifier
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_nhdplus_comid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbd_huc12
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.catchment_featureid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                AND p_add_flowline_geometry = 'TRUE'
                THEN
                   a.shape
                ELSE
                   NULL
                END
               FROM 
               nhdplus_navigation.prep_connections_dm a 
               WHERE 
               a.start_nhdplus_comid = rec_connections.dncomid
               ORDER BY 
               a.hydroseq DESC;
               
               GET DIAGNOSTICS num_inserted = ROW_COUNT;

            END IF;

            IF num_inserted > 0
            THEN
               num_did_insertions := 1;
               boo_continue := TRUE;
               
            END IF;

            IF p_navigation_type = 'DD'
            THEN
               --Now add the dndiv results to a separate temp file, it necessary.
               --insert into temptable2 the dndiv nagivation results for the current tocomid
               INSERT INTO tmp_navigation_connections_dd(
                   start_permanent_identifier
                  ,permanent_identifier
                  ,start_nhdplus_comid
                  ,nhdplus_comid
                  ,reachcode
                  ,fmeasure
                  ,tmeasure
                  ,totaldist
                  ,totaltime
                  ,hydroseq
                  ,levelpathid
                  ,terminalpathid
                  ,uphydroseq
                  ,dnhydroseq
                  ,pathlength
                  ,lengthkm
                  ,length_measure_ratio
                  ,pathtime
                  ,travtime
                  ,time_measure_ratio
                  ,ofmeasure
                  ,otmeasure
                  ,processed
                  ,nhdplus_region
                  ,nhdplus_version
                  ,reachsmdate
                  ,ftype
                  ,fcode
                  ,gnis_id
                  ,wbarea_permanent_identifier
                  ,wbarea_nhdplus_comid
                  ,wbd_huc12
                  ,catchment_featureid
                  ,shape
               ) 
               SELECT 
                a.start_permanent_identifier
               ,a.permanent_identifier
               ,a.start_nhdplus_comid
               ,a.nhdplus_comid
               ,a.reachcode
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS totaldist
               ,NULL AS totaltime
               ,a.hydroseq
               ,a.levelpathid
               ,a.terminalpathid
               ,a.uphydroseq
               ,a.dnhydroseq
               ,a.pathlength
               ,a.lengthkm
               ,a.length_measure_ratio
               ,a.pathtime
               ,a.travtime
               ,a.time_measure_ratio
               ,a.fmeasure
               ,a.tmeasure
               ,NULL AS processed
               ,a.nhdplus_region
               ,a.nhdplus_version
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.reachsmdate
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.ftype
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.fcode
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.gnis_id
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_permanent_identifier
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbarea_nhdplus_comid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.wbd_huc12
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                THEN
                   a.catchment_featureid
                ELSE
                   NULL
                END
               ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                AND p_add_flowline_geometry = 'TRUE'
                THEN
                   a.shape
                ELSE
                   NULL
                END
               FROM 
               nhdplus_navigation.prep_connections_dd a 
               WHERE 
               a.start_nhdplus_comid = rec_connections.dncomid
               ORDER BY
               a.hydroseq DESC;
               
               --Update total time and total distance along the main path in the connecting workspace.
               UPDATE tmp_navigation_connections a 
               SET 
               totaldist = p_start_path_length - a.pathlength 
               WHERE 
               a.totaldist IS NULL;

               --Populate totaltime field in navigation results table
               UPDATE tmp_navigation_connections a 
               SET 
               totaltime = p_start_path_time - a.pathtime 
               WHERE 
               a.totaltime IS NULL;

               --Update to1,totaldist of start record (based on user supplied startmeas)
               UPDATE tmp_navigation_connections a 
               SET 
                tmeasure  = p_start_measure
               ,totaldist = p_start_inc_dist
               WHERE 
               a.nhdplus_comid = p_start_comid;
               
               --Remove all comids in temptable2 that are along the main path.
               DELETE FROM tmp_navigation_connections_dd a 
               WHERE 
               EXISTS (
                  SELECT 
                  1 
                  FROM 
                  tmp_navigation_connections b 
                  WHERE 
                  a.nhdplus_comid = b.nhdplus_comid
               );

               --temptable2 will now contain ONLY the divergent paths
               --need to fill totaldist and totaltime along these paths.

               --fill the totaltime and totaldist for the top hydroseq of each divergent path.

               num_iterations := 1;
               UPDATE tmp_navigation_connections_dd a 
               SET 
                processed = num_iterations
               ,totaldist = a.lengthkm + (
                   SELECT DISTINCT 
                   b.totaldist 
                   FROM 
                   tmp_navigation_connections b 
                   WHERE 
                   a.uphydroseq = b.hydroseq 
                )
               ,totaltime = a.travtime + (
                   SELECT DISTINCT 
                   totaltime 
                   FROM 
                   tmp_navigation_connections c 
                   WHERE 
                   a.uphydroseq = c.hydroseq 
                ) 
               WHERE EXISTS (
                  SELECT 
                  1 
                  FROM 
                  tmp_navigation_connections d 
                  WHERE 
                  a.uphydroseq = d.hydroseq 
               );

               GET DIAGNOSTICS num_updated = ROW_COUNT;

               -- fill totaltime and totaldist for the 'next' comids along each divergent path, 
               -- until no more updates are possible.
               num_iterations := 2;

               WHILE num_updated > 0
               LOOP
                  UPDATE tmp_navigation_connections_dd a 
                  SET 
                   processed = num_iterations
                  ,totaldist = a.lengthkm + (
                      SELECT 
                      MAX(b.totaldist)
                      FROM 
                      tmp_navigation_connections_dd b 
                      WHERE 
                      a.uphydroseq = b.hydroseq 
                   )
                  ,totaltime = travtime + (
                      SELECT 
                      MAX(c.totaltime) 
                      FROM 
                      tmp_navigation_connections_dd c 
                      WHERE 
                      a.uphydroseq = c.hydroseq 
                   ) 
                  WHERE 
                      a.processed IS NULL 
                  AND EXISTS (
                     SELECT 
                     1 
                     FROM 
                     tmp_navigation_connections_dd d 
                     WHERE 
                         d.hydroseq = a.uphydroseq
                     AND d.processed IS NOT NULL 
                  );

                  GET DIAGNOSTICS num_updated = ROW_COUNT;

                  IF num_updated = 0
                  THEN
                     --the 'min' function is most likely not necessary.  I left it there to make
                     --certain that the query does not
                     --return multiple values.
                     UPDATE tmp_navigation_connections_dd a 
                     SET 
                      processed = num_iterations
                     ,totaldist = a.lengthkm + (
                         SELECT 
                         MIN(b.totaldist) 
                         FROM 
                         tmp_navigation_connections_dd b 
                         WHERE 
                             b.dnhydroseq = a.hydroseq 
                         AND b.processed IS NOT NULL 
                      )
                     ,totaltime = a.travtime + (
                         SELECT 
                         MIN(c.totaltime) 
                         FROM 
                         tmp_navigation_connections_dd c 
                         WHERE 
                             c.dnhydroseq = a.hydroseq 
                         AND c.processed IS NOT NULL 
                      )  
                     WHERE 
                         a.processed IS NULL
                     AND EXISTS (
                        SELECT 
                        1 
                        FROM 
                        tmp_navigation_connections_dd d 
                        WHERE 
                            d.dnhydroseq = a.hydroseq 
                        AND d.processed IS NOT NULL 
                     );

                     GET DIAGNOSTICS num_updated = ROW_COUNT;

                  END IF;

                  num_iterations := num_iterations + 1;

               END LOOP;

               --Remove all comids in temptable2 where totaldist and total time are null
               DELETE FROM tmp_navigation_connections_dd a
               WHERE 
               a.totaldist IS NULL;

               --remove anything longer than 'max'
               IF p_num_max_distance IS NOT NULL
               THEN
                  --Remove all comids in temptable2 where distance traveled is too long
                  DELETE FROM tmp_navigation_connections_dd a
                  WHERE 
                  a.totaldist - a.lengthkm > p_num_max_distance;

               ELSIF p_num_max_time IS NOT NULL
               THEN
                  --Remove all comids in temptable2 where time traveled is too long
                  DELETE FROM tmp_navigation_connections_dd a
                  WHERE 
                  a.totaltime - a.travtime > p_num_max_time;

               END IF;

            END IF;

            num_used := num_used + 1;
            ary_used_comids[num_used] := rec_connections.dncomid;

         END IF;

      END LOOP;

      CLOSE curs_connections;

      --Add all IRC results for this pass to the navigation results.
      --IF num_inserted > 0
      IF num_did_insertions > 0
      THEN
         INSERT INTO nhdplus_navigation.tmp_navigation_results(
             objectid
            ,session_id
            ,start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,dnhydroseq
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,nhdplus_region
            ,nhdplus_version
            ,reachsmdate
            ,ftype
            ,fcode
            ,gnis_id
            ,wbarea_permanent_identifier
            ,wbarea_nhdplus_comid
            ,wbd_huc12
            ,catchment_featureid
            ,shape 
         ) 
         SELECT DISTINCT 
          nextval('nhdplus_navigation.tmp_navigation_results_seq')
         ,p_session_id
         ,a.start_permanent_identifier
         ,a.permanent_identifier
         ,a.start_nhdplus_comid
         ,a.nhdplus_comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.totaldist
         ,a.totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.dnhydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.time_measure_ratio
         ,a.ofmeasure
         ,a.otmeasure
         ,a.nhdplus_region
         ,a.nhdplus_version
         ,a.reachsmdate
         ,a.ftype
         ,a.fcode
         ,a.gnis_id
         ,a.wbarea_permanent_identifier
         ,a.wbarea_nhdplus_comid
         ,a.wbd_huc12
         ,a.catchment_featureid
         ,a.shape
         FROM
         tmp_navigation_connections a 
         ORDER BY 
         a.hydroseq DESC;

         --Add the divergent path records too.
         IF p_navigation_type = 'DD'
         THEN
            INSERT INTO nhdplus_navigation.tmp_navigation_results(
                objectid
               ,session_id
               ,start_permanent_identifier
               ,permanent_identifier
               ,start_nhdplus_comid
               ,nhdplus_comid
               ,reachcode
               ,fmeasure
               ,tmeasure
               ,totaldist
               ,totaltime
               ,hydroseq
               ,levelpathid
               ,terminalpathid
               ,uphydroseq
               ,dnhydroseq
               ,pathlength
               ,lengthkm
               ,length_measure_ratio
               ,pathtime
               ,travtime
               ,time_measure_ratio
               ,ofmeasure
               ,otmeasure
               ,nhdplus_region
               ,nhdplus_version
               ,reachsmdate
               ,ftype
               ,fcode
               ,gnis_id
               ,wbarea_permanent_identifier
               ,wbarea_nhdplus_comid
               ,wbd_huc12
               ,catchment_featureid
               ,shape
            ) 
            SELECT DISTINCT 
             nextval('nhdplus_navigation.tmp_navigation_results_seq')
            ,p_session_id
            ,a.start_permanent_identifier
            ,a.permanent_identifier
            ,a.start_nhdplus_comid
            ,a.nhdplus_comid
            ,a.reachcode
            ,a.fmeasure
            ,a.tmeasure
            ,a.totaldist
            ,a.totaltime
            ,a.hydroseq
            ,a.levelpathid
            ,a.terminalpathid
            ,a.uphydroseq
            ,a.dnhydroseq
            ,a.pathlength
            ,a.lengthkm
            ,a.length_measure_ratio
            ,a.pathtime
            ,a.travtime
            ,a.time_measure_ratio
            ,a.ofmeasure
            ,a.otmeasure
            ,a.nhdplus_region
            ,a.nhdplus_version
            ,a.reachsmdate
            ,a.ftype
            ,a.fcode
            ,a.gnis_id
            ,a.wbarea_permanent_identifier
            ,a.wbarea_nhdplus_comid
            ,a.wbd_huc12
            ,a.catchment_featureid
            ,a.shape
            FROM 
            tmp_navigation_connections_dd a 
            WHERE 
            a.totaldist IS NOT NULL 
            ORDER BY 
            a.hydroseq DESC;

         END IF;

      END IF;

      TRUNCATE TABLE tmp_navigation_connections;

      IF p_navigation_type = 'DD'
      THEN
         TRUNCATE TABLE tmp_navigation_connections_dd;
         
      END IF;
      
   END LOOP;

   IF num_did_insertions = 1
   THEN
      --Adjust measures and totals at the bottom of paths, if necessary
      IF p_navigation_type IN ('DM','PP')
      THEN
         --Find Hydroseq of last record in the navigation.
         SELECT 
         MIN(a.hydroseq) 
         INTO num_min_hydro_seq
         FROM 
         nhdplus_navigation.tmp_navigation_results a
         WHERE
         a.session_id = p_session_id;

         --Get data needed to adjust measures and totals
         SELECT 
          a.pathlength
         ,a.lengthkm
         ,a.pathtime
         ,a.travtime
         ,a.tmeasure
         ,a.fmeasure 
         INTO 
          num_W_path_length
         ,num_W_lengthkm
         ,num_W_path_time
         ,num_W_trav_time
         ,num_W_tomeas
         ,num_W_frommeas
         FROM 
         nhdplus_navigation.tmp_navigation_results a 
         WHERE 
             a.session_id = p_session_id
         AND a.hydroseq = num_min_hydro_seq;

         IF p_num_max_distance IS NOT NULL
         AND num_W_path_length < p_start_path_length - p_num_max_distance
         THEN
            num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_lengthkm
               ,p_distance  := (num_W_path_length + num_W_lengthkm) - (p_start_path_length - p_num_max_distance)
               ,p_half      := 'TOP'
            );

            num_W_calc_time := nhdplus_navigation.included_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_trav_time
               ,p_measure   := num_W_calc_meas
               ,p_half      := 'TOP'
            );

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             fmeasure  = ROUND(num_W_calc_meas,5)
            ,totaldist = p_num_max_distance
            ,totaltime = p_start_path_time - (num_W_path_time + (num_W_trav_time - num_W_calc_time)) 
            WHERE 
                a.session_id = p_session_id
            AND a.hydroseq = num_min_hydro_seq;

         ELSIF p_num_max_time IS NOT NULL
         AND num_W_path_length < p_start_path_time - p_num_max_time
         THEN
            num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_trav_time
               ,p_distance  := (num_W_path_time + num_W_trav_time) - (p_start_path_time - p_num_max_time)
               ,p_half      := 'TOP'
            );

            num_W_calc_time := nhdplus_navigation.included_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_lengthkm
               ,p_measure   := num_W_calc_meas
               ,p_half      := 'TOP'
            );

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             fmeasure  = ROUND(num_W_calc_meas,5)
            ,totaldist = p_start_path_length - (num_W_path_length + (num_W_lengthkm - num_W_calc_dis))
            ,totaltime = p_num_max_time
            WHERE 
                a.session_id = p_session_id
            AND a.hydroseq   = num_min_hydro_seq;

         ELSIF p_stop_comid IS NOT NULL
         THEN
            num_W_calc_meas := p_stop_measure;

            num_W_calc_dis := nhdplus_navigation.included_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_lengthkm
               ,p_measure   := num_W_calc_meas
               ,p_half      := 'TOP'
            );

            num_W_calc_time := nhdplus_navigation.included_distance(
                p_fmeasure  := num_W_frommeas
               ,p_tmeasure  := num_W_tomeas
               ,p_length    := num_W_trav_time
               ,p_measure   := num_W_calc_meas
               ,p_half      := 'TOP'
            );
            
            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             fmeasure  = ROUND(num_W_calc_meas,5)
            ,totaldist = p_start_path_length - (num_W_path_length + (num_W_lengthkm - num_W_calc_dis))
            ,totaltime = p_start_path_time - (num_W_path_time + (num_W_trav_time - num_W_calc_time))
            WHERE 
                a.session_id = p_session_id
            AND a.hydroseq = num_min_hydro_seq;

         END IF;

      ELSIF p_navigation_type = 'DD'
      THEN
         IF p_num_max_distance IS NOT NULL
         THEN
            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             fmeasure  = ROUND(a.otmeasure - (((a.otmeasure - a.ofmeasure) / a.lengthkm) * (p_num_max_distance - (a.totaldist - a.lengthkm))),5)
            ,totaldist = p_num_max_distance 
            WHERE 
                a.session_id = p_session_id
            AND a.ofmeasure IS NOT NULL 
            AND a.ofmeasure = a.fmeasure
            AND a.totaldist > p_num_max_distance;

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
            totaltime = (a.totaltime - a.travtime) + (a.travtime * ((a.tmeasure - a.fmeasure) / (a.otmeasure - a.ofmeasure))) 
            WHERE 
                a.session_id = p_session_id
            AND a.ofmeasure IS NOT NULL
            AND a.ofmeasure <> a.fmeasure
            AND a.totaldist = p_num_max_distance;

         ELSIF p_num_max_time > 0
         THEN
            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             fmeasure  = ROUND(a.otmeasure - (((a.otmeasure - a.ofmeasure) / a.travtime) * (p_num_max_time - (a.totaltime - a.travtime))),5)
            ,totaltime = p_num_max_time 
            WHERE 
                a.session_id = p_session_id
            AND a.ofmeasure IS NOT NULL
            AND a.ofmeasure = a.fmeasure
            AND a.totaltime > p_num_max_time;

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET
            totaldist = (a.totaldist - a.lengthkm) + (a.lengthkm * ((a.tmeasure - a.fmeasure) / (a.otmeasure - a.ofmeasure))) 
            WHERE
                a.session_id = p_session_id
            AND a.ofmeasure IS NOT NULL
            AND a.ofmeasure <> a.fmeasure 
            AND a.totaltime = p_num_max_time;

         END IF;

      END IF;

   END IF;
   
   RETURN 0;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.irc_down_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_start_comid integer, p_start_permanent_identifier character varying, p_start_measure numeric, p_stop_comid integer, p_stop_permanent_identifier character varying, p_stop_measure numeric, p_start_inc_dist numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying) OWNER TO nhdplus_navigation;

--
-- Name: irc_up_processing(character varying, flowline_rec, numeric, numeric, numeric, numeric, character varying, character varying, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION irc_up_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   ary_used_comids     INTEGER[];
   num_used            INTEGER := 0;
   num_found           INTEGER;
   num_inserted        INTEGER;
   num_continue        INTEGER := 1;
   num_did_insertions  INTEGER := 0;
   num_max_hydro_seq   NUMERIC(10,0);
   num_W_path_length   NUMERIC;
   num_W_lengthkm      NUMERIC;
   num_W_tomeas        NUMERIC;
   num_W_frommeas      NUMERIC;
   num_W_calc_meas     NUMERIC;
   num_W_calc_dis      NUMERIC;
   num_W_calc_time     NUMERIC;
   num_W_path_time     NUMERIC;
   num_W_trav_time     NUMERIC;
   rec_connections     nhdplus_navigation.typ_connections;
   num_check           NUMERIC;
   
   curs_connections_ut CURSOR(
      p_session_id VARCHAR
   )
   IS
   SELECT DISTINCT 
    a.upcomid
   ,a.dncomid
   ,a.upunitid
   ,a.dnunitid 
   FROM 
   nhdplus.nhdplusconnect_np21 a
   JOIN
   nhdplus_navigation.tmp_navigation_results b 
   ON
   a.dncomid = b.nhdplus_comid
   WHERE
   b.session_id = p_session_id;
   
   curs_connections_um CURSOR(
      p_session_id VARCHAR
   )
   IS
   SELECT DISTINCT 
    a.upcomid
   ,a.dncomid
   ,a.upunitid
   ,a.dnunitid 
   FROM 
   nhdplus.nhdplusconnect_np21 a
   JOIN
   nhdplus_navigation.tmp_navigation_results b 
   ON
   a.dncomid = b.nhdplus_comid
   WHERE
       a.uphydroseq = a.upmainhydroseq
   AND b.session_id = p_session_id;
   
BEGIN

   --------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   --------------------------------------------------------------------------
   
   --------------------------------------------------------------------------
   -- Step 20
   -- Bail if we are able
   --------------------------------------------------------------------------
   IF p_navigation_type = 'UT'
   THEN
      SELECT 
      COUNT(*)
      INTO num_check
      FROM
      nhdplus.nhdplusconnect_np21 a
      WHERE
          a.dnunittype = 'VPU'
      AND a.dnunitid   = p_start_flowline.nhdplus_region;
   
   ELSIF p_navigation_type = 'UM'
   THEN
      SELECT 
      COUNT(*)
      INTO num_check
      FROM
      nhdplus.nhdplusconnect_np21 a
      WHERE
          a.dnunittype = 'VPU'
      AND a.uphydroseq = a.upmainhydroseq
      AND a.dnunitid   = p_start_flowline.nhdplus_region;
      
   ELSE
      RAISE EXCEPTION 'err';
      
   END IF;
   
   IF num_check = 0
   THEN
      RETURN 0;
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 30
   -- Loop through any connections found
   --------------------------------------------------------------------------
   WHILE num_continue = 1
   LOOP
      num_continue := 0;

      IF p_navigation_type = 'UT'
      THEN
         OPEN curs_connections_ut(p_session_id);

      ELSIF p_navigation_type = 'UM'
      THEN
         OPEN curs_connections_um(p_session_id);
         
      END IF;

      LOOP

      IF p_navigation_type = 'UT'
      THEN
         FETCH curs_connections_ut INTO rec_connections;
         EXIT WHEN NOT FOUND;

      ELSIF p_navigation_type = 'UM'
      THEN
         FETCH curs_connections_um INTO rec_connections;
         EXIT WHEN NOT FOUND;
            
      END IF;

         num_found := 0;

         IF ary_used_comids IS NOT NULL
         AND array_length(ary_used_comids,1) > 0
         THEN
            FOR i IN 1 .. array_length(ary_used_comids,1)
            LOOP
               IF ary_used_comids[i] = rec_connections.upcomid
               THEN
                  num_found := 1;
               
               END IF;
               
            END LOOP;
            
         END IF;

         IF num_found = 0
         THEN
            IF p_num_max_distance IS NOT NULL
            THEN
               IF p_navigation_type = 'UM'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_um a
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid 
                  AND a.pathlength <= p_start_path_length + p_num_max_distance 
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;
                  
               ELSIF p_navigation_type = 'UT'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape 
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_ut a 
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid 
                  AND a.pathlength <= p_start_path_length + p_num_max_distance
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;
                  
               END IF;

            ELSIF p_num_max_time IS NOT NULL
            THEN
               IF p_navigation_type = 'UM'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_um a 
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid
                  AND a.pathtime <= p_start_path_time + p_num_max_time
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;

               ELSIF p_navigation_type = 'UT'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape 
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime 
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_ut a 
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid
                  AND a.pathtime <= p_start_path_time + p_num_max_time
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;
               
               END IF;

            ELSE
               IF p_navigation_type = 'UM'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength 
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_um a 
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;

               ELSIF p_navigation_type = 'UT'
               THEN
                  INSERT INTO tmp_navigation_connections(
                      start_permanent_identifier
                     ,permanent_identifier
                     ,start_nhdplus_comid
                     ,nhdplus_comid
                     ,reachcode
                     ,fmeasure
                     ,tmeasure
                     ,totaldist
                     ,totaltime
                     ,hydroseq
                     ,levelpathid
                     ,terminalpathid
                     ,uphydroseq
                     ,dnhydroseq
                     ,pathlength
                     ,lengthkm
                     ,length_measure_ratio
                     ,pathtime
                     ,travtime
                     ,time_measure_ratio
                     ,ofmeasure
                     ,otmeasure
                     ,nhdplus_region
                     ,nhdplus_version
                     ,reachsmdate
                     ,ftype
                     ,fcode
                     ,gnis_id
                     ,wbarea_permanent_identifier
                     ,wbarea_nhdplus_comid
                     ,wbd_huc12
                     ,catchment_featureid
                     ,shape
                  ) 
                  SELECT  
                   a.start_permanent_identifier
                  ,a.permanent_identifier
                  ,a.start_nhdplus_comid
                  ,a.nhdplus_comid
                  ,a.reachcode
                  ,a.fmeasure
                  ,a.tmeasure
                  ,NULL AS totaldist
                  ,NULL AS totaltime
                  ,a.hydroseq
                  ,a.levelpathid
                  ,a.terminalpathid
                  ,a.uphydroseq
                  ,a.dnhydroseq
                  ,a.pathlength
                  ,a.lengthkm
                  ,a.length_measure_ratio
                  ,a.pathtime
                  ,a.travtime
                  ,a.time_measure_ratio
                  ,a.fmeasure
                  ,a.tmeasure
                  ,a.nhdplus_region
                  ,a.nhdplus_version
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.reachsmdate
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.ftype
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.fcode
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.gnis_id
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_permanent_identifier
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbarea_nhdplus_comid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.wbd_huc12
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   THEN
                      a.catchment_featureid
                   ELSE
                      NULL
                   END
                  ,CASE WHEN p_add_flowline_attributes = 'TRUE'
                   AND p_add_flowline_geometry = 'TRUE'
                   THEN
                      a.shape
                   ELSE
                      NULL
                   END
                  FROM 
                  nhdplus_navigation.prep_connections_ut a 
                  WHERE 
                      a.start_nhdplus_comid = rec_connections.upcomid
                  AND a.nhdplus_comid NOT IN (SELECT b.nhdplus_comid FROM tmp_navigation_connections b)
                  ORDER BY 
                  a.hydroseq;
                  
               END IF;

            END IF;

            GET DIAGNOSTICS num_inserted = ROW_COUNT;

            IF num_inserted > 0
            THEN
               num_did_insertions := 1;
               num_continue := 1;
               
            END IF;
            
            num_used := num_used + 1;
            ary_used_comids[num_used] := rec_connections.upcomid;

         END IF;

      END LOOP;

      IF p_navigation_type = 'UT'
      THEN
         CLOSE curs_connections_ut;

      ELSIF p_navigation_type = 'UM'
      THEN
         CLOSE curs_connections_um;

      END IF;

      IF num_inserted > 0
      THEN
         INSERT INTO nhdplus_navigation.tmp_navigation_results(
             objectid
            ,session_id
            ,start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode 
            ,fmeasure 
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,dnhydroseq
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,nhdplus_region
            ,nhdplus_version
            ,reachsmdate
            ,ftype
            ,fcode
            ,gnis_id
            ,wbarea_permanent_identifier
            ,wbarea_nhdplus_comid
            ,wbd_huc12
            ,catchment_featureid
            ,shape
         ) 
         SELECT DISTINCT 
          nextval('nhdplus_navigation.tmp_navigation_results_seq')
         ,p_session_id
         ,a.start_permanent_identifier
         ,a.permanent_identifier
         ,a.start_nhdplus_comid
         ,a.nhdplus_comid
         ,a.reachcode
         ,ROUND(a.fmeasure,5)
         ,ROUND(a.tmeasure,5)
         ,ROUND(a.totaldist,16)
         ,ROUND(a.totaltime,16)
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.dnhydroseq
         ,a.pathlength
         ,ROUND(a.lengthkm,16)
         ,ROUND(a.length_measure_ratio,16)
         ,a.pathtime
         ,ROUND(a.travtime,16)
         ,a.time_measure_ratio
         ,a.ofmeasure
         ,a.otmeasure
         ,a.nhdplus_region
         ,a.nhdplus_version
         ,a.reachsmdate
         ,a.ftype
         ,a.fcode
         ,a.gnis_id
         ,a.wbarea_permanent_identifier
         ,a.wbarea_nhdplus_comid
         ,a.wbd_huc12
         ,a.catchment_featureid
         ,a.shape
         FROM 
         tmp_navigation_connections a 
         ORDER BY 
         a.hydroseq;

      END IF;

      TRUNCATE TABLE tmp_navigation_connections;

   END LOOP;

   IF num_did_insertions = 1
   THEN
      --Adjust measures and totals at the bottom of paths, if necessary
      IF p_navigation_type = 'UM'
      THEN
         --Find Hydroseq of last record in the navigation.
         SELECT 
         MAX(a.hydroseq)
         INTO num_max_hydro_seq
         FROM
         nhdplus_navigation.tmp_navigation_results a
         WHERE
         a.session_id = p_session_id;

         -- Get data needed to adjust measures and totals
         SELECT 
          a.pathlength
         ,a.lengthkm
         ,a.pathtime
         ,a.travtime
         ,a.tmeasure
         ,a.fmeasure 
         INTO 
          num_W_path_length
         ,num_W_lengthkm
         ,num_W_path_time
         ,num_W_trav_time
         ,num_W_tomeas
         ,num_W_frommeas
         FROM 
         nhdplus_navigation.tmp_navigation_results a 
         WHERE 
             a.session_id = p_session_id
         AND a.hydroseq = num_max_hydro_seq;

         IF p_num_max_distance IS NOT NULL
         THEN
            IF num_W_path_length + num_W_lengthkm > p_start_path_length + p_num_max_distance
            THEN
               IF num_W_tomeas IS NULL
               THEN
                  NULL; --End NHDFlowline has null measures.  Do nothing.
                  
               ELSE
                  --Reset to1 with a calculated measure and totaldist with maxdistance and totaltime with calculated
                  --  totaltime
                  num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                      p_fmeasure      := num_W_frommeas
                     ,p_tmeasure      := num_W_tomeas
                     ,p_length        := num_W_lengthkm
                     ,p_distance      := p_start_path_length + p_num_max_distance - num_W_path_length
                     ,p_half          := 'BOTTOM'
                  );

                  num_W_calc_time := nhdplus_navigation.included_distance(
                      p_fmeasure  := num_W_frommeas
                     ,p_tmeasure  := num_W_tomeas
                     ,p_length    := num_W_trav_time
                     ,p_measure   := num_W_calc_meas
                     ,p_half      := 'BOTTOM'
                  );

                  UPDATE nhdplus_navigation.tmp_navigation_results a 
                  SET 
                   tmeasure  = ROUND(num_W_calc_meas,5)
                  ,totaldist = ROUND(p_num_max_distance,16)
                  ,totaltime = ROUND(num_W_path_time + num_W_calc_time - p_start_path_time,16)
                  WHERE
                      a.session_id = p_session_id
                  AND a.hydroseq = num_max_hydro_seq;

               END IF;
               
            END IF;

         ELSIF p_num_max_time > 0
         THEN
            IF num_W_path_time + num_W_trav_time > p_start_path_time + p_num_max_time
            THEN
               IF num_W_tomeas IS NULL
               THEN
                  NULL; --End NHDFlowline has null measures.  Do nothing.
                  
               ELSE
                  --Reset to1 with a calculated measure and totaldist with maxdistance
                  num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                      p_fmeasure      := num_W_frommeas
                     ,p_tmeasure      := num_W_tomeas
                     ,p_length        := num_W_trav_time
                     ,p_distance      := p_start_path_time + p_num_max_time - num_W_path_time
                     ,p_half          := 'BOTTOM'
                  );
                  
                  num_W_calc_dis := nhdplus_navigation.included_distance(
                      p_fmeasure  := num_W_frommeas
                     ,p_tmeasure  := num_W_tomeas
                     ,p_length    := num_W_lengthkm
                     ,p_measure   := num_W_calc_meas
                     ,p_half      := 'BOTTOM'
                  );

                  UPDATE nhdplus_navigation.tmp_navigation_results a 
                  SET 
                   tmeasure  = ROUND(num_W_calc_meas,5)
                  ,totaldist = ROUND(num_W_path_length + num_W_calc_dis - p_start_path_length,16)
                  ,totaltime = ROUND(p_num_max_time,16)
                  WHERE 
                      a.session_id = p_session_id
                  AND a.hydroseq = num_max_hydro_seq;

               END IF;

            END IF;

         END IF;

      ELSIF p_navigation_type = 'UT'
      THEN
         IF p_num_max_distance IS NOT NULL
         THEN
            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             tmeasure  = ROUND((a.fmeasure + ((a.tmeasure - a.fmeasure) / a.lengthkm) * ((p_start_path_length + p_num_max_distance) - a.pathlength)),5)
            ,totaldist = ROUND(p_num_max_distance,16)
            WHERE 
                a.session_id = p_session_id
            AND a.otmeasure = a.tmeasure
            AND a.pathlength + a.lengthkm > p_start_path_length + p_num_max_distance;

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
            totaltime = ROUND((a.pathtime + (a.travtime - (a.travtime * ((a.otmeasure - a.tmeasure) / (a.otmeasure - a.ofmeasure))))) - p_start_path_time,16)
            WHERE 
                a.session_id = p_session_id
            AND a.otmeasure <> a.tmeasure
            AND a.pathlength + a.lengthkm > p_start_path_length + p_num_max_distance;

         ELSIF p_num_max_time IS NOT NULL
         THEN
            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
             tmeasure  = ROUND((a.fmeasure + ((a.tmeasure - a.fmeasure) / a.travtime) * ( (p_start_path_time + p_num_max_time) - a.pathtime)),5)
            ,totaltime = ROUND(p_num_max_time,16)
            WHERE
                a.session_id = p_session_id
            AND a.otmeasure = a.tmeasure
            AND a.pathtime + a.travtime > p_start_path_time + p_num_max_time;

            UPDATE nhdplus_navigation.tmp_navigation_results a 
            SET 
            totaldist = ROUND((a.pathlength + (a.lengthkm - (a.lengthkm * ((a.otmeasure - a.tmeasure) / (a.otmeasure - a.ofmeasure))))) - p_start_path_length,16)
            WHERE 
                a.session_id = p_session_id
            AND a.otmeasure <> a.tmeasure
            AND a.pathtime + a.travtime > p_start_path_time + p_num_max_time;

         END IF;

      END IF;

   END IF;
   
   RETURN 0;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.irc_up_processing(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, p_add_flowline_attributes character varying, p_add_flowline_geometry character varying, p_session_id character varying) OWNER TO nhdplus_navigation;

--
-- Name: measure_at_distance(numeric, numeric, numeric, numeric, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION measure_at_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_distance numeric, p_half character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
BEGIN
   
   -- Calculate Measure at a provided distance
   -- 'tmeasure' references the to measure which will actually be the from point of nhdflowline.
   -- 'fmeasure' references the from measure which will actually be the to point of nhdflowline.
   -- X is the measure supplied by the user
   -- Arrows indicate coordinate ordering - which is in agreement with the flow table
   --NHDFlowline C:   A(Tomeas)--->---X------>----->-----B(Frommeas)
   --Distance from A to X is the 'TOP'   (will need to be included in upstream navigations)
   --Distance from X to B is the 'BOTTOM' (will need to be included in downstream navigations)
   
   IF p_half = 'TOP'
   THEN
      RETURN ROUND(p_tmeasure - (((p_tmeasure - p_fmeasure) / p_length) * p_distance),5);
      
   ELSIF p_half = 'BOTTOM'
   THEN
      RETURN ROUND(p_fmeasure + (((p_tmeasure - p_fmeasure) / p_length) * p_distance),5);
   
   ELSE
      RAISE EXCEPTION 'err';
         
   END IF;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.measure_at_distance(p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_distance numeric, p_half character varying) OWNER TO nhdplus_navigation;

--
-- Name: navigate(character varying, integer, character varying, character varying, numeric, integer, character varying, character varying, numeric, numeric, numeric, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, pdebug character varying DEFAULT 'FALSE'::character varying, paddflowlineattributes character varying DEFAULT 'FALSE'::character varying, paddflowlinegeometry character varying DEFAULT 'FALSE'::character varying, OUT poutstartcomid integer, OUT poutstartmeasure numeric, OUT poutstopcomid integer, OUT poutstopmeasure numeric, OUT preturncode numeric, OUT pstatusmessage character varying, INOUT psessionid character varying DEFAULT NULL::character varying) RETURNS record
    LANGUAGE plpgsql
    AS $$
DECLARE
   str_nav_type                   VARCHAR(4000) := UPPER(pNavigationType);
   num_maximum_distance_km        NUMERIC := pMaxDistanceKm;
   num_maximum_flowtime_hour      NUMERIC := pMaxFlowTimeHour;
   str_add_flowline_attributes    VARCHAR(4000) := UPPER(pAddFlowlineAttributes);
   str_add_flowline_geometry      VARCHAR(4000) := UPPER(pAddFlowlineGeometry);
   int_start_comid                INTEGER;
   str_start_permanent_identifier VARCHAR(40);
   num_start_measure              NUMERIC;
   num_start_path_length          NUMERIC;
   num_start_path_time            NUMERIC;
   num_start_inc_dist             NUMERIC;
   num_start_inc_time             NUMERIC;
   int_stop_comid                 INTEGER;
   str_stop_permanent_identifier  VARCHAR(40);
   num_stop_measure               NUMERIC;
   num_stop_inc_dist              NUMERIC;
   num_stop_inc_time              NUMERIC;
   num_stop_condition_met         NUMERIC;
   obj_start_flowline             nhdplus_navigation.flowline_rec;
   obj_stop_flowline              nhdplus_navigation.flowline_rec;
   r                              RECORD;
   int_return_code                INTEGER;
   int_navigation_count           INTEGER;
   
BEGIN
  
   --------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   --------------------------------------------------------------------------
   pReturnCode := 0;
   
   IF str_nav_type NOT IN ('UM','UT','DM','DD','PP')
   THEN
      pReturnCode    := -1;
      pStatusMessage := 'Valid navigation type codes are UM, UT, DM, DD and PP.';
      RETURN;
   
   END IF;
   
   IF str_nav_type = 'PP'
   THEN
      num_maximum_distance_km   := NULL;
      num_maximum_flowtime_hour := NULL;
      
   END IF;
   
   IF str_add_flowline_attributes IS NULL
   OR str_add_flowline_attributes NOT IN ('TRUE','FALSE')
   THEN
      str_add_flowline_attributes := 'FALSE';
      
   END IF;
   
   IF str_add_flowline_geometry IS NULL
   OR str_add_flowline_geometry NOT IN ('TRUE','FALSE')
   THEN
      str_add_flowline_geometry := 'FALSE';
      
   END IF;
   
   IF  str_add_flowline_geometry = 'TRUE'
   AND str_add_flowline_attributes = 'FALSE'
   THEN
      str_add_flowline_attributes = 'TRUE';
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 20
   -- Verify or create the session id
   --------------------------------------------------------------------------
   IF pSessionID IS NULL
   THEN
      pSessionID := '{' || uuid_generate_v1() || '}';

      INSERT INTO
      nhdplus_navigation.tmp_navigation_status(
          objectid
         ,session_id
         ,session_datestamp
      ) VALUES (
          nextval('nhdplus_navigation.tmp_navigation_status_seq')
         ,pSessionID
         ,(abstime(('now'::text)::timestamp(6) with time zone))
      );

   END IF;
   
   --------------------------------------------------------------------------
   -- Step 20
   -- Run Navigation within the VPU
   --------------------------------------------------------------------------
   r := nhdplus_navigation.navigate_vpu_core(
       pNavigationType           := str_nav_type
      ,pStartComID               := pStartComID
      ,pStartPermanentIdentifier := pStartPermanentIdentifier
      ,pStartReachcode           := pStartReachcode
      ,pStartMeasure             := pStartMeasure
      ,pStopComID                := pStopComID
      ,pStopPermanentIdentifier  := pStopPermanentIdentifier
      ,pStopReachcode            := pStopReachcode
      ,pStopMeasure              := pStopMeasure
      ,pMaxDistanceKm            := num_maximum_distance_km
      ,pMaxFlowTimeHour          := num_maximum_flowtime_hour
      ,pSessionID                := pSessionID
      ,pDebug                    := pDebug
   );
   int_start_comid                := r.pCheckStartComID;
   str_start_permanent_identifier := r.pCheckStartPermanentIdentifier;
   num_start_measure              := r.pCheckStartMeasure;
   num_start_path_length          := r.pCheckStartPathLength;
   num_start_path_time            := r.pCheckStartPathTime;
   num_start_inc_dist             := r.pCheckStartIncDist;
   num_start_inc_time             := r.pCheckStartIncTime;
   int_stop_comid                 := r.pCheckStopComID;
   str_stop_permanent_identifier  := r.pCheckStopPermanentIdentifier;
   num_stop_measure               := r.pCheckStopMeasure;
   num_stop_inc_dist              := r.pCheckStopIncDist;
   num_stop_inc_time              := r.pCheckStopIncTime;
   num_stop_condition_met         := r.pCheckStopConditionMet;
   obj_start_flowline             := r.pCheckStartFlowline;
   obj_stop_flowline              := r.pCheckStopFlowline;
   pReturnCode                    := r.pReturnCode;
   pStatusMessage                 := r.pStatusMessage;
   
   -- Provide to out parameters for use by delineation
   pOutStartComID                 := r.pCheckStartComID;
   pOutStartMeasure               := r.pCheckStartMeasure;
   pOutStopComID                  := r.pCheckStopComID;
   pOutStopMeasure                := r.pCheckStopMeasure;

   --------------------------------------------------------------------------
   -- Step 30
   -- Do the IRC processes if stop condition has not been met
   --------------------------------------------------------------------------
   IF num_stop_condition_met <> 1
   THEN
      -- IRCProcess
      IF str_nav_type IN ('UM','UT')
      THEN
         int_return_code := nhdplus_navigation.irc_up_processing(
             p_navigation_type         := str_nav_type
            ,p_start_flowline          := obj_start_flowline
            ,p_num_max_distance        := num_maximum_distance_km
            ,p_num_max_time            := num_maximum_flowtime_hour
            ,p_start_path_length       := num_start_path_length
            ,p_start_path_time         := num_start_path_time
            ,p_add_flowline_attributes := str_add_flowline_attributes
            ,p_add_flowline_geometry   := str_add_flowline_geometry
            ,p_session_id              := pSessionID
         );
         
      ELSE
         int_return_code := nhdplus_navigation.irc_down_processing(
             p_navigation_type            := str_nav_type
            ,p_start_flowline             := obj_start_flowline
            ,p_stop_flowline              := obj_stop_flowline
            ,p_num_max_distance           := num_maximum_distance_km
            ,p_num_max_time               := num_maximum_flowtime_hour
            ,p_start_path_length          := num_start_path_length
            ,p_start_path_time            := num_start_path_time
            ,p_start_comid                := int_start_comid
            ,p_start_permanent_identifier := str_start_permanent_identifier
            ,p_start_measure              := num_start_measure
            ,p_stop_comid                 := int_stop_comid
            ,p_stop_permanent_identifier  := str_stop_permanent_identifier 
            ,p_stop_measure               := num_stop_measure
            ,p_start_inc_dist             := num_start_inc_dist
            ,p_add_flowline_attributes    := str_add_flowline_attributes
            ,p_add_flowline_geometry      := str_add_flowline_geometry
            ,p_session_id                 := pSessionID
         );
         
      END IF;
      
   END IF;

   --------------------------------------------------------------------------
   -- Step 40
   -- Update measures and distances
   --------------------------------------------------------------------------
   IF str_nav_type IN ('UM','UT')
   THEN
      --Populate totaldist field in navigation results table
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
      totaldist = a.pathlength + a.lengthkm - num_start_path_length
      WHERE 
          a.session_id = pSessionID
      AND a.totaldist IS NULL;

      --Populate totaltime field in navigation results table
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
      totaltime = a.pathtime + a.travtime - num_start_path_time 
      WHERE 
          a.session_id = pSessionID
      AND a.totaltime IS NULL;

      --Update from1,totaldist of start record (based on user supplied startmeas)
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
       fmeasure  = num_start_measure
      ,totaldist = num_start_inc_dist
      ,totaltime = num_start_inc_time 
      WHERE 
          a.session_id = pSessionID
      AND a.nhdplus_comid = int_start_comid;

   ELSIF str_nav_type IN ('DM','DD','PP')
   THEN
      --Populate totaldist field in navigation results table
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
      totaldist = num_start_path_length - a.pathlength 
      WHERE 
          a.session_id = pSessionID
      AND a.totaldist IS NULL;

      --Populate totaltime field in navigation results table
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
      totaltime = num_start_path_time - a.pathtime 
      WHERE 
          a.session_id = pSessionID
      AND a.totaltime IS NULL;

      --Update to1,totaldist of start record (based on user supplied startmeas)
      UPDATE nhdplus_navigation.tmp_navigation_results a 
      SET 
       tmeasure  = num_start_measure 
      ,totaldist = num_start_inc_dist
      WHERE 
          a.session_id = pSessionID
      AND a.nhdplus_comid = int_start_comid;
   
   ELSE
      RAISE EXCEPTION 'err';
      
   END IF;

   --------------------------------------------------------------------------
   -- Step 50
   -- Deal with top of headwater condition
   --------------------------------------------------------------------------
   UPDATE nhdplus_navigation.tmp_navigation_results a 
   SET 
    fmeasure = 99.999
   WHERE
       a.session_id = pSessionID
   AND a.fmeasure = 100
   AND a.tmeasure = 100
   AND a.uphydroseq = 0;

   --------------------------------------------------------------------------
   -- Step 60
   -- Recalculate modified flowlines, need reasonable where clause here
   --------------------------------------------------------------------------
   UPDATE nhdplus_navigation.tmp_navigation_results a 
   SET 
    lengthkm = (a.tmeasure - a.fmeasure) * a.length_measure_ratio
   ,travtime = (a.tmeasure - a.fmeasure) * a.time_measure_ratio
   WHERE
   a.session_id = pSessionID;
   
   --------------------------------------------------------------------------
   -- Step 70
   -- Add flowline attributes if requested
   --------------------------------------------------------------------------
   IF str_add_flowline_attributes = 'TRUE'
   THEN
      IF str_add_flowline_geometry = 'TRUE'
      THEN
         UPDATE nhdplus_navigation.tmp_navigation_results a 
         SET
          reachsmdate                 = b.reachsmdate
         ,ftype                       = b.ftype
         ,fcode                       = b.fcode
         ,gnis_id                     = b.gnis_id
         ,wbarea_permanent_identifier = b.wbarea_permanent_identifier
         ,wbarea_nhdplus_comid        = b.wbarea_nhdplus_comid
         ,wbd_huc12                   = b.wbd_huc12
         ,catchment_featureid         = b.catchment_featureid
         ,shape                       = CASE
                                        WHEN a.fmeasure <> b.fmeasure
                                        OR   a.tmeasure <> b.tmeasure
                                        THEN
                                           ST_GeometryN(ST_LocateBetween(b.shape,a.fmeasure,a.tmeasure),1)
                                        ELSE
                                           b.shape
                                        END
         FROM 
         nhdplus.nhdflowline_np21 b
         WHERE
             a.session_id = pSessionID
         AND b.nhdplus_comid = a.nhdplus_comid;
         
      ELSE
         UPDATE nhdplus_navigation.tmp_navigation_results a 
         SET 
          reachsmdate                 = b.reachsmdate
         ,ftype                       = b.ftype
         ,fcode                       = b.fcode
         ,gnis_id                     = b.gnis_id
         ,wbarea_permanent_identifier = b.wbarea_permanent_identifier
         ,wbarea_nhdplus_comid        = b.wbarea_nhdplus_comid
         ,wbd_huc12                   = b.wbd_huc12
         ,catchment_featureid         = b.catchment_featureid
         FROM
         nhdplus.nhdflowline_np21 b
         WHERE
             a.session_id = pSessionID
         AND b.nhdplus_comid = a.nhdplus_comid;
         
      END IF;
   
   END IF;
   
   -----------------------------------------------------------------------------
   -- Step 80
   -- Exit with zero
   -----------------------------------------------------------------------------
   UPDATE nhdplus_navigation.tmp_navigation_status a
   SET
    return_code    = pReturnCode
   ,status_message = pStatusMessage
   WHERE
   a.session_id = pSessionID;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, pdebug character varying, paddflowlineattributes character varying, paddflowlinegeometry character varying, OUT poutstartcomid integer, OUT poutstartmeasure numeric, OUT poutstopcomid integer, OUT poutstopmeasure numeric, OUT preturncode numeric, OUT pstatusmessage character varying, INOUT psessionid character varying) OWNER TO nhdplus_navigation;

--
-- Name: navigate_dndiv(character varying, flowline_rec, flowline_rec, numeric, numeric, numeric, numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate_dndiv(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   boo_continue             BOOLEAN := TRUE;
   num_first                INTEGER := 1;
   num_finished             INTEGER;
   num_updated              INTEGER;

   int_start_comid          INTEGER;
   num_start_measure        NUMERIC;
   num_termid               INTEGER;
   num_level_path_id        INTEGER;
   num_hydro_seq_no         INTEGER;

   num_last_level_path      INTEGER;
   num_min_hydro_seq        INTEGER;
   num_min_hydro_seq_dshs   INTEGER;
   num_min_hydro_seq_dslp   INTEGER;
   num_last_level_path_main INTEGER;
   num_last_hydro_seq_main  INTEGER;

   num_W_path_length        NUMERIC;
   num_W_lengthkm           NUMERIC;
   num_W_path_time          NUMERIC;
   num_W_trav_time          NUMERIC;
   num_W_tomeas             NUMERIC;
   num_W_frommeas           NUMERIC;
   num_W_calc_meas          NUMERIC;
   num_W_calc_time          NUMERIC;
   num_W_calc_dis           NUMERIC;

   num_starting_path_length NUMERIC;
   num_starting_path_time   NUMERIC;

   num_max_distance         NUMERIC;
   num_max_time             NUMERIC;
   num_dist_at_top          NUMERIC := 0;
   num_time_at_top          NUMERIC := 0;
   num_bottom_path_length   NUMERIC := 0;
   num_bottom_path_time     NUMERIC := 0;

   num_div_count            INTEGER;
   listDivs                 nhdplus_navigation.listDivs_rec[];
   boo_skip                 BOOLEAN;
   r                        RECORD;
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Get the last levelpath and hs to make sure a navigation from
   -- a divergence does not go past this point.
   --------------------------------------------------------------------------
   SELECT 
    a.hydroseq 
   ,a.levelpathid 
   INTO 
    num_last_hydro_seq_main
   ,num_last_level_path_main
   FROM 
   tmp_navigation_working a 
   WHERE 
       a.selected = 1 
   AND a.hydroseq = ( 
      SELECT 
      MIN(b.hydroseq) 
      FROM 
      tmp_navigation_working b 
      WHERE 
      b.selected = 1 
   );

   num_finished  := 0;
   num_div_count := 0;
   num_updated   := 0;

   WHILE num_finished = 0
   LOOP
      num_finished := 1;
      
      r := nhdplus_navigation.divergences(
          p_list_divs        := listDivs
         ,p_divergence_count := num_div_count
      );
      listDivs      := r.p_list_divs;
      num_div_count := r.p_divergence_count;

      IF listDivs IS NOT NULL
      AND array_length(listDivs,1) > 0
      THEN
         FOR i IN 1 .. array_length(listDivs,1)
         LOOP
            --If this drain divergence has not been procesed...
            IF listDivs[i].done = 0
            THEN
               listDivs[i] := (
                   listDivs[i].permanent_identifier
                  ,listDivs[i].nhdplus_comid
                  ,listDivs[i].fmeasure
                  ,listDivs[i].tmeasure
                  ,listDivs[i].hydroseq
                  ,listDivs[i].pathlength
                  ,listDivs[i].pathtime
                  ,listDivs[i].lengthkm
                  ,listDivs[i].travtime
                  ,listDivs[i].terminalpathid
                  ,listDivs[i].levelpathid
                  ,listDivs[i].uphydroseq
                  ,listDivs[i].divergence
                  ,1        -- done
                  ,listDivs[i].nhdplus_region
                  ,listDivs[i].nhdplus_version         
               )::nhdplus_navigation.listDivs_rec;
   
               num_finished      := 0;
   
               int_start_comid   := listDivs[i].nhdplus_comid;
               num_start_measure := listDivs[i].tmeasure;
               num_termid        := listDivs[i].terminalpathid;
               num_hydro_seq_no  := listDivs[i].hydroseq;
               num_level_path_id := listDivs[i].levelpathid;
   
               num_first    := 1;
               boo_continue := TRUE;
               boo_skip     := FALSE;
   
               -------------------------------------------------
               --Special DownMain navigation
               --   Stop navigating if a levelpath has already
               --   been navigated.
               -------------------------------------------------
               BEGIN
                  SELECT DISTINCT 
                   a.pathlength
                  ,a.pathtime
                  ,a.totaldist
                  ,a.totaltime 
                  INTO STRICT
                   num_starting_path_length
                  ,num_starting_path_time
                  ,num_dist_at_top
                  ,num_time_at_top
                  FROM 
                  tmp_navigation_working a 
                  WHERE 
                  a.hydroseq = listDivs[i].uphydroseq;
   
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     --------------------------------------------------------
                     -- This situation seems to occur when the service
                     -- encounters an intersection whereby two branches
                     -- touch but do not merge.  This step is checking that
                     -- the upstream flowline is in the list, but in this
                     -- case it never is.
                     --------------------------------------------------------
                     IF listDivs[i].divergence >= 2
                     THEN
                        -- We assume that this is OK
                        boo_skip := TRUE;
                        
                     ELSE
                        RAISE EXCEPTION 'err';
                        
                     END IF;
   
                  WHEN OTHERS
                  THEN
                     RAISE EXCEPTION 'err';
   
               END;
   
               IF boo_skip = FALSE
               THEN
                  IF num_dist_at_top IS NULL
                  THEN
                     --upstream hydroseq is along the main path
                     num_dist_at_top := p_start_path_length - num_starting_path_length;
                     
                  END IF;
   
                  IF num_time_at_top IS NULL
                  THEN
                     --upstream hydroseq is along the main path
                     num_time_at_top := p_start_path_time - num_starting_path_time;
                     
                  END IF;
   
                  --Adjust StartingPL and maxdistance for this start
                  IF p_num_max_distance IS NOT NULL
                  THEN
                     num_max_distance       := p_num_max_distance - num_dist_at_top; -- distance yet to travel
                     num_bottom_path_length := listDivs[i].pathlength + listDivs[i].lengthkm - num_max_distance;
   
                     IF num_max_distance <= 0
                     THEN
                        boo_continue := FALSE;
                        
                     END IF;
   
                  ELSIF p_num_max_time IS NOT NULL
                  THEN
                     num_max_time         := p_num_max_distance - num_time_at_top;
                     num_bottom_path_time := listDivs[i].pathtime + listDivs[i].travtime - num_max_time;
   
                     IF num_max_time <= 0
                     THEN
                        boo_continue := FALSE;
                        
                     END IF;
   
                  END IF;
   
                  --------------------------------------------------------------
                  -- DOWN MAIN loop
                  --------------------------------------------------------------
                  IF boo_continue
                  THEN
                     num_last_level_path := 0;
                     boo_continue := TRUE;
   
                     WHILE boo_continue
                     LOOP
                        --Set the starting hydroseqno for downstream levelpaths that are
                        --NOT the initial query
                        IF num_first = 0
                        THEN
                           num_level_path_id := num_min_hydro_seq_dslp;
                           num_hydro_seq_no  := num_min_hydro_seq_dshs;
                           
                        END IF;
   
                        IF num_last_level_path <> num_level_path_id
                        AND num_level_path_id > 0
                        AND num_hydro_seq_no > 0
                        THEN
                           --There is a downstream levelpath
                           --Downstream levelpaths exist on the initial query and
                           --when a particular levelpath ends and there is another below it
                           num_last_level_path := num_level_path_id;
                           num_first := 0;
   
                           IF p_num_max_distance IS NOT NULL
                           THEN
                              IF num_last_level_path_main <> num_level_path_id
                              THEN
                                 UPDATE tmp_navigation_working a 
                                 SET 
                                  selected  = 1
                                 ,ofmeasure = a.fmeasure
                                 ,otmeasure = a.tmeasure
                                 ,totaldist = num_dist_at_top + (
                                     SELECT 
                                     SUM(b.lengthkm) 
                                     FROM 
                                     tmp_navigation_working b 
                                     WHERE 
                                         b.levelpathid =  num_level_path_id
                                     AND b.hydroseq    <= num_hydro_seq_no
                                     AND b.hydroseq    >= a.hydroseq
                                  )
                                 ,totaltime = num_time_at_top + (
                                     SELECT 
                                     SUM(c.travtime) 
                                     FROM 
                                     tmp_navigation_working c 
                                     WHERE 
                                         c.levelpathid =  num_level_path_id
                                     AND c.hydroseq    <= num_hydro_seq_no
                                     AND c.hydroseq    >= a.hydroseq
                                  ) 
                                 WHERE 
                                     a.selected    =  0
                                 AND a.levelpathid =  num_level_path_id
                                 AND a.hydroseq    <= num_hydro_seq_no
                                 AND a.hydroseq    <> 0
                                 AND a.pathlength + a.lengthkm >= num_bottom_path_length;
   
                                 GET DIAGNOSTICS num_updated = ROW_COUNT;
   
                              ELSE
                                 --Special case to make sure we don't go
                                 --past the main path end point
                                 UPDATE tmp_navigation_working a 
                                 SET 
                                  selected  = 1 
                                 ,ofmeasure = a.fmeasure
                                 ,otmeasure = a.tmeasure
                                 ,totaldist = num_dist_at_top + (
                                     SELECT 
                                     SUM(b.lengthkm) 
                                     FROM 
                                     tmp_navigation_working b
                                     WHERE 
                                         b.levelpathid =  num_level_path_id
                                     AND b.hydroseq   <= num_hydro_seq_no 
                                     AND b.hydroseq   >= a.hydroseq 
                                  )
                                 ,totaltime = num_time_at_top + (
                                     SELECT
                                     SUM(c.travtime)
                                     FROM
                                     tmp_navigation_working c
                                     WHERE
                                         c.levelpathid =  num_level_path_id
                                     AND c.hydroseq    <= num_hydro_seq_no
                                     AND c.hydroseq    >= a.hydroseq
                                  )
                                 WHERE
                                     a.selected    =  0
                                 AND a.levelpathid =  num_level_path_id
                                 AND a.hydroseq    <= num_hydro_seq_no
                                 AND a.hydroseq    >  num_last_hydro_seq_main
                                 AND a.pathlength + a.lengthkm > num_bottom_path_length;
   
                                 GET DIAGNOSTICS num_updated = ROW_COUNT;
   
                              END IF;
   
                           ELSIF p_num_max_time IS NOT NULL
                           THEN
                              IF num_last_level_path_main <> num_level_path_id
                              THEN
                                 UPDATE tmp_navigation_working a 
                                 SET 
                                  selected  = 1
                                 ,ofmeasure = a.fmeasure
                                 ,otmeasure = a.tmeasure
                                 ,totaltime = num_time_at_top + (
                                     SELECT 
                                     SUM(b.travtime) 
                                     FROM 
                                     tmp_navigation_working b 
                                     WHERE 
                                         b.levelpathid =  num_level_path_id
                                     AND b.hydroseq    <= num_hydro_seq_no
                                     AND b.hydroseq    >= a.hydroseq 
                                  )
                                 ,totaldist = num_dist_at_top + (
                                     SELECT
                                     SUM(c.lengthkm)
                                     FROM
                                     tmp_navigation_working c
                                     WHERE
                                         c.levelpathid =  num_level_path_id
                                     AND c.hydroseq    <= num_hydro_seq_no
                                     AND c.hydroseq    >= a.hydroseq
                                  )
                                 WHERE 
                                     a.selected    =  0
                                 AND a.levelpathid =  num_level_path_id
                                 AND a.hydroseq    <= num_hydro_seq_no
                                 AND a.hydroseq    <> 0
                                 AND a.pathtime + a.travtime > num_bottom_path_time;
   
                                 GET DIAGNOSTICS num_updated = ROW_COUNT;
   
                              ELSE
                                 --Special case to make sure we don't go
                                 --past the main path end point
                                 UPDATE tmp_navigation_working a 
                                 SET 
                                  selected  = 1
                                 ,ofmeasure = a.fmeasure
                                 ,otmeasure = a.tmeasure
                                 ,totaltime = num_time_at_top + (
                                     SELECT 
                                     SUM(b.travtime) 
                                     FROM 
                                     tmp_navigation_working b 
                                     WHERE 
                                         b.levelpathid =  num_level_path_id
                                     AND b.hydroseq    <= num_hydro_seq_no
                                     AND b.hydroseq    >= a.hydroseq 
                                  )
                                 ,totaldist = num_dist_at_top + (
                                     SELECT 
                                     SUM(c.lengthkm) 
                                     FROM 
                                     tmp_navigation_working c 
                                     WHERE 
                                         c.levelpathid =  num_level_path_id
                                     AND c.hydroseq    <= num_hydro_seq_no
                                     AND c.hydroseq    >= a.hydroseq 
                                  ) 
                                 WHERE 
                                     a.selected    =  0
                                 AND a.levelpathid =  num_level_path_id
                                 AND a.hydroseq    <= num_hydro_seq_no
                                 AND a.hydroseq    >  num_last_hydro_seq_main
                                 AND a.pathtime + a.travtime > num_bottom_path_time;
   
                                 GET DIAGNOSTICS num_updated = ROW_COUNT;
   
                              END IF;
                              
                           ELSE
                              --Neither maxdistance or maxtime
                              UPDATE tmp_navigation_working a 
                              SET 
                               selected  = 1
                              ,ofmeasure = a.fmeasure
                              ,otmeasure = a.tmeasure
                              ,totaldist = num_dist_at_top + (
                                  SELECT 
                                  SUM(b.lengthkm) 
                                  FROM 
                                  tmp_navigation_working b 
                                  WHERE 
                                      b.levelpathid =  num_level_path_id
                                  AND b.hydroseq    <= num_hydro_seq_no
                                  AND b.hydroseq    >= a.hydroseq 
                               )
                              ,totaltime = num_time_at_top + (
                                  SELECT 
                                  SUM(c.travtime) 
                                  FROM 
                                  tmp_navigation_working c 
                                  WHERE 
                                      c.levelpathid = num_level_path_id
                                  AND c.hydroseq <= num_hydro_seq_no
                                  AND c.hydroseq >= a.hydroseq 
                               ) 
                              WHERE 
                                  a.selected    =  0
                              AND a.levelpathid =  num_level_path_id
                              AND a.hydroseq    <= num_hydro_seq_no
                              AND a.hydroseq    <> 0;
   
                              GET DIAGNOSTICS num_updated = ROW_COUNT;
   
                           END IF;
   
                           IF num_updated > 0
                           THEN
                              --Find Hydroseq of last record just updated.
                              SELECT 
                              MIN(a.hydroseq) 
                              INTO num_min_hydro_seq
                              FROM 
                              tmp_navigation_working a 
                              WHERE 
                                  a.selected    =  1
                              AND a.levelpathid =  num_level_path_id
                              AND a.hydroseq    <= num_hydro_seq_no;
   
                              --Get infomation from the working record for the min hs to ...
                              --    prepare for next iteration
                              --    update to1, totaldist if max distance has been reached.
                              SELECT 
                               a.dnhydroseq
                              ,a.dnlevelpathid
                              ,a.pathlength
                              ,a.lengthkm
                              ,a.pathtime
                              ,a.travtime
                              ,a.tmeasure
                              ,a.fmeasure
                              ,a.totaldist
                              ,a.totaltime 
                              INTO 
                               num_min_hydro_seq_dshs
                              ,num_min_hydro_seq_dslp
                              ,num_W_path_length
                              ,num_W_lengthkm
                              ,num_W_path_time
                              ,num_W_trav_time
                              ,num_W_tomeas
                              ,num_W_frommeas
                              ,num_dist_at_top
                              ,num_time_at_top
                              FROM 
                              tmp_navigation_working a 
                              WHERE 
                              a.hydroseq = num_min_hydro_seq;
   
                              --Need numMinDsHS, numMinDSlp to prepare for next iteration of loop
                              --Need numWPathlength, numWlengthkm, numWtomeas, numWfrommeas to update to1 (and determine if to1 needs
                              --      to be updated)
                              --Update to1, totaldist based on distance, if necessary
                              IF p_num_max_distance IS NOT NULL
                              THEN
                                 IF num_W_path_length < num_bottom_path_length
                                 THEN
                                    IF num_W_tomeas IS NULL
                                    THEN
                                       NULL; --End NHDFlowline has null measures.  Do nothing.
                                       
                                    ELSE
                                       --Reset to1 with a calculated measure and totaldist with maxdistance
                                       num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                                           p_fmeasure      := num_W_frommeas
                                          ,p_tmeasure      := num_W_tomeas
                                          ,p_length        := num_W_lengthkm
                                          ,p_distance      := (num_W_path_length + num_W_lengthkm) - num_bottom_path_length
                                          ,p_half          := 'TOP'
                                       );
                                       
                                       num_W_calc_time := nhdplus_navigation.included_distance(
                                           p_fmeasure      := num_W_frommeas
                                          ,p_tmeasure      := num_W_tomeas
                                          ,p_length        := num_W_trav_time
                                          ,p_measure       := num_W_calc_meas
                                          ,p_half          := 'TOP'
                                       );
   
                                       UPDATE tmp_navigation_working a
                                       SET 
                                        ofmeasure = num_W_calc_meas
                                       ,totaldist = p_num_max_distance
                                       ,totaltime = a.totaltime - a.travtime + num_W_calc_time 
                                       WHERE 
                                       a.hydroseq = num_min_hydro_seq;
   
                                    END IF;
   
                                    boo_continue := FALSE;
                          
                                 END IF;
   
                              ELSIF p_num_max_time IS NOT NULL
                              THEN
                                 IF num_W_path_time < num_bottom_path_time
                                 THEN
                                    IF num_W_tomeas IS NULL
                                    THEN
                                       NULL; --End NHDFlowline has null measures.  Do nothing.
                                       
                                    ELSE
                                       -- Reset to1 with a calculated measure and totaldist with maxdistance
                                       num_W_calc_meas:= nhdplus_navigation.measure_at_distance(
                                           p_fmeasure      := num_W_frommeas
                                          ,p_tmeasure      := num_W_tomeas
                                          ,p_length        := num_W_trav_time
                                          ,p_distance      := (num_W_path_time + num_W_trav_time) - num_bottom_path_time
                                          ,p_half          := 'TOP'
                                       );
   
                                       num_W_calc_dis := nhdplus_navigation.included_distance(
                                           p_fmeasure      := num_W_frommeas
                                          ,p_tmeasure      := num_W_tomeas
                                          ,p_length        := num_W_lengthkm
                                          ,p_measure       := num_W_calc_meas
                                          ,p_half          := 'TOP'
                                       );
   
                                       UPDATE tmp_navigation_working a 
                                       SET 
                                        ofmeasure = num_W_calc_meas
                                       ,totaltime = p_num_max_time
                                       ,totaldist = a.totaldist - a.lengthkm + num_W_calc_dis 
                                       WHERE 
                                       a.hydroseq = num_min_hydro_seq;
   
                                    END IF;
   
                                    boo_continue := FALSE;
   
                                 END IF;
   
                              END IF;
   
                           ELSE
                              boo_continue := FALSE;
   
                           END IF;
   
                        ELSE
                           boo_continue := FALSE;
   
                        END IF;
   
                     END LOOP;
   
                  END IF;
   
               END IF;
   
            END IF;
   
         END LOOP;
         
      END IF;

   END LOOP;
   
   RETURN 0;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate_dndiv(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric) OWNER TO nhdplus_navigation;

--
-- Name: navigate_dnmain(character varying, flowline_rec, flowline_rec, integer, numeric, numeric, numeric, numeric, numeric, numeric, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate_dnmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_stop_comid integer, p_stop_measure numeric, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric, p_debug character varying DEFAULT 'FALSE'::character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   boo_continue           BOOLEAN;
   boo_is_start_flowline  BOOLEAN;
   num_last_level_path    INTEGER;
   num_updated            INTEGER := 0;
   num_level_path_id      INTEGER;
   num_hydro_seq_no       INTEGER;
   num_min_hydro_seq      INTEGER;
   num_min_hydro_seq_dshs INTEGER;
   num_min_hydro_seq_dslp INTEGER;

   num_W_path_length      NUMERIC;
   num_W_lengthkm         NUMERIC;
   num_W_tomeas           NUMERIC;
   num_W_frommeas         NUMERIC;
   num_W_calc_meas        NUMERIC;
   num_W_calc_dis         NUMERIC;
   num_W_calc_time        NUMERIC;
   num_W_path_time        NUMERIC;
   num_W_trav_time        NUMERIC;
   str_message            VARCHAR(255);
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Load information about the starting comid
   --------------------------------------------------------------------------
   num_hydro_seq_no  := p_start_flowline.hydroseq;
   num_level_path_id := p_start_flowline.levelpathid;

   --------------------------------------------------------------------------
   -- Step 20
   -- Prepare the main loop
   --------------------------------------------------------------------------
   num_last_level_path   := 0;
   boo_continue          := TRUE;
   boo_is_start_flowline := TRUE;
   
   IF p_debug = 'TRUE'
   THEN
       str_message := 'Starting downstream with hydroseq = ' || num_hydro_seq_no 
       || ' and levelpathid = ' || num_level_path_id;
       RAISE DEBUG '%', str_message;
       
   END IF;

   --------------------------------------------------------------------------
   -- Step 30
   -- Main Loop
   --------------------------------------------------------------------------
   WHILE boo_continue
   LOOP
      --Set the starting hydroseqno for upstream levelpaths that are
      --NOT the initial query
      IF NOT boo_is_start_flowline
      THEN
         num_level_path_id := num_min_hydro_seq_dslp;
         num_hydro_seq_no  := num_min_hydro_seq_dshs;
         
      END IF;

      IF num_last_level_path <> num_level_path_id
      AND num_level_path_id > 0
      AND num_hydro_seq_no > 0
      THEN
         --There is a downstream levelpath
         --Downstream levelpaths exist on the initial query and
         --when a particular levelpath ends and there is another below it
         num_last_level_path := num_level_path_id;
         boo_is_start_flowline := FALSE;

         IF p_num_max_distance IS NOT NULL
         THEN
            UPDATE tmp_navigation_working a 
            SET 
             selected  = 1
            ,ofmeasure = a.fmeasure
            ,otmeasure = a.tmeasure 
            WHERE
                a.terminalpathid =  p_start_flowline.terminalpathid
            AND a.levelpathid    =  num_level_path_id
            AND a.hydroseq       <= num_hydro_seq_no
            AND a.hydroseq       <> 0
            AND p_start_path_length - p_num_max_distance <= a.pathlength + a.lengthkm;
            
            GET DIAGNOSTICS num_updated = ROW_COUNT;
            
            IF p_debug = 'TRUE'
            THEN
               str_message := 'Adding ' || num_updated || ' records to selection.';
               RAISE DEBUG '%', str_message;
               
            END IF;

         ELSIF p_num_max_time IS NOT NULL
         THEN
            UPDATE tmp_navigation_working a 
            SET 
             selected  = 1
            ,ofmeasure = a.fmeasure
            ,otmeasure = a.tmeasure 
            WHERE 
                a.terminalpathid =  p_start_flowline.terminalpathid
            AND a.levelpathid    =  num_level_path_id
            AND a.hydroseq       <= num_hydro_seq_no
            AND a.hydroseq       <> 0
            AND p_start_path_time - p_num_max_time  <= a.pathtime + a.travtime;
            
            GET DIAGNOSTICS num_updated = ROW_COUNT;

         ELSIF p_stop_comid IS NOT NULL
         THEN
            UPDATE tmp_navigation_working a 
            SET 
             selected   = 1
            ,ofmeasure  = a.fmeasure
            ,otmeasure  = a.tmeasure
            WHERE 
                a.terminalpathid =  p_start_flowline.terminalpathid
            AND a.levelpathid    =  num_level_path_id
            AND a.hydroseq       <= num_hydro_seq_no
            AND a.hydroseq       >= p_stop_flowline.hydroseq;
            
            GET DIAGNOSTICS num_updated = ROW_COUNT;

         ELSE
            UPDATE tmp_navigation_working a 
            SET 
             selected  = 1
            ,ofmeasure = a.fmeasure
            ,otmeasure = a.tmeasure 
            WHERE 
                a.terminalpathid =  p_start_flowline.terminalpathid
            AND a.levelpathid    =  num_level_path_id
            AND a.hydroseq       <= num_hydro_seq_no
            AND a.hydroseq       <> 0;
            
            GET DIAGNOSTICS num_updated = ROW_COUNT;

         END IF;

         IF num_updated > 0
         THEN
            -----------------------------------------------------------------
            --Find Hydroseq of last record just updated.
            -----------------------------------------------------------------
            SELECT 
            MIN(a.hydroseq) 
            INTO num_min_hydro_seq
            FROM 
            tmp_navigation_working a 
            WHERE 
                a.selected       =  1
            AND a.terminalpathid =  p_start_flowline.terminalpathid
            AND a.levelpathid    =  num_level_path_id
            AND a.hydroseq       <= num_hydro_seq_no;
            
            IF p_debug = 'TRUE'
            THEN
               str_message := '   Minimum Hydroseq is ' || num_min_hydro_seq;
               RAISE DEBUG '%', str_message;
               
            END IF;

            -----------------------------------------------------------------
            -- Get infomation from the working record for the min hs to ...
            -- Prepare for next iteration
            --    update to1, totaldist if max distance has been reached.
            -----------------------------------------------------------------
            SELECT 
             a.dnhydroseq
            ,a.dnlevelpathid
            ,a.pathlength
            ,a.lengthkm
            ,a.pathtime
            ,a.travtime
            ,a.tmeasure 
            ,a.fmeasure 
            INTO 
             num_min_hydro_seq_dshs
            ,num_min_hydro_seq_dslp
            ,num_W_path_length
            ,num_W_lengthkm
            ,num_W_path_time
            ,num_W_trav_time
            ,num_W_tomeas
            ,num_W_frommeas
            FROM 
            tmp_navigation_working a 
            WHERE 
            a.hydroseq = num_min_hydro_seq;

            IF p_debug = 'TRUE'
            THEN
               str_message := '   tmeasure is ' || CAST(num_W_tomeas AS VARCHAR);
               RAISE DEBUG '%', str_message;
               
            END IF;
            
            -----------------------------------------------------------------
            -- Need numMinDsHS, numMinDSlp to prepare for next iteration of loop
            -- Need the remaiing fields to update from1 
            -- (and determine if from1 needs to be updated)
            -- Update to1, totaldist based on distance, 
            -- totaltime based on time if necessary
            -----------------------------------------------------------------
            IF p_num_max_distance IS NOT NULL
            THEN
            
               IF p_debug = 'TRUE'
               THEN
                  IF num_W_path_length < p_start_path_length - p_num_max_distance
                  THEN
                     str_message := '   ' || CAST(num_W_path_length AS VARCHAR) ||
                     ' is less than ' || CAST(p_start_path_length - p_num_max_distance AS VARCHAR);
                     RAISE DEBUG '%', str_message;
                     
                  ELSE
                     str_message := '   ' || CAST(num_W_path_length AS VARCHAR) ||
                     ' is NOT less than ' || CAST(p_start_path_length - p_num_max_distance AS VARCHAR);
                     RAISE DEBUG '%', str_message;
                     
                  END IF;
                   
               END IF;

               IF num_W_path_length < p_start_path_length - p_num_max_distance
               THEN
                  IF num_W_tomeas IS NOT NULL
                  THEN
                     --Reset to1 with a calculated measure and totaldist with maxdistance
                     num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_lengthkm
                        ,p_distance      := (num_W_path_length + num_W_lengthkm) - (p_start_path_length - p_num_max_distance)
                        ,p_half          := 'TOP'
                     );

                     num_W_calc_time := nhdplus_navigation.included_distance(
                         p_fmeasure  := num_W_frommeas
                        ,p_tmeasure  := num_W_tomeas
                        ,p_length    := num_W_trav_time
                        ,p_measure   := num_W_calc_meas
                        ,p_half      := 'TOP'
                     );

                     UPDATE tmp_navigation_working a 
                     SET 
                      ofmeasure = num_W_calc_meas
                     ,totaldist = p_num_max_distance
                     ,totaltime = p_start_path_time - (num_W_path_time + (num_W_trav_time - num_W_calc_time))
                     WHERE 
                     a.hydroseq = num_min_hydro_seq;
                     
                     IF p_debug = 'TRUE'
                     THEN
                        str_message := '   updating ' || CAST(num_min_hydro_seq AS VARCHAR) ||
                        ' with ofmeasure = ' || CAST(num_W_calc_meas AS VARCHAR) ||
                        ' and totaldist = ' || CAST(p_num_max_distance AS VARCHAR) ||
                        ' and totaltime = ' || CAST(p_start_path_time - (num_W_path_time + (num_W_trav_time - num_W_calc_time)) AS VARCHAR);
                        RAISE DEBUG '%', str_message;
                        
                     END IF;

                  END IF;

                  boo_continue := FALSE; --Have reached the max distance, so stop

                  IF p_navigation_type = 'DM'
                  THEN
                     p_stop_condition_met := 1;
                     
                  END IF;

               END IF;

            ELSIF p_num_max_time IS NOT NULL
            THEN
               IF num_W_path_time < p_start_path_time - p_num_max_time
               THEN
                  IF num_W_tomeas IS NULL
                  THEN
                     NULL; --End NHDFlowline has null measures.  Do nothing.
                     
                  ELSE
                     --Reset to1 with a calculated measure and totaldist with maxdistance
                     num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_trav_time
                        ,p_distance      := (num_W_path_time + num_W_trav_time) - (p_start_path_time - p_num_max_time)
                        ,p_half          := 'TOP'
                     );

                     num_W_calc_dis := nhdplus_navigation.included_distance(
                         p_fmeasure  := num_W_frommeas
                        ,p_tmeasure  := num_W_tomeas
                        ,p_length    := num_W_lengthkm
                        ,p_measure   := num_W_calc_meas
                        ,p_half      := 'TOP'
                     );

                     UPDATE tmp_navigation_working a 
                     SET 
                      ofmeasure = num_W_calc_meas
                     ,totaldist = p_start_path_length - (num_W_path_length + (num_W_lengthkm - num_W_calc_dis))
                     ,totaltime = p_num_max_time
                     WHERE 
                     a.hydroseq = num_min_hydro_seq;

                  END IF;

                  boo_continue := FALSE; --Have reached the max time, so stop

                  IF p_navigation_type = 'DM'
                  THEN
                     p_stop_condition_met := 1;
                     
                  END IF;

               END IF;

            ELSIF p_stop_comid IS NOT NULL 
            AND p_navigation_type = 'PP'
            THEN
               IF num_min_hydro_seq = p_stop_flowline.hydroseq
               THEN
                  IF num_W_tomeas IS NULL
                  THEN
                     NULL; --End NHDFlowline has null measures.  Do nothing.
                     
                  ELSE
                     --Reset to1 with user provided measure
                     --Calculate totaldist and totaltime
                     num_W_calc_meas := p_stop_measure;
                     
                     num_W_calc_dis := nhdplus_navigation.included_distance(
                         p_fmeasure  := num_W_frommeas
                        ,p_tmeasure  := num_W_tomeas
                        ,p_length    := num_W_lengthkm
                        ,p_measure   := num_W_calc_meas
                        ,p_half      := 'TOP'
                     );
                     
                     num_W_calc_time := nhdplus_navigation.included_distance(
                         p_fmeasure  := num_W_frommeas
                        ,p_tmeasure  := num_W_tomeas
                        ,p_length    := num_W_trav_time
                        ,p_measure   := num_W_calc_meas
                        ,p_half      := 'TOP'
                     );

                     UPDATE tmp_navigation_working a 
                     SET 
                      ofmeasure = num_W_calc_meas
                     ,totaldist = p_start_path_length - (num_W_path_length + (num_W_lengthkm - num_W_calc_dis))
                     ,totaltime = p_start_path_time - (num_W_path_time + (num_W_trav_time - num_W_calc_time)) 
                     WHERE 
                     a.hydroseq = num_min_hydro_seq;

                  END IF;

                  boo_continue := FALSE; --Have reached the stop comid, so stop
                  p_stop_condition_met := 1;

               END IF;

            END IF;
            
         ELSE
            --No more updates, do nothing
            NULL;
            
         END IF;

      ELSE
         --There are no more downstream queries, so stop
         boo_continue := FALSE;
         
      END IF;

   END LOOP;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate_dnmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_stop_comid integer, p_stop_measure numeric, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric, p_debug character varying) OWNER TO nhdplus_navigation;

--
-- Name: navigate_upmain(character varying, flowline_rec, numeric, numeric, numeric, numeric, numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate_upmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   boo_continue           BOOLEAN := TRUE;
   boo_is_first           BOOLEAN := TRUE;
   num_level_path_id      INTEGER;
   num_hydro_seq_no       INTEGER;
   num_max_hydro_seq      INTEGER;
   num_max_hydro_seq_ushs INTEGER;
   num_max_hydro_seq_uslp INTEGER;
   
   num_W_path_length      NUMERIC;
   num_W_lengthkm         NUMERIC;
   num_W_path_time        NUMERIC;
   num_W_trav_time        NUMERIC;
   num_W_tomeas           NUMERIC;
   num_W_frommeas         NUMERIC;
   num_W_calc_meas        NUMERIC;
   num_W_calc_time        NUMERIC;
   num_W_calc_dis         NUMERIC;
   
   num_updated            INTEGER := 0;
   r                      RECORD;
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Get information about the starting comid
   -- This will always be the starting comid of the navigation itself
   --------------------------------------------------------------------------
   num_hydro_seq_no  := p_start_flowline.hydroseq;
   num_level_path_id := p_start_flowline.levelpathid;
   boo_continue      := TRUE;

   --------------------------------------------------------------------------
   -- Step 20
   -- MAIN loop
   --------------------------------------------------------------------------
   WHILE boo_continue
   LOOP
      --Set the starting hydroseqno for upstream levelpaths that are
      --NOT the initial query
      IF NOT boo_is_first
      THEN
         IF num_hydro_seq_no = num_max_hydro_seq_ushs
         THEN
            num_hydro_seq_no  := 0;
            
         ELSE
            num_hydro_seq_no  := num_max_hydro_seq_ushs;
            num_level_path_id := num_max_hydro_seq_uslp;
            
         END IF;
         
      END IF;

      IF num_hydro_seq_no <> 0
      THEN
         --There is an upstream levelpath
         --Upstream levelpaths exist on the initial query and
         --when a particular levelpath ends on a divergence = 2
         boo_is_first := FALSE;

         --Select (set selected = 1 ) for upstream levelpath

         IF p_num_max_distance IS NOT NULL
         THEN
            -- MaxDistance is the stop condition
            -- This is some screwy postgres shit
            WITH cte_update AS (
               UPDATE tmp_navigation_working a 
               SET 
                selected  = 1
               ,ofmeasure = a.fmeasure
               ,otmeasure = a.tmeasure 
               WHERE 
                   a.terminalpathid =  p_start_flowline.terminalpathid
               AND a.levelpathid    =  num_level_path_id 
               AND a.hydroseq       >= num_hydro_seq_no
               AND a.pathlength     <= p_start_path_length + p_num_max_distance
               RETURNING a.hydroseq
            )
            SELECT MAX(b.hydroseq) INTO num_max_hydro_seq FROM cte_update b;

         ELSIF p_num_max_time IS NOT NULL
         THEN
            --MaxTime is the stop condition
            WITH cte_update AS (
               UPDATE tmp_navigation_working a 
               SET 
                selected  = 1
               ,ofmeasure = a.fmeasure 
               ,otmeasure = a.tmeasure
               WHERE 
                   a.terminalpathid =  p_start_flowline.terminalpathid
               AND a.levelpathid    =  num_level_path_id 
               AND a.hydroseq       >= num_hydro_seq_no
               AND a.pathtime       <= p_start_path_time + p_num_max_time
               RETURNING a.hydroseq
            )
            SELECT MAX(b.hydroseq) INTO num_max_hydro_seq FROM cte_update b;
            
         ELSE
            --There is no stop condition
            WITH cte_update AS (
               UPDATE tmp_navigation_working a 
               SET 
                selected  = 1
               ,ofmeasure = a.fmeasure
               ,otmeasure = a.tmeasure 
               WHERE 
                   a.terminalpathid =  p_start_flowline.terminalpathid
               AND a.levelpathid    =  num_level_path_id 
               AND a.hydroseq       >= num_hydro_seq_no
               RETURNING a.hydroseq
            )
            SELECT MAX(b.hydroseq) INTO num_max_hydro_seq FROM cte_update b;
            
         END IF;
         
         GET DIAGNOSTICS num_updated = ROW_COUNT;

         IF num_updated > 0
         THEN
            -- Get infomation from the working record for the max hs to ...
            --  prepare for next iteration
            --  update to1, totaldist if max distance has been reached.
            SELECT 
            a.uphydroseq, 
            a.uplevelpathid, 
            a.pathlength, 
            a.lengthkm, 
            a.pathtime, 
            a.travtime, 
            a.tmeasure, 
            a.fmeasure 
            INTO 
             num_max_hydro_seq_ushs
            ,num_max_hydro_seq_uslp
            ,num_W_path_length
            ,num_W_lengthkm
            ,num_W_path_time
            ,num_W_trav_time
            ,num_W_tomeas
            ,num_W_frommeas
            FROM 
            tmp_navigation_working a 
            WHERE 
            a.hydroseq = num_max_hydro_seq;

            -----------------------------------------------------------------
            -- Need numMaxUsHS, numMaxUSlp to prepare for next iteration of loop
            -- Need numWPathlength, numWlengthkm, numWPathtime, numWTravtime, numWtomeas, numWfrommeas to update to1
            --  (and determine if to1 needs to be updated)
            -- Update to1, totaldist based on distance, and totaltime based on travel time if necessary
            -----------------------------------------------------------------
            IF p_num_max_distance IS NOT NULL
            THEN
               IF num_W_path_length + num_W_lengthkm > p_start_path_length + p_num_max_distance
               THEN
                  IF num_W_Tomeas IS NULL
                  THEN
                     --End NHDFlowline has null measures.  Do nothing.
                     NULL; 
                     
                  ELSE
                     -- Reset to1 with a calculated measure and totaldist with maxdistance 
                     -- and totaltime with calculated totaltime
                     num_W_calc_meas := nhdplus_navigation.measure_at_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_lengthkm
                        ,p_distance      := p_start_path_length + p_num_max_distance - num_W_path_length
                        ,p_half          := 'BOTTOM'
                     );
                     
                     num_W_calc_time := nhdplus_navigation.included_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_trav_time
                        ,p_measure       := num_w_calc_meas
                        ,p_half          := 'BOTTOM'
                     );

                     UPDATE tmp_navigation_working a 
                     SET 
                      otmeasure = num_W_calc_meas
                     ,totaldist = p_num_max_distance
                     ,totaltime = num_W_path_time + num_W_calc_time - p_start_path_time
                     WHERE 
                     a.hydroseq = num_max_hydro_seq;

                  END IF;

                  boo_continue := FALSE;

                  IF p_navigation_type = 'UM'
                  THEN
                     p_stop_condition_met := 1;
                     
                  END IF;
                  
               END IF;

            ELSIF p_num_max_time IS NOT NULL
            THEN
               IF num_W_path_time + num_W_trav_time > p_start_path_time + p_num_max_time
               THEN
                  IF num_W_tomeas IS NULL
                  THEN
                     NULL; --End NHDFlowline has null measures.  Do nothing.
                     
                  ELSE
                     --Reset to1 with a calculated measure and totaldist with maxdistance
                     num_W_calc_meas:= nhdplus_navigation.measure_at_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_trav_time
                        ,p_distance      := p_start_path_time + p_num_max_time - num_W_path_time
                        ,p_half          := 'BOTTOM'
                     );
                     
                     num_W_calc_dis := nhdplus_navigation.included_distance(
                         p_fmeasure      := num_W_frommeas
                        ,p_tmeasure      := num_W_tomeas
                        ,p_length        := num_W_lengthkm
                        ,p_measure       := num_W_calc_meas
                        ,p_half          := 'BOTTOM'
                     );

                     UPDATE tmp_navigation_working a 
                     SET 
                      otmeasure = num_W_calc_meas
                     ,totaldist = num_W_path_length + num_W_calc_dis - p_start_path_length
                     ,totaltime = p_num_max_time
                     WHERE 
                     a.hydroseq = num_max_hydro_seq;

                  END IF;

                  boo_continue := FALSE;

                  IF p_navigation_type = 'UM'
                  THEN
                     p_stop_condition_met := 1;
                     
                  END IF;
                  
               END IF;

            END IF;

         ELSE
            boo_continue := FALSE;
            
         END IF;

      ELSE
         boo_continue := FALSE;

      END IF;

   END LOOP;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate_upmain(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric) OWNER TO nhdplus_navigation;

--
-- Name: navigate_uptrib(character varying, flowline_rec, numeric, numeric, numeric, numeric, numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate_uptrib(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   boo_continue           BOOLEAN := TRUE;
   num_selected_pre       INTEGER := -1;
   num_selected_post      INTEGER := -1;
   num_iteration          INTEGER :=  1;
   num_updated            INTEGER :=  0;
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- MAIN UPTRIB Loop - do until nothing more is selected
   --------------------------------------------------------------------------
   WHILE boo_continue
   LOOP
      -- GET PRE-UPDATE SELECTED count if NECESSARY
      IF num_selected_post = -1
      THEN
         SELECT 
         COUNT(*) 
         INTO num_selected_pre
         FROM 
         tmp_navigation_working a 
         WHERE 
         a.selected >= 1;

      ELSE
         num_selected_pre := num_selected_post;
         
      END IF;
      
      TRUNCATE TABLE tmp_navigation_uptrib;

      INSERT INTO tmp_navigation_uptrib
      SELECT
       b.fromlevelpathid
      ,MIN(b.fromhydroseq) AS minhs
      FROM
      tmp_navigation_working a
      JOIN
      nhdplus.plusflow_np21 b
      ON
      a.nhdplus_comid = b.tocomid
      WHERE
          a.selected = num_iteration
      AND b.nhdplus_region = p_start_flowline.nhdplus_region
      GROUP BY
      b.fromlevelpathid;

      --DO UPDATE
      num_iteration := num_iteration + 1;

      IF p_num_max_distance IS NOT NULL
      THEN
         UPDATE tmp_navigation_working a 
         SET 
          selected  = num_iteration
         ,ofmeasure = a.fmeasure
         ,otmeasure = a.tmeasure 
         WHERE 
             a.pathlength <= p_start_path_length + p_num_max_distance 
         AND a.hydroseq >= (
            SELECT 
            b.minHS 
            FROM 
            tmp_navigation_uptrib b 
            WHERE 
            b.fromlevelpathid = a.levelpathid
         );

      ELSIF p_num_max_time IS NOT NULL
      THEN
         UPDATE tmp_navigation_working a 
         SET 
          selected  = num_iteration
         ,ofmeasure = a.fmeasure
         ,otmeasure = a.tmeasure 
         WHERE 
             a.pathtime <= p_start_path_time + p_num_max_time
         AND a.hydroseq >= (
            SELECT
            b.minHS
            FROM
            tmp_navigation_uptrib b 
            WHERE
            b.fromlevelpathid = a.levelpathid
         );

      ELSE
         UPDATE tmp_navigation_working a 
         SET 
          selected  = num_iteration
         ,ofmeasure = a.fmeasure
         ,otmeasure = a.tmeasure 
         WHERE 
         a.hydroseq >= (
            SELECT 
            b.minHS 
            FROM 
            tmp_navigation_uptrib b
            WHERE 
            b.fromlevelpathid = a.levelpathid
         );

      END IF;

      GET DIAGNOSTICS num_updated = ROW_COUNT;

      --GET POST-UPDATE SELECTED count
      SELECT 
      COUNT(*) 
      INTO num_selected_post
      FROM 
      tmp_navigation_working a 
      WHERE 
      a.selected >= 1;

      IF num_selected_pre = num_selected_post
      THEN
         boo_continue := FALSE;
         
      END IF;

   END LOOP;

   --------------------------------------------------------------------------
   -- Update measures at the end of paths where necessary 
   -- if there is a stop distance.
   --------------------------------------------------------------------------
   IF p_num_max_distance IS NOT NULL
   THEN
      UPDATE tmp_navigation_working a 
      SET 
       otmeasure = (a.ofmeasure + ((a.otmeasure - a.ofmeasure) / a.lengthkm) * ((p_start_path_length + p_num_max_distance) - a.pathlength))
      ,totaldist = p_num_max_distance
      WHERE 
          a.selected >= 1
      AND a.otmeasure = a.tmeasure
      AND a.pathlength + lengthkm > p_start_path_length + p_num_max_distance;

      UPDATE tmp_navigation_working a 
      SET 
      totaltime = (a.pathtime + (a.travtime - (a.travtime * ((a.tmeasure - a.otmeasure) / (a.tmeasure - a.fmeasure))))) - p_start_path_time
      WHERE 
      a.selected >= 1 AND 
      a.otmeasure <> a.tmeasure AND 
      a.pathlength + a.lengthkm > p_start_path_length + p_num_max_distance;

   ELSIF p_num_max_time IS NOT NULL
   THEN
      UPDATE tmp_navigation_working a 
      SET 
       otmeasure = (a.ofmeasure + ((a.otmeasure - a.ofmeasure) / a.travtime) * ((p_start_path_time + p_num_max_time) - a.pathtime)) 
      ,totaltime = p_num_max_time
      WHERE 
          a.selected >= 1
      AND a.otmeasure = a.tmeasure
      AND a.pathtime + a.travtime > p_start_path_time + p_num_max_time;

      UPDATE tmp_navigation_working a 
      SET 
      totaldist = (a.pathlength + (a.lengthkm - (a.lengthkm * ((a.tmeasure - a.otmeasure) / (a.tmeasure - a.fmeasure))))) - p_start_path_length
      WHERE 
          a.selected >= 1
      AND a.otmeasure <> a.tmeasure
      AND a.pathtime + a.travtime > p_start_path_time + p_num_max_time;

   END IF;
   
   TRUNCATE TABLE tmp_navigation_uptrib;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate_uptrib(p_navigation_type character varying, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, p_start_path_length numeric, p_start_path_time numeric, INOUT p_stop_condition_met numeric) OWNER TO nhdplus_navigation;

--
-- Name: navigate_vpu_core(character varying, integer, character varying, character varying, numeric, integer, character varying, character varying, numeric, numeric, numeric, character varying, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION navigate_vpu_core(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, psessionid character varying, pdebug character varying DEFAULT 'FALSE'::character varying, OUT pcheckstartcomid integer, OUT pcheckstartpermanentidentifier character varying, OUT pcheckstartmeasure numeric, OUT pcheckstartpathlength numeric, OUT pcheckstartpathtime numeric, OUT pcheckstartincdist numeric, OUT pcheckstartinctime numeric, OUT pcheckstopcomid integer, OUT pcheckstoppermanentidentifier character varying, OUT pcheckstopmeasure numeric, OUT pcheckstopincdist numeric, OUT pcheckstopinctime numeric, OUT pcheckstopconditionmet numeric, OUT pcheckstartflowline flowline_rec, OUT pcheckstopflowline flowline_rec, OUT preturncode numeric, OUT pstatusmessage character varying) RETURNS record
    LANGUAGE plpgsql
    AS $$
DECLARE
   str_nav_type              VARCHAR(4000) := UPPER(pNavigationType);
   num_maximum_distance_km   NUMERIC := pMaxDistanceKm;
   num_maximum_flowtime_hour NUMERIC := pMaxFlowTimeHour;
   num_count                 NUMERIC;
   num_measure_range         NUMERIC;
   int_return_code           INTEGER;
   r                         RECORD;
      
BEGIN
   
   -----------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   -----------------------------------------------------------------------------
   pReturnCode                    := 0;
   
   pCheckStartComID               := pStartComID;
   pCheckStartPermanentIdentifier := pStartPermanentIdentifier;
   pCheckStartMeasure             := pStartMeasure;
   
   pCheckStopComID                := pStopComID;
   pCheckStopPermanentIdentifier  := pStopPermanentIdentifier;
   pCheckStopMeasure              := pStopMeasure;
   
   pCheckStopConditionMet         := 0;
   
   IF str_nav_type NOT IN ('UM','UT','DM','DD','PP')
   THEN
      pReturnCode    := -1;
      pStatusMessage := 'Valid navigation type codes are UM, UT, DM, DD and PP.';
      RETURN;
   
   END IF;
   
   IF str_nav_type = 'PP'
   THEN
      num_maximum_distance_km   := NULL;
      num_maximum_flowtime_hour := NULL;
      
   END IF;
   
   -----------------------------------------------------------------------------
   -- Step 20
   -- Flush or create the temp tables
   -----------------------------------------------------------------------------
   int_return_code := nhdplus_navigation.create_temp_tables();
   
   --------------------------------------------------------------------------
   -- Step 30
   -- Load start flowline
   --------------------------------------------------------------------------
   r := nhdplus_navigation.query_single_flowline(
       p_navigation_type      := str_nav_type
      ,p_comid                := pCheckStartComID
      ,p_permanent_identifier := pCheckStartPermanentIdentifier
      ,p_hydrosequence        := NULL
      ,p_reachcode            := pStartReachcode 
      ,p_measure              := pCheckStartMeasure
      ,p_check_intent         := NULL
   );
   pCheckStartFlowline            := r.p_output;
   pCheckStartComID               := r.p_check_comid;
   pCheckStartPermanentIdentifier := r.p_check_permanent_identifier;
   pCheckStartMeasure             := r.p_check_measure;
   pReturnCode                    := r.p_return_code;
   pStatusMessage                 := r.p_status_message;
   
   IF pReturnCode <> 0
   THEN
      RETURN;
       
   END IF;
   
   IF pDebug = 'TRUE'
   THEN
      RAISE DEBUG 'start flowline: %', pCheckStartPermanentIdentifier;
      RAISE DEBUG 'start measure: %', pCheckStartMeasure;
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 30
   -- Load stop flowline if required
   --------------------------------------------------------------------------
   IF str_nav_type = 'PP'
   THEN
      r := nhdplus_navigation.query_single_flowline(
          p_navigation_type      := NULL
         ,p_comid                := pCheckStopComID
         ,p_permanent_identifier := pCheckStopPermanentIdentifier
         ,p_hydrosequence        := NULL
         ,p_reachcode            := pStopReachcode 
         ,p_measure              := pCheckStopMeasure
         ,p_check_intent         := 'STOP'
      );
      pCheckStopFlowline            := r.p_output;
      pCheckStopComID               := r.p_check_comid;
      pCheckStopPermanentIdentifier := r.p_check_permanent_identifier;
      pCheckStopMeasure             := r.p_check_measure;
      pReturnCode                   := r.p_return_code;
      pStatusMessage                := r.p_status_message;
       
      IF pReturnCode <> 0
      THEN
         RETURN;
           
      END IF;
      
      IF  pCheckStartFlowline.hydroseq < pCheckStopFlowline.hydroseq
      AND pCheckStartFlowline.nhdplus_region = pCheckStopFlowline.nhdplus_region
      THEN
         pReturnCode    := 310;
         pStatusMessage := 'Start ComID must have a hydroseq greater than the hydroseq for stop ComID.';
         RETURN;
         
      END IF;
      
      IF pDebug = 'TRUE'
      THEN
         RAISE DEBUG 'stop flowline: %', pCheckStopPermanentIdentifier;
         RAISE DEBUG 'stop measure: %', pCheckStopMeasure;
         
      END IF;
   
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 40
   -- Account for PP navigation shorter than the flowline
   --------------------------------------------------------------------------
   IF str_nav_type = 'PP'
   AND pCheckStartComID = pCheckStopComID
   THEN
      IF pCheckStartMeasure <= pCheckStopMeasure
      THEN
         pReturnCode    := 311;
         pStatusMessage := 'Start measure must be greater than stop measure when navigating a single reach.';
         RETURN;
       
      END IF;
      
      num_measure_range       := pCheckStartMeasure - pCheckStopMeasure;  
      
      pCheckStartIncDist      := ROUND(num_measure_range * pCheckStartFlowline.length_measure_ratio,5);
      pCheckStartIncTime      := ROUND(num_measure_range * pCheckStartFlowline.time_measure_ratio,5);
      
      INSERT INTO tmp_navigation_working(
          start_permanent_identifier
         ,permanent_identifier
         ,start_nhdplus_comid
         ,nhdplus_comid
         ,reachcode
         ,fmeasure
         ,tmeasure
         ,totaldist
         ,totaltime
         ,hydroseq
         ,levelpathid
         ,terminalpathid
         ,uphydroseq
         ,uplevelpathid
         ,dnhydroseq
         ,dnlevelpathid
         ,dnminorhyd
         ,divergence
         ,dndraincount
         ,pathlength
         ,lengthkm
         ,length_measure_ratio
         ,pathtime
         ,travtime
         ,time_measure_ratio
         ,ofmeasure
         ,otmeasure
         ,selected
         ,nhdplus_region
         ,nhdplus_version
      ) VALUES (
          pCheckStartFlowline.permanent_identifier
         ,pCheckStartFlowline.permanent_identifier
         ,pCheckStartFlowline.nhdplus_comid 
         ,pCheckStartFlowline.nhdplus_comid 
         ,pCheckStartFlowline.reachcode
         ,pCheckStopMeasure
         ,pCheckStartMeasure
         ,pCheckStartIncDist
         ,pCheckStartIncTime           
         ,pCheckStartFlowline.hydroseq
         ,pCheckStartFlowline.levelpathid
         ,pCheckStartFlowline.terminalpathid
         ,pCheckStartFlowline.uphydroseq
         ,pCheckStartFlowline.uplevelpathid
         ,pCheckStartFlowline.dnhydroseq
         ,pCheckStartFlowline.dnlevelpathid
         ,NULL 
         ,NULL
         ,NULL
         ,pCheckStartIncDist  -- path length
         ,pCheckStartFlowline.lengthkm
         ,pCheckStartFlowline.length_measure_ratio
         ,pCheckStartIncTime  --path time
         ,pCheckStartFlowline.travtime
         ,pCheckStartFlowline.time_measure_ratio
         ,pCheckStopMeasure
         ,pCheckStartMeasure
         ,1
         ,pCheckStartFlowline.nhdplus_region
         ,pCheckStartFlowline.nhdplus_version
      );
            
      pCheckStopConditionMet := 1;
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 50
   -- Account for DD,DM,UM,UT navigation shorter than the flowline
   --------------------------------------------------------------------------
   IF num_maximum_distance_km IS NOT NULL
   OR num_maximum_flowtime_hour IS NOT NULL
   THEN
      IF str_nav_type IN ('UM','UT')
      AND num_maximum_distance_km IS NOT NULL
      AND num_maximum_distance_km <= (pCheckStartFlowline.tmeasure - pCheckStartMeasure) * pCheckStartFlowline.length_measure_ratio
      THEN
         num_measure_range       := num_maximum_distance_km / pCheckStartFlowline.length_measure_ratio;
         
         pCheckStartIncDist      := ROUND(num_measure_range * pCheckStartFlowline.length_measure_ratio,5);
         pCheckStartIncTime      := ROUND(num_measure_range * pCheckStartFlowline.time_measure_ratio,5);
         
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         ) VALUES (
             pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.reachcode
            ,pCheckStartMeasure
            ,ROUND(pCheckStartMeasure + num_measure_range,5)
            ,num_maximum_distance_km
            ,pCheckStartIncTime          
            ,pCheckStartFlowline.hydroseq
            ,pCheckStartFlowline.levelpathid
            ,pCheckStartFlowline.terminalpathid
            ,pCheckStartFlowline.uphydroseq
            ,pCheckStartFlowline.uplevelpathid
            ,pCheckStartFlowline.dnhydroseq
            ,pCheckStartFlowline.dnlevelpathid
            ,NULL 
            ,NULL
            ,NULL
            ,pCheckStartIncDist
            ,pCheckStartFlowline.lengthkm
            ,pCheckStartFlowline.length_measure_ratio
            ,pCheckStartIncTime
            ,pCheckStartFlowline.travtime
            ,pCheckStartFlowline.time_measure_ratio
            ,pCheckStartMeasure
            ,ROUND(pCheckStartMeasure + num_measure_range,5)
            ,1
            ,pCheckStartFlowline.nhdplus_region
            ,pCheckStartFlowline.nhdplus_version
         );
            
         pCheckStopConditionMet := 1;
         
      ELSIF str_nav_type IN ('UM','UT')
      AND num_maximum_flowtime_hour IS NOT NULL
      AND num_maximum_flowtime_hour <= (pCheckStartFlowline.tmeasure - pCheckStartMeasure) * pCheckStartFlowline.time_measure_ratio  
      THEN
         num_measure_range      := num_maximum_flowtime_hour / pCheckStartFlowline.time_measure_ratio;
         
         pCheckStartIncDist      := ROUND(num_measure_range * pCheckStartFlowline.length_measure_ratio,5);
         pCheckStartIncTime      := ROUND(num_measure_range * pCheckStartFlowline.time_measure_ratio,5);
            
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         ) VALUES (
             pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.reachcode
            ,pCheckStartMeasure
            ,ROUND(pCheckStartMeasure + num_measure_range,5)
            ,pCheckStartIncDist
            ,num_maximum_flowtime_hour         
            ,pCheckStartFlowline.hydroseq
            ,pCheckStartFlowline.levelpathid
            ,pCheckStartFlowline.terminalpathid
            ,pCheckStartFlowline.uphydroseq
            ,pCheckStartFlowline.uplevelpathid
            ,pCheckStartFlowline.dnhydroseq
            ,pCheckStartFlowline.dnlevelpathid
            ,NULL 
            ,NULL
            ,NULL
            ,pCheckStartIncDist
            ,pCheckStartFlowline.lengthkm
            ,pCheckStartFlowline.length_measure_ratio
            ,pCheckStartIncTime
            ,pCheckStartFlowline.travtime
            ,pCheckStartFlowline.time_measure_ratio
            ,pCheckStartMeasure
            ,ROUND(pCheckStartMeasure + num_measure_range,5)
            ,1
            ,pCheckStartFlowline.nhdplus_region
            ,pCheckStartFlowline.nhdplus_version
         );
            
         pCheckStopConditionMet := 1;
      
      ELSIF str_nav_type IN ('DM','DD')
      AND num_maximum_distance_km IS NOT NULL
      AND num_maximum_distance_km <= (pCheckStartMeasure - pCheckStartFlowline.fmeasure) * pCheckStartFlowline.length_measure_ratio 
      THEN
         num_measure_range       := num_maximum_distance_km / pCheckStartFlowline.length_measure_ratio;
         pCheckStartIncDist      := ROUND(num_measure_range * pCheckStartFlowline.length_measure_ratio,5);
         pCheckStartIncTime      := ROUND(num_measure_range * pCheckStartFlowline.time_measure_ratio,5);
               
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         ) VALUES (
             pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.reachcode
            ,ROUND(pCheckStartMeasure - num_measure_range,5)
            ,pCheckStartMeasure
            ,num_maximum_distance_km
            ,num_measure_range * pCheckStartFlowline.time_measure_ratio      
            ,pCheckStartFlowline.hydroseq
            ,pCheckStartFlowline.levelpathid
            ,pCheckStartFlowline.terminalpathid
            ,pCheckStartFlowline.uphydroseq
            ,pCheckStartFlowline.uplevelpathid
            ,pCheckStartFlowline.dnhydroseq
            ,pCheckStartFlowline.dnlevelpathid
            ,NULL 
            ,NULL
            ,NULL
            ,pCheckStartIncDist
            ,pCheckStartFlowline.lengthkm
            ,pCheckStartFlowline.length_measure_ratio
            ,pCheckStartIncTime
            ,pCheckStartFlowline.travtime
            ,pCheckStartFlowline.time_measure_ratio
            ,ROUND(pCheckStartMeasure - num_measure_range,5)
            ,pCheckStartMeasure
            ,1
            ,pCheckStartFlowline.nhdplus_region
            ,pCheckStartFlowline.nhdplus_version
         );
               
         pCheckStopConditionMet := 1;
               
      ELSIF str_nav_type IN ('DM','DD')
      AND num_maximum_flowtime_hour IS NOT NULL
      AND num_maximum_flowtime_hour <= (pCheckStartMeasure - pCheckStartFlowline.fmeasure) * pCheckStartFlowline.time_measure_ratio
      THEN
         num_measure_range  := num_maximum_flowtime_hour / pCheckStartFlowline.time_measure_ratio;
         pCheckStartIncDist := ROUND(num_measure_range * pCheckStartFlowline.length_measure_ratio,5);
         pCheckStartIncTime := ROUND(num_measure_range * pCheckStartFlowline.time_measure_ratio,5);
               
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         ) VALUES (
             pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.permanent_identifier
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.nhdplus_comid
            ,pCheckStartFlowline.reachcode
            ,ROUND(pCheckStartMeasure - num_measure_range,5)
            ,pCheckStartMeasure
            ,num_measure_range * pCheckStartFlowline.length_measure_ratio
            ,num_maximum_flowtime_hour     
            ,pCheckStartFlowline.hydroseq
            ,pCheckStartFlowline.levelpathid
            ,pCheckStartFlowline.terminalpathid
            ,pCheckStartFlowline.uphydroseq
            ,pCheckStartFlowline.uplevelpathid
            ,pCheckStartFlowline.dnhydroseq
            ,pCheckStartFlowline.dnlevelpathid
            ,NULL 
            ,NULL
            ,NULL
            ,pCheckStartIncDist
            ,pCheckStartFlowline.lengthkm
            ,pCheckStartFlowline.length_measure_ratio
            ,pCheckStartIncTime
            ,pCheckStartFlowline.travtime
            ,pCheckStartFlowline.time_measure_ratio
            ,ROUND(pCheckStartMeasure - num_measure_range,5)
            ,pCheckStartMeasure
            ,1
            ,pCheckStartFlowline.nhdplus_region
            ,pCheckStartFlowline.nhdplus_version
         );
               
         pCheckStopConditionMet := 1;
            
      END IF;
      
   END IF;

   --------------------------------------------------------------------------
   -- Step 60
   -- Run reference calculations
   --------------------------------------------------------------------------
   IF pCheckStopConditionMet <> 1
   THEN
      r := nhdplus_navigation.reference_calculations(
          p_navigation_type   := str_nav_type
         ,p_start_measure     := pCheckStartMeasure
         ,p_start_flowline    := pCheckStartFlowline
         ,p_num_max_distance  := num_maximum_distance_km
         ,p_num_max_time      := num_maximum_flowtime_hour
      );
      pCheckStartPathLength := r.p_start_path_length;
      pCheckStartPathTime   := r.p_start_path_time;
      pCheckStartIncDist    := r.p_start_inc_dist;
      pCheckStartIncTime    := r.p_start_inc_time;
  
      IF pDebug = 'TRUE'
      THEN
         RAISE DEBUG 'Start Path Length: %', pCheckStartPathLength;
         RAISE DEBUG 'Start Inc Distance: %', pCheckStartIncDist;
               
      END IF;
         
   END IF;
     
   --------------------------------------------------------------------------
   -- Step 70
   -- Prepare the working table
   --------------------------------------------------------------------------
   IF pCheckStopConditionMet <> 1
   THEN
      int_return_code := nhdplus_navigation.prepare_working_table(
          p_navigation_type   := str_nav_type
         ,p_num_max_distance  := num_maximum_distance_km
         ,p_num_max_time      := num_maximum_flowtime_hour
         ,p_start_flowline    := pCheckStartFlowline
         ,p_stop_flowline     := pCheckStopFlowline
         ,p_start_path_length := pCheckStartPathLength
         ,p_start_path_time   := pCheckStartPathTime
      );
         
      IF pDebug = 'TRUE'
      THEN
         SELECT COUNT(*) INTO num_count FROM tmp_navigation_working;
         RAISE DEBUG 'prepare working table: %', num_count;
            
      END IF;
      
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 90
   -- Process Upstream Variations
   --------------------------------------------------------------------------
   IF  str_nav_type IN ('UM','UT')
   AND pCheckStopConditionMet <> 1
   THEN
      pCheckStopConditionMet := nhdplus_navigation.navigate_upmain(
          p_navigation_type    := str_nav_type
         ,p_start_flowline     := pCheckStartFlowline
         ,p_num_max_distance   := num_maximum_distance_km
         ,p_num_max_time       := num_maximum_flowtime_hour
         ,p_start_path_length  := pCheckStartPathLength
         ,p_start_path_time    := pCheckStartPathTime
         ,p_stop_condition_met := pCheckStopConditionMet
      );
      
      IF pDebug = 'TRUE'
      THEN
         SELECT COUNT(*) INTO num_count FROM tmp_navigation_working;
         RAISE DEBUG 'navigate upmain: %', num_count;
         
      END IF;
      
      IF str_nav_type = 'UT'
      THEN
         pCheckStopConditionMet := nhdplus_navigation.navigate_uptrib(
             p_navigation_type    := str_nav_type
            ,p_start_flowline     := pCheckStartFlowline
            ,p_num_max_distance   := num_maximum_distance_km
            ,p_num_max_time       := num_maximum_flowtime_hour
            ,p_start_path_length  := pCheckStartPathLength
            ,p_start_path_time    := pCheckStartPathTime
            ,p_stop_condition_met := pCheckStopConditionMet
         );
         
         IF pDebug = 'TRUE'
         THEN
            SELECT COUNT(*) INTO num_count FROM tmp_navigation_working;
            RAISE DEBUG 'navigate uptrib: %', num_count;
            
         END IF;
      
      END IF;
   
   END IF;

   --------------------------------------------------------------------------
   -- Step 100
   -- Process Downstream Variations
   --------------------------------------------------------------------------
   IF  str_nav_type IN ('DM','DD','PP')
   AND pCheckStopConditionMet <> 1
   THEN        
      pCheckStopConditionMet := nhdplus_navigation.navigate_dnmain(
          p_navigation_type    := str_nav_type
         ,p_start_flowline     := pCheckStartFlowline
         ,p_stop_flowline      := pCheckStopFlowline
         ,p_stop_comid         := pCheckStopComID
         ,p_stop_measure       := pCheckStopMeasure
         ,p_num_max_distance   := num_maximum_distance_km
         ,p_num_max_time       := num_maximum_flowtime_hour
         ,p_start_path_length  := pCheckStartPathLength
         ,p_start_path_time    := pCheckStartPathTime
         ,p_stop_condition_met := pCheckStopConditionMet
         ,p_debug              := pDebug 
      );

      IF str_nav_type = 'DD'
      THEN
         int_return_code := nhdplus_navigation.navigate_dndiv(
             p_navigation_type    := str_nav_type
            ,p_start_flowline     := pCheckStartFlowline
            ,p_stop_flowline      := pCheckStopFlowline
            ,p_num_max_distance   := num_maximum_distance_km
            ,p_num_max_time       := num_maximum_flowtime_hour
            ,p_start_path_length  := pCheckStartPathLength
            ,p_start_path_time    := pCheckStartPathTime
         );
         
      ELSIF str_nav_type = 'PP'
      THEN
         SELECT
         COUNT(*)
         INTO num_count
         FROM
         tmp_navigation_working a
         WHERE
         a.nhdplus_comid = pCheckStopFlowline.nhdplus_comid AND
         a.selected = 1;
/*
         IF num_count <> 1
         THEN
            pReturnCode    := 311;
            pStatusMessage := 'Stop ComID not in downmain path from start ComID.';
            RETURN;
                 
         END IF;
*/       
      END IF;
   
   END IF;
   
   --------------------------------------------------------------------------
   -- Step 110
   -- Load the results tables
   --------------------------------------------------------------------------
   IF  str_nav_type IN ('UM','UT')
   THEN
      INSERT INTO nhdplus_navigation.tmp_navigation_results(
          objectid
         ,session_id
         ,start_permanent_identifier
         ,permanent_identifier
         ,start_nhdplus_comid
         ,nhdplus_comid
         ,reachcode
         ,fmeasure
         ,tmeasure
         ,totaldist
         ,totaltime
         ,hydroseq
         ,levelpathid
         ,terminalpathid
         ,uphydroseq
         ,dnhydroseq
         ,pathlength
         ,lengthkm
         ,length_measure_ratio
         ,pathtime
         ,travtime
         ,time_measure_ratio
         ,ofmeasure
         ,otmeasure
         ,nhdplus_region
         ,nhdplus_version
      ) 
      SELECT 
       nextval('nhdplus_navigation.tmp_navigation_results_seq')
      ,pSessionID
      ,a.start_permanent_identifier
      ,a.permanent_identifier
      ,a.start_nhdplus_comid
      ,a.nhdplus_comid
      ,a.reachcode
      ,ROUND(a.ofmeasure,5)
      ,ROUND(a.otmeasure,5)
      ,a.totaldist
      ,a.totaltime
      ,a.hydroseq
      ,a.levelpathid
      ,a.terminalpathid
      ,a.uphydroseq
      ,a.dnhydroseq
      ,a.pathlength
      ,a.lengthkm
      ,a.length_measure_ratio
      ,a.pathtime
      ,a.travtime
      ,a.time_measure_ratio
      ,ROUND(a.fmeasure,5)
      ,ROUND(a.tmeasure,5) 
      ,a.nhdplus_region
      ,a.nhdplus_version
      FROM 
      tmp_navigation_working a 
      WHERE 
      a.selected >= 1 
      ORDER BY 
      a.hydroseq;
      
   ELSIF str_nav_type IN ('DM','DD','PP')
   THEN
      INSERT INTO nhdplus_navigation.tmp_navigation_results(
          objectid
         ,session_id
         ,start_permanent_identifier
         ,permanent_identifier
         ,start_nhdplus_comid
         ,nhdplus_comid
         ,reachcode
         ,fmeasure
         ,tmeasure
         ,totaldist
         ,totaltime
         ,hydroseq
         ,levelpathid
         ,terminalpathid
         ,uphydroseq
         ,dnhydroseq
         ,pathlength
         ,lengthkm
         ,length_measure_ratio
         ,pathtime
         ,travtime
         ,time_measure_ratio
         ,ofmeasure
         ,otmeasure
         ,nhdplus_region
         ,nhdplus_version
      ) 
      SELECT 
       nextval('nhdplus_navigation.tmp_navigation_results_seq')
      ,pSessionID
      ,a.start_permanent_identifier
      ,a.permanent_identifier
      ,a.start_nhdplus_comid
      ,a.nhdplus_comid
      ,a.reachcode
      ,ROUND(a.ofmeasure,5)
      ,ROUND(a.otmeasure,5)
      ,a.totaldist
      ,a.totaltime
      ,a.hydroseq
      ,a.levelpathid
      ,a.terminalpathid
      ,a.uphydroseq
      ,a.dnhydroseq
      ,a.pathlength
      ,a.lengthkm
      ,a.length_measure_ratio
      ,a.pathtime
      ,a.travtime
      ,a.time_measure_ratio
      ,ROUND(a.fmeasure,5)
      ,ROUND(a.tmeasure,5)
      ,a.nhdplus_region
      ,a.nhdplus_version
      FROM 
      tmp_navigation_working a 
      WHERE 
      a.selected >= 1 
      ORDER BY
      a.hydroseq DESC;
      
   END IF;
      
END;
$$;


ALTER FUNCTION nhdplus_navigation.navigate_vpu_core(pnavigationtype character varying, pstartcomid integer, pstartpermanentidentifier character varying, pstartreachcode character varying, pstartmeasure numeric, pstopcomid integer, pstoppermanentidentifier character varying, pstopreachcode character varying, pstopmeasure numeric, pmaxdistancekm numeric, pmaxflowtimehour numeric, psessionid character varying, pdebug character varying, OUT pcheckstartcomid integer, OUT pcheckstartpermanentidentifier character varying, OUT pcheckstartmeasure numeric, OUT pcheckstartpathlength numeric, OUT pcheckstartpathtime numeric, OUT pcheckstartincdist numeric, OUT pcheckstartinctime numeric, OUT pcheckstopcomid integer, OUT pcheckstoppermanentidentifier character varying, OUT pcheckstopmeasure numeric, OUT pcheckstopincdist numeric, OUT pcheckstopinctime numeric, OUT pcheckstopconditionmet numeric, OUT pcheckstartflowline flowline_rec, OUT pcheckstopflowline flowline_rec, OUT preturncode numeric, OUT pstatusmessage character varying) OWNER TO nhdplus_navigation;

--
-- Name: prepare_working_table(character varying, numeric, numeric, flowline_rec, flowline_rec, numeric, numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION prepare_working_table(p_navigation_type character varying, p_num_max_distance numeric, p_num_max_time numeric, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_start_path_length numeric, p_start_path_time numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE
BEGIN
   
   IF p_navigation_type IN ('UM','UT')
   THEN
      --Copy to working all flowlines with a greater hydroseq. (i.e. above the starting permid in the network)
      --If a max stop distance has been supplied, use that to further limit the record count in working.
      
      IF p_num_max_distance IS NOT NULL
      THEN
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a 
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq   >= p_start_flowline.hydroseq
         AND a.pathlength <= p_start_path_length + p_num_max_distance;
         
      ELSIF p_num_max_time IS NOT NULL
      THEN
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a 
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq >= p_start_flowline.hydroseq
         AND a.pathtime <= p_start_path_time + p_num_max_time;

      ELSE
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a 
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq >= p_start_flowline.hydroseq;

      END IF;

   ELSIF p_navigation_type IN ('DM','DD','PP')
   THEN
      --Copy to working all flowlines with a lesser hydroseq. (i.e. below the starting comid in the network)
      --If a max stop distance has been supplied, use that to further limit the record count in working.
      
      IF p_num_max_distance IS NOT NULL
      AND p_navigation_type = 'DM'
      THEN
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.frommeas
         ,a.tomeas
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq <= p_start_flowline.hydroseq 
         AND a.pathlength + a.lengthkm >= p_start_path_length - p_num_max_distance;

      ELSIF p_num_max_time IS NOT NULL
      AND p_navigation_type = 'DM'
      THEN
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq <= p_start_flowline.hydroseq  
         AND a.pathtime + a.travtime >= p_start_path_time - p_num_max_time;

      ELSIF p_navigation_type = 'PP'
      THEN
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq <= p_start_flowline.hydroseq  
         AND a.hydroseq >= p_stop_flowline.hydroseq;

      ELSE
         INSERT INTO tmp_navigation_working(
             start_permanent_identifier
            ,permanent_identifier
            ,start_nhdplus_comid
            ,nhdplus_comid
            ,reachcode
            ,fmeasure
            ,tmeasure
            ,totaldist
            ,totaltime
            ,hydroseq
            ,levelpathid
            ,terminalpathid
            ,uphydroseq
            ,uplevelpathid
            ,dnhydroseq
            ,dnlevelpathid
            ,dnminorhyd
            ,divergence
            ,dndraincount
            ,pathlength
            ,lengthkm
            ,length_measure_ratio
            ,pathtime
            ,travtime
            ,time_measure_ratio
            ,ofmeasure
            ,otmeasure
            ,selected
            ,nhdplus_region
            ,nhdplus_version
         )
         SELECT
          p_start_flowline.permanent_identifier
         ,a.permanent_identifier
         ,p_start_flowline.nhdplus_comid
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,NULL AS totaldist
         ,NULL AS totaltime
         ,a.hydroseq
         ,a.levelpathid
         ,a.terminalpathid
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.dnminorhyd
         ,a.divergence
         ,a.dndraincount
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure) AS length_measure_ratio
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure) AS time_measure_ratio
         ,NULL AS ofmeasure
         ,NULL AS otmeasure
         ,0
         ,a.nhdplus_region
         ,a.nhdplus_version
         FROM 
         nhdplus.plusflowlinevaa_np21 a
         WHERE
             a.nhdplus_region = p_start_flowline.nhdplus_region
         AND a.hydroseq <= p_start_flowline.hydroseq;
         
      END IF;

   END IF;
   
   RETURN 0;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.prepare_working_table(p_navigation_type character varying, p_num_max_distance numeric, p_num_max_time numeric, p_start_flowline flowline_rec, p_stop_flowline flowline_rec, p_start_path_length numeric, p_start_path_time numeric) OWNER TO nhdplus_navigation;

--
-- Name: query_single_flowline(character varying, integer, character varying, numeric, character varying, numeric, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION query_single_flowline(p_navigation_type character varying, p_comid integer, p_permanent_identifier character varying, p_hydrosequence numeric, p_reachcode character varying, p_measure numeric, p_check_intent character varying, OUT p_output flowline_rec, OUT p_check_comid integer, OUT p_check_permanent_identifier character varying, OUT p_check_measure numeric, OUT p_return_code numeric, OUT p_status_message character varying) RETURNS record
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   str_qc           VARCHAR(4000);
   str_exception    VARCHAR(4000);
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   --------------------------------------------------------------------------
   p_check_measure := p_measure;
   
   IF  p_comid IS NULL
   AND p_permanent_identifier IS NULL
   AND p_reachcode IS NULL
   AND p_hydrosequence IS NULL
   THEN
      str_exception := 'procedure requires either hydrosequence, comid or reachcode' || CHR(10) ||
         'permanent_identifier = ' || p_permanent_identifier || CHR(10) ||
         'reachcode = ' || p_reachcode || CHR(10) ||
         'hydrosequence = ' || p_hydrosequence;
         
      RAISE EXCEPTION '%',str_exception;

   END IF;
   
   --------------------------------------------------------------------------
   -- Step 10
   -- Check over incoming parameters
   --------------------------------------------------------------------------
   IF p_hydrosequence IS NOT NULL
   THEN
      str_qc := 'Hydrosequence ' || p_hydrosequence;
      
      SELECT 
       a.permanent_identifier
      ,a.comid
      ,a.reachcode
      ,a.fmeasure
      ,a.tmeasure
      ,a.hydroseq
      ,a.pathlength
      ,a.lengthkm
      ,a.lengthkm / (a.tmeasure - a.fmeasure)
      ,a.pathtime 
      ,a.travtime
      ,a.travtime / (a.tmeasure - a.fmeasure)
      ,a.divergence
      ,a.uphydroseq
      ,a.uplevelpathid
      ,a.dnhydroseq
      ,a.dnlevelpathid
      ,a.terminalpathid
      ,a.levelpathid
      ,a.nhdplus_region
      ,a.nhdplus_version
      INTO STRICT p_output
      FROM 
      nhdplus.plusflowlinevaa_np21 a
      WHERE
      a.hydroseq = p_hydrosequence;
      
      p_check_permanent_identifier := p_output.permanent_identifier;
      
      IF p_check_measure IS NULL
      AND p_navigation_type IN ('DM','DD','PP')
      THEN
         p_check_measure := p_output.tmeasure;
      
      ELSIF p_check_measure IS NULL
      THEN  
         p_check_measure := p_output.fmeasure;
      
      END IF;
      
   ELSIF p_comid IS NOT NULL
   THEN
      str_qc := 'Flowline ' || p_comid::text;
      
      IF p_check_measure IS NULL
      THEN
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime 
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE 
         a.comid = p_comid;
         
         p_check_comid := p_output.nhdplus_comid;
         p_check_permanent_identifier := p_output.permanent_identifier;
         
         IF p_navigation_type IN ('DM','DD','PP')
         THEN
            p_check_measure := p_output.tmeasure;

         ELSE
            p_check_measure := p_output.fmeasure;

         END IF;
      
      ELSE
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime 
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE 
         a.comid = p_comid
         AND (
            p_check_measure = a.fmeasure
            OR
            (a.fmeasure < p_check_measure AND a.tmeasure >= p_check_measure)
         );
      
         p_check_comid := p_output.nhdplus_comid;
         p_check_permanent_identifier := p_output.permanent_identifier;
      
      END IF;
      
   ELSIF p_permanent_identifier IS NOT NULL
   THEN
      str_qc := 'Flowline ' || p_permanent_identifier;
      
      IF p_check_measure IS NULL
      THEN
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime 
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE 
         a.permanent_identifier = p_permanent_identifier;
         
         p_check_comid := p_output.nhdplus_comid;
         p_check_permanent_identifier := p_output.permanent_identifier;

         IF p_navigation_type IN ('DM','DD','PP')
         THEN
            p_check_measure := p_output.tmeasure;

         ELSE
            p_check_measure := p_output.fmeasure;

         END IF;
      
      ELSE
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime 
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE 
             a.permanent_identifier = p_permanent_identifier      
         AND (
               p_check_measure = a.fmeasure
               OR
               (a.fmeasure < p_check_measure AND a.tmeasure >= p_check_measure)
            );

            p_check_comid := p_output.nhdplus_comid;
            p_check_permanent_identifier := p_output.permanent_identifier;
      
      END IF;
      
   ELSIF p_reachcode IS NOT NULL
   THEN
      IF p_check_measure IS NULL
      AND p_navigation_type IN ('DM','DD','PP')
      THEN
         p_check_measure := 100;
      
      ELSIF p_check_measure IS NULL
      THEN  
         p_check_measure := 0;
      
      END IF;
      
      str_qc := 'Reach code ' || p_reachcode;
      
      IF p_check_measure = 0
      THEN
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE 
             a.reachcode = p_reachcode 
         AND a.fmeasure = 0;
         
      ELSE
         SELECT 
          a.permanent_identifier
         ,a.comid
         ,a.reachcode
         ,a.fmeasure
         ,a.tmeasure
         ,a.hydroseq
         ,a.pathlength
         ,a.lengthkm
         ,a.lengthkm / (a.tmeasure - a.fmeasure)
         ,a.pathtime 
         ,a.travtime
         ,a.travtime / (a.tmeasure - a.fmeasure)
         ,a.divergence
         ,a.uphydroseq
         ,a.uplevelpathid
         ,a.dnhydroseq
         ,a.dnlevelpathid
         ,a.terminalpathid
         ,a.levelpathid
         ,a.nhdplus_region
         ,a.nhdplus_version
         INTO STRICT p_output
         FROM
         nhdplus.plusflowlinevaa_np21 a
         JOIN
         nhdplus.nhdflowline_np21 b
         ON
         a.permanent_identifier = b.permanent_identifier
         WHERE 
             b.reachcode = p_reachcode 
         AND (
            (p_check_measure = 0 AND a.fmeasure = 0)
            OR
            (a.fmeasure < p_check_measure AND a.tmeasure >= p_check_measure)
         );
      
      END IF;
      
      p_check_comid := p_output.nhdplus_comid;
      p_check_permanent_identifier := p_output.permanent_identifier;
      
   END IF;
   
   p_return_code := 0;
   RETURN;

EXCEPTION
   WHEN no_data_found
   THEN
      IF p_check_measure IS NULL
      THEN
         p_status_message := str_qc || ' not found in NHDPlus stream network.';

      ELSE
         p_status_message := str_qc || ' at measure ' || p_check_measure::text || ' not found in NHDPlus stream network.';

      END IF;
         
      p_return_code := 999;
      RETURN;
      
   WHEN OTHERS
   THEN
      RAISE;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.query_single_flowline(p_navigation_type character varying, p_comid integer, p_permanent_identifier character varying, p_hydrosequence numeric, p_reachcode character varying, p_measure numeric, p_check_intent character varying, OUT p_output flowline_rec, OUT p_check_comid integer, OUT p_check_permanent_identifier character varying, OUT p_check_measure numeric, OUT p_return_code numeric, OUT p_status_message character varying) OWNER TO nhdplus_navigation;

--
-- Name: reference_calculations(character varying, numeric, flowline_rec, numeric, numeric); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION reference_calculations(p_navigation_type character varying, p_start_measure numeric, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, OUT p_start_path_length numeric, OUT p_start_path_time numeric, OUT p_start_inc_dist numeric, OUT p_start_inc_time numeric) RETURNS record
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   str_section   VARCHAR(10);
   
BEGIN
   
   IF p_navigation_type IN ('UM','UT')
   THEN
      str_section := 'TOP';
   
   ELSE
      str_section := 'BOTTOM';
   
   END IF;

   IF p_navigation_type IN ('UM','UT')
   AND p_start_measure = p_start_flowline.fmeasure
   AND (
      p_num_max_distance >= p_start_flowline.lengthkm
      OR
      p_num_max_time >= p_start_flowline.travtime
   )
   THEN
      p_start_path_length := p_start_flowline.pathlength;
      p_start_path_time   := p_start_flowline.pathtime;
      p_start_inc_dist    := p_start_flowline.lengthkm;
      p_start_inc_time    := p_start_flowline.travtime;
      
   ELSE
      --If going up, need starting pathlength, pathtime, and 'TOP' included distance or time.
      --If going down, need starting pathlength, pathtime, and 'BOTTOM' included distance or time.
      --Will be using the starting pathlength/pathtime to limit the number of records copied
      --     into the working table
      
      p_start_path_length := nhdplus_navigation.start_path_length(
          p_navigation_type := p_navigation_type
         ,p_fmeasure        := p_start_flowline.fmeasure
         ,p_tmeasure        := p_start_flowline.tmeasure
         ,p_length          := p_start_flowline.lengthkm
         ,p_measure         := p_start_measure
         ,p_path_length     := p_start_flowline.pathlength
         ,p_divergence      := p_start_flowline.divergence
         ,p_up_hydro_seq    := p_start_flowline.uphydroseq
         ,p_type            := 'DIST'
      );
      
      p_start_path_time := nhdplus_navigation.start_path_length(
          p_navigation_type := p_navigation_type
         ,p_fmeasure        := p_start_flowline.fmeasure
         ,p_tmeasure        := p_start_flowline.tmeasure
         ,p_length          := p_start_flowline.travtime
         ,p_measure         := p_start_measure
         ,p_path_length     := p_start_flowline.pathtime
         ,p_divergence      := p_start_flowline.divergence
         ,p_up_hydro_seq    := p_start_flowline.uphydroseq
         ,p_type            := 'TIME'
      );

      p_start_inc_dist := nhdplus_navigation.included_distance(
          p_fmeasure        := p_start_flowline.fmeasure
         ,p_tmeasure        := p_start_flowline.tmeasure
         ,p_length          := p_start_flowline.lengthkm
         ,p_measure         := p_start_measure
         ,p_half            := str_section
      );
      
      p_start_inc_time := nhdplus_navigation.included_distance(
          p_fmeasure        := p_start_flowline.fmeasure
         ,p_tmeasure        := p_start_flowline.tmeasure
         ,p_length          := p_start_flowline.travtime
         ,p_measure         := p_start_measure
         ,p_half            := str_section
      );

   END IF;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.reference_calculations(p_navigation_type character varying, p_start_measure numeric, p_start_flowline flowline_rec, p_num_max_distance numeric, p_num_max_time numeric, OUT p_start_path_length numeric, OUT p_start_path_time numeric, OUT p_start_inc_dist numeric, OUT p_start_inc_time numeric) OWNER TO nhdplus_navigation;

--
-- Name: start_path_length(character varying, numeric, numeric, numeric, numeric, numeric, numeric, numeric, character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION start_path_length(p_navigation_type character varying, p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_path_length numeric, p_divergence numeric, p_up_hydro_seq numeric, p_type character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$ 
DECLARE
   num_inc_dis           NUMERIC := 0;
   num_start_path_length NUMERIC := -1;
   num_uspl              NUMERIC;
   
BEGIN
   
   --------------------------------------------------------------------------
   -- Calculate Starting pathlength
   -- Normally, this is the pathlength plus the 'bottom included distance'
   -- When going up from a flowline that is div 2, the starting 
   -- pathlength is the pathlength of the upstream flowline minus the 
   -- 'top included distance'
   --------------------------------------------------------------------------
   IF p_navigation_type IN ('DM','DD','PP')
   OR p_divergence <> 2
   THEN
      -- Normal
      num_inc_dis := nhdplus_navigation.included_distance(
          p_fmeasure  := p_fmeasure
         ,p_tmeasure  := p_tmeasure
         ,p_length    := p_length
         ,p_measure   := p_measure
         ,p_half      := 'BOTTOM'
      );
      
      num_start_path_length := p_path_length + num_inc_dis;

   ELSE
      IF p_type = 'TIME'
      THEN
         SELECT 
         a.pathtime 
         INTO num_uspl
         FROM 
         nhdplus.plusflowlinevaa_np21 a 
         WHERE
         a.hydroseq = p_up_hydro_seq;
         
      ELSE
         SELECT
         a.pathlength
         INTO num_uspl
         FROM
         nhdplus.plusflowlinevaa_np21 a
         WHERE
         a.hydroseq = p_up_hydro_seq;
         
      END IF;

      num_inc_dis := nhdplus_navigation.included_distance(
          p_fmeasure  := p_fmeasure
         ,p_tmeasure  := p_tmeasure
         ,p_length    := p_length
         ,p_measure   := p_measure
         ,p_half      := 'TOP'
      );
      
      num_start_path_length := num_uspl - num_inc_dis;

   END IF;

   RETURN num_start_path_length;
   
END;
$$;


ALTER FUNCTION nhdplus_navigation.start_path_length(p_navigation_type character varying, p_fmeasure numeric, p_tmeasure numeric, p_length numeric, p_measure numeric, p_path_length numeric, p_divergence numeric, p_up_hydro_seq numeric, p_type character varying) OWNER TO nhdplus_navigation;

--
-- Name: temp_table_exists(character varying); Type: FUNCTION; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE FUNCTION temp_table_exists(p_table_name character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
   str_table_name VARCHAR(255);
   
BEGIN

   ----------------------------------------------------------------------------
   -- Step 10
   -- Query catalog for temp table
   ----------------------------------------------------------------------------
   SELECT 
    n.nspname
   INTO str_table_name
   FROM 
   pg_catalog.pg_class c 
   LEFT JOIN 
   pg_catalog.pg_namespace n 
   ON 
   n.oid = c.relnamespace
   where 
       n.nspname like 'pg_temp_%'
   AND pg_catalog.pg_table_is_visible(c.oid)
   AND UPPER(relname) = UPPER(p_table_name);

   ----------------------------------------------------------------------------
   -- Step 20
   -- See what we gots and exit accordingly
   ----------------------------------------------------------------------------
   IF str_table_name IS NULL 
   THEN
      RETURN FALSE;

   ELSE
      RETURN TRUE;

   END IF;

END;
$$;


ALTER FUNCTION nhdplus_navigation.temp_table_exists(p_table_name character varying) OWNER TO nhdplus_navigation;

SET search_path = nhdplus, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: catchmentsp; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE catchmentsp (
    ogc_fid integer NOT NULL,
    the_geom public.geometry(MultiPolygon,4269),
    gridcode integer,
    featureid integer,
    sourcefc character varying,
    areasqkm double precision,
    shape_length double precision,
    shape_area double precision
);


ALTER TABLE catchmentsp OWNER TO nldi;

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE; Schema: nhdplus; Owner: nldi
--

CREATE SEQUENCE catchmentsp_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE catchmentsp_ogc_fid_seq OWNER TO nldi;

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: nhdplus; Owner: nldi
--

ALTER SEQUENCE catchmentsp_ogc_fid_seq OWNED BY catchmentsp.ogc_fid;


--
-- Name: megadiv_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE megadiv_np21 (
    objectid integer NOT NULL,
    fromcomid integer NOT NULL,
    tocomid integer NOT NULL,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL
);


ALTER TABLE megadiv_np21 OWNER TO nldi;

--
-- Name: nhdflowline_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE nhdflowline_np21 (
    objectid integer NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    nhdplus_comid integer NOT NULL,
    fdate timestamp without time zone NOT NULL,
    resolution numeric(38,10) NOT NULL,
    gnis_id character varying(10),
    gnis_name character varying(65),
    lengthkm numeric(38,11) NOT NULL,
    reachcode character varying(14) NOT NULL,
    flowdir integer NOT NULL,
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    ftype integer NOT NULL,
    fcode integer NOT NULL,
    reachsmdate timestamp without time zone NOT NULL,
    fmeasure numeric(38,10) NOT NULL,
    tmeasure numeric(38,10) NOT NULL,
    wbarea_ftype integer,
    wbarea_fcode integer,
    wbd_huc12 character varying(12) NOT NULL,
    wbd_huc12_percent numeric(38,10),
    catchment_featureid integer,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL,
    navigable character varying(1) NOT NULL,
    streamlevel smallint,
    streamorder smallint,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    closed_loop character varying(1),
    gdb_geomattr_data bytea,
    shape public.geometry(LineStringM,4269),
    CONSTRAINT enforce_srid_shape CHECK ((public.st_srid(shape) = 4269))
);


ALTER TABLE nhdflowline_np21 OWNER TO nldi;

--
-- Name: nhdplusconnect_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE nhdplusconnect_np21 (
    objectid integer NOT NULL,
    drainageid character varying(2),
    upunitid character varying(8) NOT NULL,
    upunittype character varying(5) NOT NULL,
    dnunitid character varying(8) NOT NULL,
    dnunittype character varying(5) NOT NULL,
    upcomid integer NOT NULL,
    dncomid integer NOT NULL,
    uphydroseq integer NOT NULL,
    dnhydroseq integer NOT NULL,
    upmainhydroseq integer,
    dnmainhydroseq integer
);


ALTER TABLE nhdplusconnect_np21 OWNER TO nldi;

--
-- Name: plusflow_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE plusflow_np21 (
    objectid integer NOT NULL,
    fromcomid integer NOT NULL,
    fromhydroseq numeric(11,0) NOT NULL,
    fromlevelpathid numeric(11,0) NOT NULL,
    tocomid integer NOT NULL,
    tohydroseq numeric(11,0) NOT NULL,
    tolevelpathid numeric(11,0) NOT NULL,
    nodenumber numeric(11,0) NOT NULL,
    deltalevel smallint NOT NULL,
    direction smallint NOT NULL,
    gapdistkm numeric(38,10) NOT NULL,
    hasgeo character varying(1) NOT NULL,
    totdasqkm numeric(38,10) NOT NULL,
    divdasqkm numeric(38,10) NOT NULL,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL
);


ALTER TABLE plusflow_np21 OWNER TO nldi;

--
-- Name: plusflowlinevaa_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE plusflowlinevaa_np21 (
    objectid integer NOT NULL,
    comid integer NOT NULL,
    fdate timestamp without time zone NOT NULL,
    streamlevel smallint NOT NULL,
    streamorder smallint NOT NULL,
    streamcalculator smallint,
    fromnode numeric(11,0) NOT NULL,
    tonode numeric(11,0) NOT NULL,
    hydroseq numeric(11,0) NOT NULL,
    levelpathid numeric(11,0) NOT NULL,
    pathlength numeric(38,10) NOT NULL,
    terminalpathid numeric(11,0) NOT NULL,
    arbolatesum numeric(38,10),
    divergence smallint,
    startflag smallint,
    terminalflag smallint,
    dnlevel smallint,
    thinnercode smallint,
    uplevelpathid numeric(11,0) NOT NULL,
    uphydroseq numeric(11,0) NOT NULL,
    dnlevelpathid numeric(11,0) NOT NULL,
    dnminorhyd numeric(11,0) NOT NULL,
    dndraincount smallint NOT NULL,
    dnhydroseq numeric(11,0) NOT NULL,
    frommeas numeric(38,10) NOT NULL,
    tomeas numeric(38,10) NOT NULL,
    reachcode character varying(14) NOT NULL,
    lengthkm numeric(38,10) NOT NULL,
    fcode integer,
    rtndiv smallint,
    outdiv smallint,
    diveffect smallint,
    vpuin smallint,
    vpuout smallint,
    travtime numeric(38,10) NOT NULL,
    pathtime numeric(38,10) NOT NULL,
    areasqkm numeric(38,10),
    totdasqkm numeric(38,10),
    divdasqkm numeric(38,10),
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    reachsmdate timestamp without time zone NOT NULL,
    fmeasure numeric(38,10) NOT NULL,
    tmeasure numeric(38,10) NOT NULL
);


ALTER TABLE plusflowlinevaa_np21 OWNER TO nldi;

SET search_path = nhdplus_navigation, pg_catalog;

--
-- Name: prep_connections_dd; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TABLE prep_connections_dd (
    objectid integer NOT NULL,
    snapshot_date date NOT NULL,
    start_permanent_identifier character varying(40) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    start_nhdplus_comid integer NOT NULL,
    nhdplus_comid integer NOT NULL,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric,
    fcode numeric,
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer,
    shape public.geometry(LineStringM,4269)
);


ALTER TABLE prep_connections_dd OWNER TO nhdplus_navigation;

--
-- Name: prep_connections_dm; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TABLE prep_connections_dm (
    objectid integer NOT NULL,
    snapshot_date date NOT NULL,
    start_permanent_identifier character varying(40) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    start_nhdplus_comid integer NOT NULL,
    nhdplus_comid integer NOT NULL,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric,
    fcode numeric,
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer,
    shape public.geometry(LineStringM,4269)
);


ALTER TABLE prep_connections_dm OWNER TO nhdplus_navigation;

--
-- Name: prep_connections_um; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TABLE prep_connections_um (
    objectid integer NOT NULL,
    snapshot_date date NOT NULL,
    start_permanent_identifier character varying(40) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    start_nhdplus_comid integer NOT NULL,
    nhdplus_comid integer NOT NULL,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric,
    fcode numeric,
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer,
    shape public.geometry(LineStringM,4269)
);


ALTER TABLE prep_connections_um OWNER TO nhdplus_navigation;

--
-- Name: prep_connections_ut; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE TABLE prep_connections_ut (
    objectid integer NOT NULL,
    snapshot_date date NOT NULL,
    start_permanent_identifier character varying(40) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    start_nhdplus_comid integer NOT NULL,
    nhdplus_comid integer NOT NULL,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric,
    fcode numeric,
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer,
    shape public.geometry(LineStringM,4269)
);


ALTER TABLE prep_connections_ut OWNER TO nhdplus_navigation;

--
-- Name: tmp_navigation_connections; Type: TABLE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE TABLE tmp_navigation_connections (
    start_permanent_identifier character varying(40),
    permanent_identifier character varying(40),
    start_nhdplus_comid integer,
    nhdplus_comid integer,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    totaldist numeric,
    totaltime numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    ofmeasure numeric,
    otmeasure numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype integer,
    fcode integer,
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer
);


ALTER TABLE tmp_navigation_connections OWNER TO nldi;

--
-- Name: tmp_navigation_connections_dd; Type: TABLE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE TABLE tmp_navigation_connections_dd (
    start_permanent_identifier character varying(40),
    permanent_identifier character varying(40),
    start_nhdplus_comid integer,
    nhdplus_comid integer,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    totaldist numeric,
    totaltime numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    ofmeasure numeric,
    otmeasure numeric,
    processed numeric(11,0),
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric(3,0),
    fcode numeric(5,0),
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer
);


ALTER TABLE tmp_navigation_connections_dd OWNER TO nldi;

--
-- Name: tmp_navigation_results; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNLOGGED TABLE tmp_navigation_results (
    objectid integer NOT NULL,
    session_id character varying(40) NOT NULL,
    start_permanent_identifier character varying(40) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    start_nhdplus_comid integer NOT NULL,
    nhdplus_comid integer NOT NULL,
    reachcode character varying(14) NOT NULL,
    fmeasure numeric NOT NULL,
    tmeasure numeric NOT NULL,
    totaldist numeric,
    totaltime numeric,
    hydroseq integer NOT NULL,
    levelpathid integer NOT NULL,
    terminalpathid integer NOT NULL,
    uphydroseq integer,
    dnhydroseq integer,
    pathlength numeric,
    lengthkm numeric NOT NULL,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    ofmeasure numeric,
    otmeasure numeric,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date,
    ftype numeric(3,0),
    fcode numeric(5,0),
    gnis_id character varying(10),
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    wbd_huc12 character varying(12),
    catchment_featureid integer,
    shape public.geometry(LineStringM,4269)
);


ALTER TABLE tmp_navigation_results OWNER TO nhdplus_navigation;

--
-- Name: tmp_navigation_results_seq; Type: SEQUENCE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE SEQUENCE tmp_navigation_results_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tmp_navigation_results_seq OWNER TO nldi;

--
-- Name: tmp_navigation_status; Type: TABLE; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNLOGGED TABLE tmp_navigation_status (
    objectid integer NOT NULL,
    session_id character varying(40) NOT NULL,
    return_code integer,
    status_message character varying(255),
    session_datestamp timestamp without time zone
);


ALTER TABLE tmp_navigation_status OWNER TO nhdplus_navigation;

--
-- Name: tmp_navigation_status_seq; Type: SEQUENCE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE SEQUENCE tmp_navigation_status_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tmp_navigation_status_seq OWNER TO nldi;

--
-- Name: tmp_navigation_uptrib; Type: TABLE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE TABLE tmp_navigation_uptrib (
    fromlevelpathid integer,
    minhs integer
);


ALTER TABLE tmp_navigation_uptrib OWNER TO nldi;

--
-- Name: tmp_navigation_working; Type: TABLE; Schema: nhdplus_navigation; Owner: nldi
--

CREATE TABLE tmp_navigation_working (
    start_permanent_identifier character varying(40),
    permanent_identifier character varying(40),
    start_nhdplus_comid integer,
    nhdplus_comid integer,
    reachcode character varying(14),
    fmeasure numeric,
    tmeasure numeric,
    totaldist numeric,
    totaltime numeric,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    uplevelpathid integer,
    dnhydroseq integer,
    dnlevelpathid integer,
    dnminorhyd integer,
    divergence integer,
    dndraincount integer,
    pathlength numeric,
    lengthkm numeric,
    length_measure_ratio numeric,
    pathtime numeric,
    travtime numeric,
    time_measure_ratio numeric,
    ofmeasure numeric,
    otmeasure numeric,
    selected integer,
    nhdplus_region character varying(3),
    nhdplus_version character varying(6),
    reachsmdate date
);


ALTER TABLE tmp_navigation_working OWNER TO nldi;

SET search_path = nldi_data, pg_catalog;

--
-- Name: crawler_source; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE crawler_source (
    crawler_source_id integer NOT NULL,
    source_name character varying(500) NOT NULL,
    source_suffix character varying(10) NOT NULL,
    source_uri character varying(256) NOT NULL,
    feature_id character varying(500) NOT NULL,
    feature_name character varying(500) NOT NULL,
    feature_uri_prefix character varying(256) NOT NULL
);


ALTER TABLE crawler_source OWNER TO nldi;

--
-- Name: feature; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature (
    crawler_source_id integer NOT NULL,
    identifier character varying(500),
    name character varying(500),
    uri character varying(256),
    location public.geometry(Point,4269),
    comid integer
);


ALTER TABLE feature OWNER TO nldi;

--
-- Name: feature_wqp; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature_wqp (
)
INHERITS (feature);


ALTER TABLE feature_wqp OWNER TO nldi;

--
-- Name: feature_wqp_temp; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature_wqp_temp (
    crawler_source_id integer NOT NULL,
    identifier character varying(500),
    name character varying(500),
    uri character varying(256),
    location public.geometry(Point,4269),
    comid integer
);


ALTER TABLE feature_wqp_temp OWNER TO nldi;

SET search_path = public, pg_catalog;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: nldi
--

CREATE TABLE databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255)
);


ALTER TABLE databasechangelog OWNER TO nldi;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: nldi
--

CREATE TABLE databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE databasechangeloglock OWNER TO nldi;

SET search_path = nhdplus, pg_catalog;

--
-- Name: ogc_fid; Type: DEFAULT; Schema: nhdplus; Owner: nldi
--

ALTER TABLE ONLY catchmentsp ALTER COLUMN ogc_fid SET DEFAULT nextval('catchmentsp_ogc_fid_seq'::regclass);


--
-- Data for Name: catchmentsp; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY catchmentsp (ogc_fid, the_geom, gridcode, featureid, sourcefc, areasqkm, shape_length, shape_area) FROM stdin;
\.
COPY catchmentsp (ogc_fid, the_geom, gridcode, featureid, sourcefc, areasqkm, shape_length, shape_area) FROM '$$PATH$$/3850.dat';

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE SET; Schema: nhdplus; Owner: nldi
--

SELECT pg_catalog.setval('catchmentsp_ogc_fid_seq', 1, false);


--
-- Data for Name: megadiv_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY megadiv_np21 (objectid, fromcomid, tocomid, nhdplus_region, nhdplus_version) FROM stdin;
\.
COPY megadiv_np21 (objectid, fromcomid, tocomid, nhdplus_region, nhdplus_version) FROM '$$PATH$$/3844.dat';

--
-- Data for Name: nhdflowline_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY nhdflowline_np21 (objectid, permanent_identifier, nhdplus_comid, fdate, resolution, gnis_id, gnis_name, lengthkm, reachcode, flowdir, wbarea_permanent_identifier, wbarea_nhdplus_comid, ftype, fcode, reachsmdate, fmeasure, tmeasure, wbarea_ftype, wbarea_fcode, wbd_huc12, wbd_huc12_percent, catchment_featureid, nhdplus_region, nhdplus_version, navigable, streamlevel, streamorder, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, closed_loop, gdb_geomattr_data, shape) FROM stdin;
\.
COPY nhdflowline_np21 (objectid, permanent_identifier, nhdplus_comid, fdate, resolution, gnis_id, gnis_name, lengthkm, reachcode, flowdir, wbarea_permanent_identifier, wbarea_nhdplus_comid, ftype, fcode, reachsmdate, fmeasure, tmeasure, wbarea_ftype, wbarea_fcode, wbd_huc12, wbd_huc12_percent, catchment_featureid, nhdplus_region, nhdplus_version, navigable, streamlevel, streamorder, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, closed_loop, gdb_geomattr_data, shape) FROM '$$PATH$$/3845.dat';

--
-- Data for Name: nhdplusconnect_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY nhdplusconnect_np21 (objectid, drainageid, upunitid, upunittype, dnunitid, dnunittype, upcomid, dncomid, uphydroseq, dnhydroseq, upmainhydroseq, dnmainhydroseq) FROM stdin;
\.
COPY nhdplusconnect_np21 (objectid, drainageid, upunitid, upunittype, dnunitid, dnunittype, upcomid, dncomid, uphydroseq, dnhydroseq, upmainhydroseq, dnmainhydroseq) FROM '$$PATH$$/3846.dat';

--
-- Data for Name: plusflow_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY plusflow_np21 (objectid, fromcomid, fromhydroseq, fromlevelpathid, tocomid, tohydroseq, tolevelpathid, nodenumber, deltalevel, direction, gapdistkm, hasgeo, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version) FROM stdin;
\.
COPY plusflow_np21 (objectid, fromcomid, fromhydroseq, fromlevelpathid, tocomid, tohydroseq, tolevelpathid, nodenumber, deltalevel, direction, gapdistkm, hasgeo, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version) FROM '$$PATH$$/3848.dat';

--
-- Data for Name: plusflowlinevaa_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY plusflowlinevaa_np21 (objectid, comid, fdate, streamlevel, streamorder, streamcalculator, fromnode, tonode, hydroseq, levelpathid, pathlength, terminalpathid, arbolatesum, divergence, startflag, terminalflag, dnlevel, thinnercode, uplevelpathid, uphydroseq, dnlevelpathid, dnminorhyd, dndraincount, dnhydroseq, frommeas, tomeas, reachcode, lengthkm, fcode, rtndiv, outdiv, diveffect, vpuin, vpuout, travtime, pathtime, areasqkm, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version, permanent_identifier, reachsmdate, fmeasure, tmeasure) FROM stdin;
\.
COPY plusflowlinevaa_np21 (objectid, comid, fdate, streamlevel, streamorder, streamcalculator, fromnode, tonode, hydroseq, levelpathid, pathlength, terminalpathid, arbolatesum, divergence, startflag, terminalflag, dnlevel, thinnercode, uplevelpathid, uphydroseq, dnlevelpathid, dnminorhyd, dndraincount, dnhydroseq, frommeas, tomeas, reachcode, lengthkm, fcode, rtndiv, outdiv, diveffect, vpuin, vpuout, travtime, pathtime, areasqkm, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version, permanent_identifier, reachsmdate, fmeasure, tmeasure) FROM '$$PATH$$/3847.dat';

SET search_path = nhdplus_navigation, pg_catalog;

--
-- Data for Name: prep_connections_dd; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY prep_connections_dd (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM stdin;
\.
COPY prep_connections_dd (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM '$$PATH$$/3834.dat';

--
-- Data for Name: prep_connections_dm; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY prep_connections_dm (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM stdin;
\.
COPY prep_connections_dm (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM '$$PATH$$/3835.dat';

--
-- Data for Name: prep_connections_um; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY prep_connections_um (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM stdin;
\.
COPY prep_connections_um (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM '$$PATH$$/3836.dat';

--
-- Data for Name: prep_connections_ut; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY prep_connections_ut (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM stdin;
\.
COPY prep_connections_ut (objectid, snapshot_date, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM '$$PATH$$/3837.dat';

--
-- Data for Name: tmp_navigation_connections; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nldi
--

COPY tmp_navigation_connections (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid) FROM stdin;
\.
COPY tmp_navigation_connections (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid) FROM '$$PATH$$/3838.dat';

--
-- Data for Name: tmp_navigation_connections_dd; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nldi
--

COPY tmp_navigation_connections_dd (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, processed, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid) FROM stdin;
\.
COPY tmp_navigation_connections_dd (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, processed, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid) FROM '$$PATH$$/3839.dat';

--
-- Data for Name: tmp_navigation_results; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY tmp_navigation_results (objectid, session_id, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM stdin;
\.
COPY tmp_navigation_results (objectid, session_id, start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, nhdplus_region, nhdplus_version, reachsmdate, ftype, fcode, gnis_id, wbarea_permanent_identifier, wbarea_nhdplus_comid, wbd_huc12, catchment_featureid, shape) FROM '$$PATH$$/3840.dat';

--
-- Name: tmp_navigation_results_seq; Type: SEQUENCE SET; Schema: nhdplus_navigation; Owner: nldi
--

SELECT pg_catalog.setval('tmp_navigation_results_seq', 7985, true);


--
-- Data for Name: tmp_navigation_status; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

COPY tmp_navigation_status (objectid, session_id, return_code, status_message, session_datestamp) FROM stdin;
\.
COPY tmp_navigation_status (objectid, session_id, return_code, status_message, session_datestamp) FROM '$$PATH$$/3841.dat';

--
-- Name: tmp_navigation_status_seq; Type: SEQUENCE SET; Schema: nhdplus_navigation; Owner: nldi
--

SELECT pg_catalog.setval('tmp_navigation_status_seq', 274, true);


--
-- Data for Name: tmp_navigation_uptrib; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nldi
--

COPY tmp_navigation_uptrib (fromlevelpathid, minhs) FROM stdin;
\.
COPY tmp_navigation_uptrib (fromlevelpathid, minhs) FROM '$$PATH$$/3842.dat';

--
-- Data for Name: tmp_navigation_working; Type: TABLE DATA; Schema: nhdplus_navigation; Owner: nldi
--

COPY tmp_navigation_working (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, uplevelpathid, dnhydroseq, dnlevelpathid, dnminorhyd, divergence, dndraincount, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, selected, nhdplus_region, nhdplus_version, reachsmdate) FROM stdin;
\.
COPY tmp_navigation_working (start_permanent_identifier, permanent_identifier, start_nhdplus_comid, nhdplus_comid, reachcode, fmeasure, tmeasure, totaldist, totaltime, hydroseq, levelpathid, terminalpathid, uphydroseq, uplevelpathid, dnhydroseq, dnlevelpathid, dnminorhyd, divergence, dndraincount, pathlength, lengthkm, length_measure_ratio, pathtime, travtime, time_measure_ratio, ofmeasure, otmeasure, selected, nhdplus_region, nhdplus_version, reachsmdate) FROM '$$PATH$$/3843.dat';

SET search_path = nldi_data, pg_catalog;

--
-- Data for Name: crawler_source; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri_prefix) FROM stdin;
\.
COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri_prefix) FROM '$$PATH$$/3851.dat';

--
-- Data for Name: feature; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3852.dat';

--
-- Data for Name: feature_wqp; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature_wqp (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature_wqp (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3853.dat';

--
-- Data for Name: feature_wqp_temp; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature_wqp_temp (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature_wqp_temp (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3854.dat';

SET search_path = public, pg_catalog;

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: nldi
--

COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels) FROM stdin;
\.
COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels) FROM '$$PATH$$/3831.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: nldi
--

COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/3830.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: nldi
--

COPY spatial_ref_sys  FROM stdin;
\.
COPY spatial_ref_sys  FROM '$$PATH$$/3575.dat';

SET search_path = topology, pg_catalog;

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: nldi
--

COPY topology  FROM stdin;
\.
COPY topology  FROM '$$PATH$$/3576.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: nldi
--

COPY layer  FROM stdin;
\.
COPY layer  FROM '$$PATH$$/3577.dat';

SET search_path = nhdplus, pg_catalog;

--
-- Name: catchmentsp_pkey; Type: CONSTRAINT; Schema: nhdplus; Owner: nldi
--

ALTER TABLE ONLY catchmentsp
    ADD CONSTRAINT catchmentsp_pkey PRIMARY KEY (ogc_fid);


SET search_path = nhdplus_navigation, pg_catalog;

--
-- Name: prep_connections_dd_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_dd
    ADD CONSTRAINT prep_connections_dd_pk PRIMARY KEY (start_nhdplus_comid, nhdplus_comid);


--
-- Name: prep_connections_dd_pk2; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_dd
    ADD CONSTRAINT prep_connections_dd_pk2 UNIQUE (start_permanent_identifier, permanent_identifier);


--
-- Name: prep_connections_dm_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_dm
    ADD CONSTRAINT prep_connections_dm_pk PRIMARY KEY (start_nhdplus_comid, nhdplus_comid);


--
-- Name: prep_connections_dm_pk2; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_dm
    ADD CONSTRAINT prep_connections_dm_pk2 UNIQUE (start_permanent_identifier, permanent_identifier);


--
-- Name: prep_connections_um_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_um
    ADD CONSTRAINT prep_connections_um_pk PRIMARY KEY (start_nhdplus_comid, nhdplus_comid);


--
-- Name: prep_connections_um_pk2; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_um
    ADD CONSTRAINT prep_connections_um_pk2 UNIQUE (start_permanent_identifier, permanent_identifier);


--
-- Name: prep_connections_ut_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_ut
    ADD CONSTRAINT prep_connections_ut_pk PRIMARY KEY (start_nhdplus_comid, nhdplus_comid);


--
-- Name: prep_connections_ut_pk2; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY prep_connections_ut
    ADD CONSTRAINT prep_connections_ut_pk2 UNIQUE (start_permanent_identifier, permanent_identifier);


--
-- Name: tmp_navigation_results_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY tmp_navigation_results
    ADD CONSTRAINT tmp_navigation_results_pk PRIMARY KEY (session_id, nhdplus_comid);


--
-- Name: tmp_navigation_results_pk2; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY tmp_navigation_results
    ADD CONSTRAINT tmp_navigation_results_pk2 UNIQUE (session_id, permanent_identifier);


--
-- Name: tmp_navigation_status_pk; Type: CONSTRAINT; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

ALTER TABLE ONLY tmp_navigation_status
    ADD CONSTRAINT tmp_navigation_status_pk PRIMARY KEY (session_id);


SET search_path = nldi_data, pg_catalog;

--
-- Name: crawler_source_pk; Type: CONSTRAINT; Schema: nldi_data; Owner: nldi
--

ALTER TABLE ONLY crawler_source
    ADD CONSTRAINT crawler_source_pk PRIMARY KEY (crawler_source_id);


SET search_path = public, pg_catalog;

--
-- Name: pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: nldi
--

ALTER TABLE ONLY databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


SET search_path = nhdplus, pg_catalog;

--
-- Name: a162_ix1; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX a162_ix1 ON nhdflowline_np21 USING gist (shape);


--
-- Name: catchmentsp_the_geom_geom_idx; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX catchmentsp_the_geom_geom_idx ON catchmentsp USING gist (the_geom);


--
-- Name: i12fromcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i12fromcomid ON plusflow_np21 USING btree (fromcomid) WITH (fillfactor='75');


--
-- Name: i160catchment_fe; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i160catchment_fe ON nhdflowline_np21 USING btree (catchment_featureid) WITH (fillfactor='75');


--
-- Name: i177terminalpath; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i177terminalpath ON plusflowlinevaa_np21 USING btree (terminalpathid) WITH (fillfactor='75');


--
-- Name: i206streamorder; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i206streamorder ON nhdflowline_np21 USING btree (streamorder) WITH (fillfactor='75');


--
-- Name: i270nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i270nhdplus_regi ON nhdflowline_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i301gnis_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i301gnis_id ON nhdflowline_np21 USING btree (gnis_id) WITH (fillfactor='75');


--
-- Name: i325comid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i325comid ON plusflowlinevaa_np21 USING btree (comid) WITH (fillfactor='75');


--
-- Name: i349reachcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i349reachcode ON plusflowlinevaa_np21 USING btree (reachcode) WITH (fillfactor='75');


--
-- Name: i387wbarea_fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i387wbarea_fcode ON nhdflowline_np21 USING btree (wbarea_fcode) WITH (fillfactor='75');


--
-- Name: i398fromcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i398fromcomid ON megadiv_np21 USING btree (fromcomid) WITH (fillfactor='75');


--
-- Name: i427fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i427fcode ON plusflowlinevaa_np21 USING btree (fcode) WITH (fillfactor='75');


--
-- Name: i442hydroseq; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i442hydroseq ON plusflowlinevaa_np21 USING btree (hydroseq) WITH (fillfactor='75');


--
-- Name: i444nhdplus_regi_1; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i444nhdplus_regi_1 ON megadiv_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i468reachcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i468reachcode ON nhdflowline_np21 USING btree (reachcode) WITH (fillfactor='75');


--
-- Name: i509nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i509nhdplus_regi ON plusflowlinevaa_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i51streamlevel; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i51streamlevel ON nhdflowline_np21 USING btree (streamlevel) WITH (fillfactor='75');


--
-- Name: i52dncomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i52dncomid ON nhdplusconnect_np21 USING btree (dncomid) WITH (fillfactor='75');


--
-- Name: i540wbarea_ftype; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i540wbarea_ftype ON nhdflowline_np21 USING btree (wbarea_ftype) WITH (fillfactor='75');


--
-- Name: i556nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i556nhdplus_regi ON plusflow_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i576permanent_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i576permanent_id ON nhdflowline_np21 USING btree (permanent_identifier) WITH (fillfactor='75');


--
-- Name: i603wbd_huc12; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i603wbd_huc12 ON nhdflowline_np21 USING btree (wbd_huc12) WITH (fillfactor='75');


--
-- Name: i605nhdplus_comi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i605nhdplus_comi ON nhdflowline_np21 USING btree (nhdplus_comid) WITH (fillfactor='75');


--
-- Name: i638streamorder; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i638streamorder ON plusflowlinevaa_np21 USING btree (streamorder) WITH (fillfactor='75');


--
-- Name: i648levelpathid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i648levelpathid ON plusflowlinevaa_np21 USING btree (levelpathid) WITH (fillfactor='75');


--
-- Name: i655gnis_name; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i655gnis_name ON nhdflowline_np21 USING btree (gnis_name) WITH (fillfactor='75');


--
-- Name: i664tocomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i664tocomid ON megadiv_np21 USING btree (tocomid) WITH (fillfactor='75');


--
-- Name: i757wbarea_nhdpl; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i757wbarea_nhdpl ON nhdflowline_np21 USING btree (wbarea_nhdplus_comid) WITH (fillfactor='75');


--
-- Name: i814hydroseq; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i814hydroseq ON nhdflowline_np21 USING btree (hydroseq) WITH (fillfactor='75');


--
-- Name: i818wbarea_perma; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i818wbarea_perma ON nhdflowline_np21 USING btree (wbarea_permanent_identifier) WITH (fillfactor='75');


--
-- Name: i82ftype; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i82ftype ON nhdflowline_np21 USING btree (ftype) WITH (fillfactor='75');


--
-- Name: i835fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i835fcode ON nhdflowline_np21 USING btree (fcode) WITH (fillfactor='75');


--
-- Name: i841upcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i841upcomid ON nhdplusconnect_np21 USING btree (upcomid) WITH (fillfactor='75');


--
-- Name: i871navigable; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i871navigable ON nhdflowline_np21 USING btree (navigable) WITH (fillfactor='75');


--
-- Name: i910permanent_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i910permanent_id ON plusflowlinevaa_np21 USING btree (permanent_identifier) WITH (fillfactor='75');


--
-- Name: i954streamlevel; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i954streamlevel ON plusflowlinevaa_np21 USING btree (streamlevel) WITH (fillfactor='75');


--
-- Name: i973tocomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i973tocomid ON plusflow_np21 USING btree (tocomid) WITH (fillfactor='75');


--
-- Name: r325_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r325_sde_rowid_uk ON nhdplusconnect_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r34_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r34_sde_rowid_uk ON megadiv_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r368_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r368_sde_rowid_uk ON nhdflowline_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r43_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r43_sde_rowid_uk ON plusflow_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r45_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r45_sde_rowid_uk ON plusflowlinevaa_np21 USING btree (objectid) WITH (fillfactor='60');


SET search_path = nhdplus_navigation, pg_catalog;

--
-- Name: prep_connections_dd_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dd_08i ON prep_connections_dd USING btree (hydroseq);


--
-- Name: prep_connections_dd_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dd_13i ON prep_connections_dd USING btree (pathlength);


--
-- Name: prep_connections_dd_14i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dd_14i ON prep_connections_dd USING btree (lengthkm);


--
-- Name: prep_connections_dd_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dd_16i ON prep_connections_dd USING btree (pathtime);


--
-- Name: prep_connections_dd_17i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dd_17i ON prep_connections_dd USING btree (travtime);


--
-- Name: prep_connections_dd_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX prep_connections_dd_u01 ON prep_connections_dd USING btree (objectid);


--
-- Name: prep_connections_dm_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dm_08i ON prep_connections_dm USING btree (hydroseq);


--
-- Name: prep_connections_dm_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dm_13i ON prep_connections_dm USING btree (pathlength);


--
-- Name: prep_connections_dm_14i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dm_14i ON prep_connections_dm USING btree (lengthkm);


--
-- Name: prep_connections_dm_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dm_16i ON prep_connections_dm USING btree (pathtime);


--
-- Name: prep_connections_dm_17i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_dm_17i ON prep_connections_dm USING btree (travtime);


--
-- Name: prep_connections_dm_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX prep_connections_dm_u01 ON prep_connections_dm USING btree (objectid);


--
-- Name: prep_connections_um_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_um_08i ON prep_connections_um USING btree (hydroseq);


--
-- Name: prep_connections_um_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_um_13i ON prep_connections_um USING btree (pathlength);


--
-- Name: prep_connections_um_14i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_um_14i ON prep_connections_um USING btree (lengthkm);


--
-- Name: prep_connections_um_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_um_16i ON prep_connections_um USING btree (pathtime);


--
-- Name: prep_connections_um_17i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_um_17i ON prep_connections_um USING btree (travtime);


--
-- Name: prep_connections_um_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX prep_connections_um_u01 ON prep_connections_um USING btree (objectid);


--
-- Name: prep_connections_ut_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_ut_08i ON prep_connections_ut USING btree (hydroseq);


--
-- Name: prep_connections_ut_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_ut_13i ON prep_connections_ut USING btree (pathlength);


--
-- Name: prep_connections_ut_14i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_ut_14i ON prep_connections_ut USING btree (lengthkm);


--
-- Name: prep_connections_ut_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_ut_16i ON prep_connections_ut USING btree (pathtime);


--
-- Name: prep_connections_ut_17i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX prep_connections_ut_17i ON prep_connections_ut USING btree (travtime);


--
-- Name: prep_connections_ut_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX prep_connections_ut_u01 ON prep_connections_ut USING btree (objectid);


--
-- Name: tmp_navigation_connections_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_08i ON tmp_navigation_connections USING btree (hydroseq);


--
-- Name: tmp_navigation_connections_09i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_09i ON tmp_navigation_connections USING btree (levelpathid);


--
-- Name: tmp_navigation_connections_10i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_10i ON tmp_navigation_connections USING btree (terminalpathid);


--
-- Name: tmp_navigation_connections_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_13i ON tmp_navigation_connections USING btree (pathlength);


--
-- Name: tmp_navigation_connections_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_16i ON tmp_navigation_connections USING btree (pathtime);


--
-- Name: tmp_navigation_connections_dd_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_08i ON tmp_navigation_connections_dd USING btree (hydroseq);


--
-- Name: tmp_navigation_connections_dd_09i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_09i ON tmp_navigation_connections_dd USING btree (levelpathid);


--
-- Name: tmp_navigation_connections_dd_10i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_10i ON tmp_navigation_connections_dd USING btree (terminalpathid);


--
-- Name: tmp_navigation_connections_dd_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_13i ON tmp_navigation_connections_dd USING btree (pathlength);


--
-- Name: tmp_navigation_connections_dd_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_16i ON tmp_navigation_connections_dd USING btree (pathtime);


--
-- Name: tmp_navigation_connections_dd_21i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_connections_dd_21i ON tmp_navigation_connections_dd USING btree (processed);


--
-- Name: tmp_navigation_connections_dd_pk; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_connections_dd_pk ON tmp_navigation_connections_dd USING btree (permanent_identifier);


--
-- Name: tmp_navigation_connections_dd_pk2; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_connections_dd_pk2 ON tmp_navigation_connections_dd USING btree (nhdplus_comid);


--
-- Name: tmp_navigation_connections_pk; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_connections_pk ON tmp_navigation_connections USING btree (permanent_identifier);


--
-- Name: tmp_navigation_connections_pk2; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_connections_pk2 ON tmp_navigation_connections USING btree (nhdplus_comid);


--
-- Name: tmp_navigation_results_03i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_03i ON tmp_navigation_results USING btree (session_id, reachcode);


--
-- Name: tmp_navigation_results_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_08i ON tmp_navigation_results USING btree (session_id, hydroseq);


--
-- Name: tmp_navigation_results_09i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_09i ON tmp_navigation_results USING btree (session_id, levelpathid);


--
-- Name: tmp_navigation_results_10i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_10i ON tmp_navigation_results USING btree (session_id, terminalpathid);


--
-- Name: tmp_navigation_results_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_13i ON tmp_navigation_results USING btree (session_id, pathlength);


--
-- Name: tmp_navigation_results_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE INDEX tmp_navigation_results_16i ON tmp_navigation_results USING btree (session_id, pathtime);


--
-- Name: tmp_navigation_results_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX tmp_navigation_results_u01 ON tmp_navigation_results USING btree (objectid);


--
-- Name: tmp_navigation_status_u01; Type: INDEX; Schema: nhdplus_navigation; Owner: nhdplus_navigation
--

CREATE UNIQUE INDEX tmp_navigation_status_u01 ON tmp_navigation_status USING btree (objectid);


--
-- Name: tmp_navigation_uptrib_pk; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_uptrib_pk ON tmp_navigation_uptrib USING btree (fromlevelpathid);


--
-- Name: tmp_navigation_working_03i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_03i ON tmp_navigation_working USING btree (reachcode);


--
-- Name: tmp_navigation_working_08i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_08i ON tmp_navigation_working USING btree (hydroseq);


--
-- Name: tmp_navigation_working_09i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_09i ON tmp_navigation_working USING btree (levelpathid);


--
-- Name: tmp_navigation_working_10i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_10i ON tmp_navigation_working USING btree (terminalpathid);


--
-- Name: tmp_navigation_working_13i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_13i ON tmp_navigation_working USING btree (pathlength);


--
-- Name: tmp_navigation_working_16i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_16i ON tmp_navigation_working USING btree (pathtime);


--
-- Name: tmp_navigation_working_17i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_17i ON tmp_navigation_working USING btree (dndraincount);


--
-- Name: tmp_navigation_working_26i; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE INDEX tmp_navigation_working_26i ON tmp_navigation_working USING btree (selected);


--
-- Name: tmp_navigation_working_pk; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_working_pk ON tmp_navigation_working USING btree (permanent_identifier);


--
-- Name: tmp_navigation_working_pk2; Type: INDEX; Schema: nhdplus_navigation; Owner: nldi
--

CREATE UNIQUE INDEX tmp_navigation_working_pk2 ON tmp_navigation_working USING btree (permanent_identifier);


--
-- Name: catchmentsp_np21_acu_topo; Type: ACL; Schema: -; Owner: nhdplus
--

REVOKE ALL ON SCHEMA catchmentsp_np21_acu_topo FROM PUBLIC;
REVOKE ALL ON SCHEMA catchmentsp_np21_acu_topo FROM nhdplus;
GRANT ALL ON SCHEMA catchmentsp_np21_acu_topo TO nhdplus;
GRANT USAGE ON SCHEMA catchmentsp_np21_acu_topo TO PUBLIC;


--
-- Name: catchmentsp_np21_lpv_topo; Type: ACL; Schema: -; Owner: nhdplus
--

REVOKE ALL ON SCHEMA catchmentsp_np21_lpv_topo FROM PUBLIC;
REVOKE ALL ON SCHEMA catchmentsp_np21_lpv_topo FROM nhdplus;
GRANT USAGE ON SCHEMA catchmentsp_np21_lpv_topo TO PUBLIC;


--
-- Name: catchmentsp_np21_uhi_topo; Type: ACL; Schema: -; Owner: nhdplus
--

REVOKE ALL ON SCHEMA catchmentsp_np21_uhi_topo FROM PUBLIC;
REVOKE ALL ON SCHEMA catchmentsp_np21_uhi_topo FROM nhdplus;
GRANT ALL ON SCHEMA catchmentsp_np21_uhi_topo TO nhdplus;
GRANT USAGE ON SCHEMA catchmentsp_np21_uhi_topo TO PUBLIC;


--
-- Name: nhdplus; Type: ACL; Schema: -; Owner: nhdplus
--

REVOKE ALL ON SCHEMA nhdplus FROM PUBLIC;
REVOKE ALL ON SCHEMA nhdplus FROM nhdplus;
GRANT ALL ON SCHEMA nhdplus TO nhdplus;
GRANT USAGE ON SCHEMA nhdplus TO PUBLIC;


--
-- Name: nhdplus_delineation; Type: ACL; Schema: -; Owner: nhdplus_delineation
--

REVOKE ALL ON SCHEMA nhdplus_delineation FROM PUBLIC;
REVOKE ALL ON SCHEMA nhdplus_delineation FROM nhdplus_delineation;
GRANT ALL ON SCHEMA nhdplus_delineation TO nhdplus_delineation;
GRANT USAGE ON SCHEMA nhdplus_delineation TO PUBLIC;


--
-- Name: nhdplus_indexing; Type: ACL; Schema: -; Owner: nhdplus_indexing
--

REVOKE ALL ON SCHEMA nhdplus_indexing FROM PUBLIC;
REVOKE ALL ON SCHEMA nhdplus_indexing FROM nhdplus_indexing;
GRANT ALL ON SCHEMA nhdplus_indexing TO nhdplus_indexing;
GRANT USAGE ON SCHEMA nhdplus_indexing TO PUBLIC;


--
-- Name: nhdplus_navigation; Type: ACL; Schema: -; Owner: nhdplus_navigation
--

REVOKE ALL ON SCHEMA nhdplus_navigation FROM PUBLIC;
REVOKE ALL ON SCHEMA nhdplus_navigation FROM nhdplus_navigation;
GRANT ALL ON SCHEMA nhdplus_navigation TO nhdplus_navigation;
GRANT USAGE ON SCHEMA nhdplus_navigation TO PUBLIC;


--
-- Name: nldi_data; Type: ACL; Schema: -; Owner: nldi_data
--

REVOKE ALL ON SCHEMA nldi_data FROM PUBLIC;
REVOKE ALL ON SCHEMA nldi_data FROM nldi_data;
GRANT ALL ON SCHEMA nldi_data TO nldi_data;
GRANT USAGE ON SCHEMA nldi_data TO PUBLIC;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

