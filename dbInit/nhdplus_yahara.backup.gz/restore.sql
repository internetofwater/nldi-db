--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.2
-- Dumped by pg_dump version 9.5.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = nhdplus, pg_catalog;

DROP INDEX nhdplus.r45_sde_rowid_uk;
DROP INDEX nhdplus.r43_sde_rowid_uk;
DROP INDEX nhdplus.r368_sde_rowid_uk;
DROP INDEX nhdplus.r34_sde_rowid_uk;
DROP INDEX nhdplus.r325_sde_rowid_uk;
DROP INDEX nhdplus.i973tocomid;
DROP INDEX nhdplus.i954streamlevel;
DROP INDEX nhdplus.i910permanent_id;
DROP INDEX nhdplus.i871navigable;
DROP INDEX nhdplus.i841upcomid;
DROP INDEX nhdplus.i835fcode;
DROP INDEX nhdplus.i82ftype;
DROP INDEX nhdplus.i818wbarea_perma;
DROP INDEX nhdplus.i814hydroseq;
DROP INDEX nhdplus.i757wbarea_nhdpl;
DROP INDEX nhdplus.i664tocomid;
DROP INDEX nhdplus.i655gnis_name;
DROP INDEX nhdplus.i648levelpathid;
DROP INDEX nhdplus.i638streamorder;
DROP INDEX nhdplus.i605nhdplus_comi;
DROP INDEX nhdplus.i603wbd_huc12;
DROP INDEX nhdplus.i576permanent_id;
DROP INDEX nhdplus.i556nhdplus_regi;
DROP INDEX nhdplus.i540wbarea_ftype;
DROP INDEX nhdplus.i52dncomid;
DROP INDEX nhdplus.i51streamlevel;
DROP INDEX nhdplus.i509nhdplus_regi;
DROP INDEX nhdplus.i468reachcode;
DROP INDEX nhdplus.i444nhdplus_regi_1;
DROP INDEX nhdplus.i442hydroseq;
DROP INDEX nhdplus.i427fcode;
DROP INDEX nhdplus.i398fromcomid;
DROP INDEX nhdplus.i387wbarea_fcode;
DROP INDEX nhdplus.i349reachcode;
DROP INDEX nhdplus.i325comid;
DROP INDEX nhdplus.i301gnis_id;
DROP INDEX nhdplus.i270nhdplus_regi;
DROP INDEX nhdplus.i206streamorder;
DROP INDEX nhdplus.i177terminalpath;
DROP INDEX nhdplus.i160catchment_fe;
DROP INDEX nhdplus.i12fromcomid;
DROP INDEX nhdplus.catchmentsp_the_geom_geom_idx;
DROP INDEX nhdplus.a162_ix1;
SET search_path = nldi_data, pg_catalog;

ALTER TABLE ONLY nldi_data.crawler_source DROP CONSTRAINT crawler_source_pk;
SET search_path = nhdplus, pg_catalog;

ALTER TABLE ONLY nhdplus.catchmentsp DROP CONSTRAINT catchmentsp_pkey;
SET search_path = nldi_data, pg_catalog;

SET search_path = nhdplus, pg_catalog;

ALTER TABLE nhdplus.catchmentsp ALTER COLUMN ogc_fid DROP DEFAULT;
SET search_path = nldi_data, pg_catalog;

DROP TABLE nldi_data.feature_wqp_temp;
DROP TABLE nldi_data.feature_wqp;
DROP TABLE nldi_data.feature;
DROP TABLE nldi_data.crawler_source;
SET search_path = nhdplus, pg_catalog;

DROP TABLE nhdplus.plusflowlinevaa_np21;
DROP TABLE nhdplus.plusflow_np21;
DROP TABLE nhdplus.nhdplusconnect_np21;
DROP TABLE nhdplus.nhdflowline_np21;
DROP TABLE nhdplus.megadiv_np21;
DROP SEQUENCE nhdplus.catchmentsp_ogc_fid_seq;
DROP TABLE nhdplus.catchmentsp;
DROP SCHEMA nldi_data;
DROP SCHEMA nhdplus;
--
-- Name: nhdplus; Type: SCHEMA; Schema: -; Owner: nhdplus
--

CREATE SCHEMA nhdplus;


ALTER SCHEMA nhdplus OWNER TO nhdplus;

--
-- Name: nldi_data; Type: SCHEMA; Schema: -; Owner: nldi_data
--

CREATE SCHEMA nldi_data;


ALTER SCHEMA nldi_data OWNER TO nldi_data;

SET search_path = nhdplus, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: catchmentsp; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE catchmentsp (
    ogc_fid integer NOT NULL,
    the_geom public.geometry(MultiPolygon,4269),
    gridcode integer,
    featureid integer,
    sourcefc character varying,
    areasqkm double precision,
    shape_length double precision,
    shape_area double precision
);


ALTER TABLE catchmentsp OWNER TO nldi;

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE; Schema: nhdplus; Owner: nldi
--

CREATE SEQUENCE catchmentsp_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE catchmentsp_ogc_fid_seq OWNER TO nldi;

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: nhdplus; Owner: nldi
--

ALTER SEQUENCE catchmentsp_ogc_fid_seq OWNED BY catchmentsp.ogc_fid;


--
-- Name: megadiv_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE megadiv_np21 (
    objectid integer NOT NULL,
    fromcomid integer NOT NULL,
    tocomid integer NOT NULL,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL
);


ALTER TABLE megadiv_np21 OWNER TO nldi;

--
-- Name: nhdflowline_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE nhdflowline_np21 (
    objectid integer NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    nhdplus_comid integer NOT NULL,
    fdate timestamp without time zone NOT NULL,
    resolution numeric(38,10) NOT NULL,
    gnis_id character varying(10),
    gnis_name character varying(65),
    lengthkm numeric(38,11) NOT NULL,
    reachcode character varying(14) NOT NULL,
    flowdir integer NOT NULL,
    wbarea_permanent_identifier character varying(40),
    wbarea_nhdplus_comid integer,
    ftype integer NOT NULL,
    fcode integer NOT NULL,
    reachsmdate timestamp without time zone NOT NULL,
    fmeasure numeric(38,10) NOT NULL,
    tmeasure numeric(38,10) NOT NULL,
    wbarea_ftype integer,
    wbarea_fcode integer,
    wbd_huc12 character varying(12) NOT NULL,
    wbd_huc12_percent numeric(38,10),
    catchment_featureid integer,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL,
    navigable character varying(1) NOT NULL,
    streamlevel smallint,
    streamorder smallint,
    hydroseq integer,
    levelpathid integer,
    terminalpathid integer,
    uphydroseq integer,
    dnhydroseq integer,
    closed_loop character varying(1),
    gdb_geomattr_data bytea,
    shape public.geometry(LineStringM,4269),
    CONSTRAINT enforce_srid_shape CHECK ((public.st_srid(shape) = 4269))
);


ALTER TABLE nhdflowline_np21 OWNER TO nldi;

--
-- Name: nhdplusconnect_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE nhdplusconnect_np21 (
    objectid integer NOT NULL,
    drainageid character varying(2),
    upunitid character varying(8) NOT NULL,
    upunittype character varying(5) NOT NULL,
    dnunitid character varying(8) NOT NULL,
    dnunittype character varying(5) NOT NULL,
    upcomid integer NOT NULL,
    dncomid integer NOT NULL,
    uphydroseq integer NOT NULL,
    dnhydroseq integer NOT NULL,
    upmainhydroseq integer,
    dnmainhydroseq integer
);


ALTER TABLE nhdplusconnect_np21 OWNER TO nldi;

--
-- Name: plusflow_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE plusflow_np21 (
    objectid integer NOT NULL,
    fromcomid integer NOT NULL,
    fromhydroseq numeric(11,0) NOT NULL,
    fromlevelpathid numeric(11,0) NOT NULL,
    tocomid integer NOT NULL,
    tohydroseq numeric(11,0) NOT NULL,
    tolevelpathid numeric(11,0) NOT NULL,
    nodenumber numeric(11,0) NOT NULL,
    deltalevel smallint NOT NULL,
    direction smallint NOT NULL,
    gapdistkm numeric(38,10) NOT NULL,
    hasgeo character varying(1) NOT NULL,
    totdasqkm numeric(38,10) NOT NULL,
    divdasqkm numeric(38,10) NOT NULL,
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL
);


ALTER TABLE plusflow_np21 OWNER TO nldi;

--
-- Name: plusflowlinevaa_np21; Type: TABLE; Schema: nhdplus; Owner: nldi
--

CREATE TABLE plusflowlinevaa_np21 (
    objectid integer NOT NULL,
    comid integer NOT NULL,
    fdate timestamp without time zone NOT NULL,
    streamlevel smallint NOT NULL,
    streamorder smallint NOT NULL,
    streamcalculator smallint,
    fromnode numeric(11,0) NOT NULL,
    tonode numeric(11,0) NOT NULL,
    hydroseq numeric(11,0) NOT NULL,
    levelpathid numeric(11,0) NOT NULL,
    pathlength numeric(38,10) NOT NULL,
    terminalpathid numeric(11,0) NOT NULL,
    arbolatesum numeric(38,10),
    divergence smallint,
    startflag smallint,
    terminalflag smallint,
    dnlevel smallint,
    thinnercode smallint,
    uplevelpathid numeric(11,0) NOT NULL,
    uphydroseq numeric(11,0) NOT NULL,
    dnlevelpathid numeric(11,0) NOT NULL,
    dnminorhyd numeric(11,0) NOT NULL,
    dndraincount smallint NOT NULL,
    dnhydroseq numeric(11,0) NOT NULL,
    frommeas numeric(38,10) NOT NULL,
    tomeas numeric(38,10) NOT NULL,
    reachcode character varying(14) NOT NULL,
    lengthkm numeric(38,10) NOT NULL,
    fcode integer,
    rtndiv smallint,
    outdiv smallint,
    diveffect smallint,
    vpuin smallint,
    vpuout smallint,
    travtime numeric(38,10) NOT NULL,
    pathtime numeric(38,10) NOT NULL,
    areasqkm numeric(38,10),
    totdasqkm numeric(38,10),
    divdasqkm numeric(38,10),
    nhdplus_region character varying(3) NOT NULL,
    nhdplus_version character varying(6) NOT NULL,
    permanent_identifier character varying(40) NOT NULL,
    reachsmdate timestamp without time zone NOT NULL,
    fmeasure numeric(38,10) NOT NULL,
    tmeasure numeric(38,10) NOT NULL
);


ALTER TABLE plusflowlinevaa_np21 OWNER TO nldi;

SET search_path = nldi_data, pg_catalog;

--
-- Name: crawler_source; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE crawler_source (
    crawler_source_id integer NOT NULL,
    source_name character varying(500) NOT NULL,
    source_suffix character varying(10) NOT NULL,
    source_uri character varying(256) NOT NULL,
    feature_id character varying(500) NOT NULL,
    feature_name character varying(500) NOT NULL,
    feature_uri_prefix character varying(256) NOT NULL
);


ALTER TABLE crawler_source OWNER TO nldi;

--
-- Name: feature; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature (
    crawler_source_id integer NOT NULL,
    identifier character varying(500),
    name character varying(500),
    uri character varying(256),
    location public.geometry(Point,4269),
    comid integer
);


ALTER TABLE feature OWNER TO nldi;

--
-- Name: feature_wqp; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature_wqp (
)
INHERITS (feature);


ALTER TABLE feature_wqp OWNER TO nldi;

--
-- Name: feature_wqp_temp; Type: TABLE; Schema: nldi_data; Owner: nldi
--

CREATE TABLE feature_wqp_temp (
    crawler_source_id integer NOT NULL,
    identifier character varying(500),
    name character varying(500),
    uri character varying(256),
    location public.geometry(Point,4269),
    comid integer
);


ALTER TABLE feature_wqp_temp OWNER TO nldi;

SET search_path = nhdplus, pg_catalog;

--
-- Name: ogc_fid; Type: DEFAULT; Schema: nhdplus; Owner: nldi
--

ALTER TABLE ONLY catchmentsp ALTER COLUMN ogc_fid SET DEFAULT nextval('catchmentsp_ogc_fid_seq'::regclass);


--
-- Data for Name: catchmentsp; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY catchmentsp (ogc_fid, the_geom, gridcode, featureid, sourcefc, areasqkm, shape_length, shape_area) FROM stdin;
\.
COPY catchmentsp (ogc_fid, the_geom, gridcode, featureid, sourcefc, areasqkm, shape_length, shape_area) FROM '$$PATH$$/3697.dat';

--
-- Name: catchmentsp_ogc_fid_seq; Type: SEQUENCE SET; Schema: nhdplus; Owner: nldi
--

SELECT pg_catalog.setval('catchmentsp_ogc_fid_seq', 1, false);


--
-- Data for Name: megadiv_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY megadiv_np21 (objectid, fromcomid, tocomid, nhdplus_region, nhdplus_version) FROM stdin;
\.
COPY megadiv_np21 (objectid, fromcomid, tocomid, nhdplus_region, nhdplus_version) FROM '$$PATH$$/3691.dat';

--
-- Data for Name: nhdflowline_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY nhdflowline_np21 (objectid, permanent_identifier, nhdplus_comid, fdate, resolution, gnis_id, gnis_name, lengthkm, reachcode, flowdir, wbarea_permanent_identifier, wbarea_nhdplus_comid, ftype, fcode, reachsmdate, fmeasure, tmeasure, wbarea_ftype, wbarea_fcode, wbd_huc12, wbd_huc12_percent, catchment_featureid, nhdplus_region, nhdplus_version, navigable, streamlevel, streamorder, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, closed_loop, gdb_geomattr_data, shape) FROM stdin;
\.
COPY nhdflowline_np21 (objectid, permanent_identifier, nhdplus_comid, fdate, resolution, gnis_id, gnis_name, lengthkm, reachcode, flowdir, wbarea_permanent_identifier, wbarea_nhdplus_comid, ftype, fcode, reachsmdate, fmeasure, tmeasure, wbarea_ftype, wbarea_fcode, wbd_huc12, wbd_huc12_percent, catchment_featureid, nhdplus_region, nhdplus_version, navigable, streamlevel, streamorder, hydroseq, levelpathid, terminalpathid, uphydroseq, dnhydroseq, closed_loop, gdb_geomattr_data, shape) FROM '$$PATH$$/3692.dat';

--
-- Data for Name: nhdplusconnect_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY nhdplusconnect_np21 (objectid, drainageid, upunitid, upunittype, dnunitid, dnunittype, upcomid, dncomid, uphydroseq, dnhydroseq, upmainhydroseq, dnmainhydroseq) FROM stdin;
\.
COPY nhdplusconnect_np21 (objectid, drainageid, upunitid, upunittype, dnunitid, dnunittype, upcomid, dncomid, uphydroseq, dnhydroseq, upmainhydroseq, dnmainhydroseq) FROM '$$PATH$$/3693.dat';

--
-- Data for Name: plusflow_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY plusflow_np21 (objectid, fromcomid, fromhydroseq, fromlevelpathid, tocomid, tohydroseq, tolevelpathid, nodenumber, deltalevel, direction, gapdistkm, hasgeo, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version) FROM stdin;
\.
COPY plusflow_np21 (objectid, fromcomid, fromhydroseq, fromlevelpathid, tocomid, tohydroseq, tolevelpathid, nodenumber, deltalevel, direction, gapdistkm, hasgeo, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: plusflowlinevaa_np21; Type: TABLE DATA; Schema: nhdplus; Owner: nldi
--

COPY plusflowlinevaa_np21 (objectid, comid, fdate, streamlevel, streamorder, streamcalculator, fromnode, tonode, hydroseq, levelpathid, pathlength, terminalpathid, arbolatesum, divergence, startflag, terminalflag, dnlevel, thinnercode, uplevelpathid, uphydroseq, dnlevelpathid, dnminorhyd, dndraincount, dnhydroseq, frommeas, tomeas, reachcode, lengthkm, fcode, rtndiv, outdiv, diveffect, vpuin, vpuout, travtime, pathtime, areasqkm, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version, permanent_identifier, reachsmdate, fmeasure, tmeasure) FROM stdin;
\.
COPY plusflowlinevaa_np21 (objectid, comid, fdate, streamlevel, streamorder, streamcalculator, fromnode, tonode, hydroseq, levelpathid, pathlength, terminalpathid, arbolatesum, divergence, startflag, terminalflag, dnlevel, thinnercode, uplevelpathid, uphydroseq, dnlevelpathid, dnminorhyd, dndraincount, dnhydroseq, frommeas, tomeas, reachcode, lengthkm, fcode, rtndiv, outdiv, diveffect, vpuin, vpuout, travtime, pathtime, areasqkm, totdasqkm, divdasqkm, nhdplus_region, nhdplus_version, permanent_identifier, reachsmdate, fmeasure, tmeasure) FROM '$$PATH$$/3694.dat';

SET search_path = nldi_data, pg_catalog;

--
-- Data for Name: crawler_source; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri_prefix) FROM stdin;
\.
COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri_prefix) FROM '$$PATH$$/3698.dat';

--
-- Data for Name: feature; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3699.dat';

--
-- Data for Name: feature_wqp; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature_wqp (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature_wqp (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3700.dat';

--
-- Data for Name: feature_wqp_temp; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY feature_wqp_temp (crawler_source_id, identifier, name, uri, location, comid) FROM stdin;
\.
COPY feature_wqp_temp (crawler_source_id, identifier, name, uri, location, comid) FROM '$$PATH$$/3701.dat';

SET search_path = nhdplus, pg_catalog;

--
-- Name: catchmentsp_pkey; Type: CONSTRAINT; Schema: nhdplus; Owner: nldi
--

ALTER TABLE ONLY catchmentsp
    ADD CONSTRAINT catchmentsp_pkey PRIMARY KEY (ogc_fid);


SET search_path = nldi_data, pg_catalog;

--
-- Name: crawler_source_pk; Type: CONSTRAINT; Schema: nldi_data; Owner: nldi
--

ALTER TABLE ONLY crawler_source
    ADD CONSTRAINT crawler_source_pk PRIMARY KEY (crawler_source_id);


SET search_path = nhdplus, pg_catalog;

--
-- Name: a162_ix1; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX a162_ix1 ON nhdflowline_np21 USING gist (shape);


--
-- Name: catchmentsp_the_geom_geom_idx; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX catchmentsp_the_geom_geom_idx ON catchmentsp USING gist (the_geom);


--
-- Name: i12fromcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i12fromcomid ON plusflow_np21 USING btree (fromcomid) WITH (fillfactor='75');


--
-- Name: i160catchment_fe; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i160catchment_fe ON nhdflowline_np21 USING btree (catchment_featureid) WITH (fillfactor='75');


--
-- Name: i177terminalpath; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i177terminalpath ON plusflowlinevaa_np21 USING btree (terminalpathid) WITH (fillfactor='75');


--
-- Name: i206streamorder; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i206streamorder ON nhdflowline_np21 USING btree (streamorder) WITH (fillfactor='75');


--
-- Name: i270nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i270nhdplus_regi ON nhdflowline_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i301gnis_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i301gnis_id ON nhdflowline_np21 USING btree (gnis_id) WITH (fillfactor='75');


--
-- Name: i325comid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i325comid ON plusflowlinevaa_np21 USING btree (comid) WITH (fillfactor='75');


--
-- Name: i349reachcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i349reachcode ON plusflowlinevaa_np21 USING btree (reachcode) WITH (fillfactor='75');


--
-- Name: i387wbarea_fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i387wbarea_fcode ON nhdflowline_np21 USING btree (wbarea_fcode) WITH (fillfactor='75');


--
-- Name: i398fromcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i398fromcomid ON megadiv_np21 USING btree (fromcomid) WITH (fillfactor='75');


--
-- Name: i427fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i427fcode ON plusflowlinevaa_np21 USING btree (fcode) WITH (fillfactor='75');


--
-- Name: i442hydroseq; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i442hydroseq ON plusflowlinevaa_np21 USING btree (hydroseq) WITH (fillfactor='75');


--
-- Name: i444nhdplus_regi_1; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i444nhdplus_regi_1 ON megadiv_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i468reachcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i468reachcode ON nhdflowline_np21 USING btree (reachcode) WITH (fillfactor='75');


--
-- Name: i509nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i509nhdplus_regi ON plusflowlinevaa_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i51streamlevel; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i51streamlevel ON nhdflowline_np21 USING btree (streamlevel) WITH (fillfactor='75');


--
-- Name: i52dncomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i52dncomid ON nhdplusconnect_np21 USING btree (dncomid) WITH (fillfactor='75');


--
-- Name: i540wbarea_ftype; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i540wbarea_ftype ON nhdflowline_np21 USING btree (wbarea_ftype) WITH (fillfactor='75');


--
-- Name: i556nhdplus_regi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i556nhdplus_regi ON plusflow_np21 USING btree (nhdplus_region) WITH (fillfactor='75');


--
-- Name: i576permanent_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i576permanent_id ON nhdflowline_np21 USING btree (permanent_identifier) WITH (fillfactor='75');


--
-- Name: i603wbd_huc12; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i603wbd_huc12 ON nhdflowline_np21 USING btree (wbd_huc12) WITH (fillfactor='75');


--
-- Name: i605nhdplus_comi; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i605nhdplus_comi ON nhdflowline_np21 USING btree (nhdplus_comid) WITH (fillfactor='75');


--
-- Name: i638streamorder; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i638streamorder ON plusflowlinevaa_np21 USING btree (streamorder) WITH (fillfactor='75');


--
-- Name: i648levelpathid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i648levelpathid ON plusflowlinevaa_np21 USING btree (levelpathid) WITH (fillfactor='75');


--
-- Name: i655gnis_name; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i655gnis_name ON nhdflowline_np21 USING btree (gnis_name) WITH (fillfactor='75');


--
-- Name: i664tocomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i664tocomid ON megadiv_np21 USING btree (tocomid) WITH (fillfactor='75');


--
-- Name: i757wbarea_nhdpl; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i757wbarea_nhdpl ON nhdflowline_np21 USING btree (wbarea_nhdplus_comid) WITH (fillfactor='75');


--
-- Name: i814hydroseq; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i814hydroseq ON nhdflowline_np21 USING btree (hydroseq) WITH (fillfactor='75');


--
-- Name: i818wbarea_perma; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i818wbarea_perma ON nhdflowline_np21 USING btree (wbarea_permanent_identifier) WITH (fillfactor='75');


--
-- Name: i82ftype; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i82ftype ON nhdflowline_np21 USING btree (ftype) WITH (fillfactor='75');


--
-- Name: i835fcode; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i835fcode ON nhdflowline_np21 USING btree (fcode) WITH (fillfactor='75');


--
-- Name: i841upcomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i841upcomid ON nhdplusconnect_np21 USING btree (upcomid) WITH (fillfactor='75');


--
-- Name: i871navigable; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i871navigable ON nhdflowline_np21 USING btree (navigable) WITH (fillfactor='75');


--
-- Name: i910permanent_id; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX i910permanent_id ON plusflowlinevaa_np21 USING btree (permanent_identifier) WITH (fillfactor='75');


--
-- Name: i954streamlevel; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i954streamlevel ON plusflowlinevaa_np21 USING btree (streamlevel) WITH (fillfactor='75');


--
-- Name: i973tocomid; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE INDEX i973tocomid ON plusflow_np21 USING btree (tocomid) WITH (fillfactor='75');


--
-- Name: r325_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r325_sde_rowid_uk ON nhdplusconnect_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r34_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r34_sde_rowid_uk ON megadiv_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r368_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r368_sde_rowid_uk ON nhdflowline_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r43_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r43_sde_rowid_uk ON plusflow_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: r45_sde_rowid_uk; Type: INDEX; Schema: nhdplus; Owner: nldi
--

CREATE UNIQUE INDEX r45_sde_rowid_uk ON plusflowlinevaa_np21 USING btree (objectid) WITH (fillfactor='60');


--
-- Name: nhdplus; Type: ACL; Schema: -; Owner: nhdplus
--

REVOKE ALL ON SCHEMA nhdplus FROM PUBLIC;
REVOKE ALL ON SCHEMA nhdplus FROM nhdplus;
GRANT ALL ON SCHEMA nhdplus TO nhdplus;
GRANT USAGE ON SCHEMA nhdplus TO PUBLIC;


--
-- Name: nldi_data; Type: ACL; Schema: -; Owner: nldi_data
--

REVOKE ALL ON SCHEMA nldi_data FROM PUBLIC;
REVOKE ALL ON SCHEMA nldi_data FROM nldi_data;
GRANT ALL ON SCHEMA nldi_data TO nldi_data;
GRANT USAGE ON SCHEMA nldi_data TO PUBLIC;


--
-- PostgreSQL database dump complete
--

