--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.2
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = nldi_data, pg_catalog;

SET search_path = nldi_data, pg_catalog;

--
-- Data for Name: crawler_source; Type: TABLE DATA; Schema: nldi_data; Owner: nldi
--

COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri, feature_reach, feature_measure, ingest_type) FROM stdin;
\.
COPY crawler_source (crawler_source_id, source_name, source_suffix, source_uri, feature_id, feature_name, feature_uri, feature_reach, feature_measure, ingest_type) FROM '$$PATH$$/3652.dat';

--
-- PostgreSQL database dump complete
--

